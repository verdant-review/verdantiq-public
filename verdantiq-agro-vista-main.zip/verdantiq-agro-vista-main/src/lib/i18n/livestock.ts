// Lightweight i18n dictionary for livestock + mechanization features.
// Supports English (en), Shona (sn), Ndebele (nd).

export type Lang = "en" | "sn" | "nd";

type Dict = Record<string, Record<Lang, string>>;

const DICT: Dict = {
  // Generic
  herd: { en: "Herd", sn: "Boka", nd: "Umhlambi" },
  herds: { en: "Herds", sn: "Mapoka", nd: "Imihlambi" },
  livestock: { en: "Livestock", sn: "Zvipfuyo", nd: "Imfuyo" },
  species: { en: "Species", sn: "Rudzi", nd: "Uhlobo" },
  breed: { en: "Breed", sn: "Marudzi", nd: "Uhlobo" },
  herd_size: { en: "Herd size", sn: "Huwandu hweboka", nd: "Ubukhulu bomhlambi" },
  purpose: { en: "Purpose", sn: "Chinangwa", nd: "Inhloso" },
  status: { en: "Status", sn: "Mamiriro", nd: "Isimo" },
  notes: { en: "Notes", sn: "Mashoko", nd: "Amanothi" },
  add_herd: { en: "Add herd", sn: "Wedzera boka", nd: "Engeza umhlambi" },
  add_event: { en: "Log event", sn: "Nyora chiitiko", nd: "Bhala isenzakalo" },
  vaccination: { en: "Vaccination", sn: "Jekiseni", nd: "Umjovo" },
  birth: { en: "Birth", sn: "Kuberekwa", nd: "Ukuzalwa" },
  death: { en: "Death", sn: "Rufu", nd: "Ukufa" },
  sale: { en: "Sale", sn: "Kutengeswa", nd: "Ukuthengiswa" },
  feed: { en: "Feed", sn: "Chikafu", nd: "Ukudla" },
  weighing: { en: "Weighing", sn: "Kuyera", nd: "Ukukala" },

  // Mechanization
  mechanization_score: {
    en: "Mechanization score",
    sn: "Chiyero chemichina",
    nd: "Iziphumo zemishini",
  },
  mostly_manual: {
    en: "Mostly manual — typical for smallholders",
    sn: "Maoko chete — zvakajairika kuvarimi vadiki",
    nd: "Izandla kuphela — okujwayelekile kubalimi abancane",
  },
  partially_mechanized: {
    en: "Partially mechanized",
    sn: "Pamuchina pamwe",
    nd: "Ngokwesilinganiso",
  },
  highly_mechanized: {
    en: "Highly mechanized",
    sn: "Zvakanyatso michina",
    nd: "Imishini ephezulu kakhulu",
  },
  power_source: { en: "Power source", sn: "Chinopa simba", nd: "Umthombo wamandla" },

  // Farming type
  farming_type: { en: "Farming type", sn: "Rudzi rwekurima", nd: "Uhlobo lokulima" },
  crop_only: { en: "Crops only", sn: "Zvirimwa chete", nd: "Izitshalo kuphela" },
  livestock_only: { en: "Livestock only", sn: "Zvipfuyo chete", nd: "Imfuyo kuphela" },
  mixed_farming: { en: "Mixed (crops + livestock)", sn: "Zvose (zvirimwa nezvipfuyo)", nd: "Kokubili (izitshalo lemfuyo)" },

  // Today feed
  today_on_the_farm: { en: "Today on the farm", sn: "Nhasi pamunda", nd: "Lamuhla epulazini" },
  upcoming: { en: "Upcoming", sn: "Zvichauya", nd: "Okuzayo" },
  no_items_today: { en: "Nothing pending today", sn: "Hapana chiripo nhasi", nd: "Akukho lutho lamuhla" },
};

export const SPECIES_OPTIONS = [
  "Cattle",
  "Goats",
  "Sheep",
  "Poultry (Broilers)",
  "Poultry (Layers)",
  "Pigs",
  "Fish",
  "Rabbits",
];

export function t(key: string, lang: Lang = "en"): string {
  const entry = DICT[key];
  if (!entry) return key;
  return entry[lang] || entry.en;
}
