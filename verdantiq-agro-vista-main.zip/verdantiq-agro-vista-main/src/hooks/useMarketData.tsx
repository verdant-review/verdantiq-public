
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

export const useMarketData = () => {
  const [marketData, setMarketData] = useState([]);
  const [mbarePrices, setMbarePrices] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const fetchMarketData = async () => {
    setLoading(true);
    setError(null);

    try {
      // Fetch regular market prices
      const { data: dbData, error: dbError } = await supabase
        .from('market_prices')
        .select('*')
        .order('last_updated', { ascending: false });

      if (dbError) throw dbError;

      // Fetch Mbare market prices
      const { data: mbareData, error: mbareError } = await supabase
        .from('mbare_market_prices')
        .select('*')
        .order('captured_at', { ascending: false });

      if (mbareError) throw mbareError;

      setMarketData(dbData || []);
      setMbarePrices(mbareData || []);
    } catch (err: any) {
      setError(err.message);
      console.error('Market data fetch error:', err);
      setMarketData([]);
      setMbarePrices([]);
    } finally {
      setLoading(false);
    }
  };

  const fetchHistoricalData = async (crop: string, item?: string) => {
    try {
      if (item) {
        // Fetch mbare price history
        const { data, error } = await supabase
          .from('mbare_price_history')
          .select('*')
          .eq('item', item)
          .order('recorded_date', { ascending: true })
          .limit(30);

        if (error) throw error;
        return data || [];
      } else {
        // Fetch grain price history
        const { data, error } = await supabase
          .from('market_price_history')
          .select('*')
          .eq('crop', crop)
          .order('recorded_date', { ascending: true })
          .limit(30);

        if (error) throw error;
        return data || [];
      }
    } catch (err) {
      console.error('Error fetching historical data:', err);
      return [];
    }
  };

  const calculateTrends = (historicalData: any[], currentPrice: number) => {
    if (historicalData.length === 0) {
      return { sevenDay: 0, thirtyDay: 0 };
    }

    // Get 7-day old price
    const sevenDaysAgo = historicalData.length >= 7 
      ? historicalData[historicalData.length - 7] 
      : historicalData[0];
    
    const sevenDayChange = sevenDaysAgo 
      ? ((currentPrice - (sevenDaysAgo.price || sevenDaysAgo.usd_price)) / (sevenDaysAgo.price || sevenDaysAgo.usd_price)) * 100
      : 0;

    // Get 30-day old price (first record)
    const thirtyDaysAgo = historicalData[0];
    const thirtyDayChange = thirtyDaysAgo
      ? ((currentPrice - (thirtyDaysAgo.price || thirtyDaysAgo.usd_price)) / (thirtyDaysAgo.price || thirtyDaysAgo.usd_price)) * 100
      : 0;

    return {
      sevenDay: sevenDayChange,
      thirtyDay: thirtyDayChange
    };
  };

  useEffect(() => {
    fetchMarketData();
  }, []);

  return { 
    marketData, 
    mbarePrices, 
    loading, 
    error, 
    refetch: fetchMarketData,
    fetchHistoricalData,
    calculateTrends
  };
};
