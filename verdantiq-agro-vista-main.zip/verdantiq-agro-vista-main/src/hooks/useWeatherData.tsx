
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface UseWeatherDataParams {
  region?: string;
  latitude?: number;
  longitude?: number;
}

export const useWeatherData = (params?: UseWeatherDataParams | string) => {
  const [weatherData, setWeatherData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Support both old string param and new object param for backwards compatibility
  const queryParams = typeof params === 'string' ? { region: params } : params || {};

  const fetchWeatherData = async (customParams?: UseWeatherDataParams) => {
    const body = customParams || queryParams;
    // Skip when no usable location is provided — prevents silent fallback to Harare.
    const hasCoords = body.latitude != null && body.longitude != null;
    if (!hasCoords && !body.region) {
      setWeatherData([]);
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const { data, error } = await supabase.functions.invoke('weather-data', { body });
      if (error) throw error;
      setWeatherData(data.data || []);
    } catch (err: any) {
      setError(err.message);
      console.error('Weather data fetch error:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchForecast = async (region?: string, latitude?: number, longitude?: number) => {
    try {
      const body = {
        region: region || queryParams.region,
        latitude: latitude || queryParams.latitude,
        longitude: longitude || queryParams.longitude,
        forecast: true // Request forecast data
      };

      const { data, error } = await supabase.functions.invoke('weather-data', {
        body
      });

      if (error) throw error;

      return data?.forecast || [];
    } catch (err: any) {
      console.error('Forecast fetch error:', err);
      return [];
    }
  };

  useEffect(() => {
    fetchWeatherData();
  }, [queryParams.region, queryParams.latitude, queryParams.longitude]);

  return { 
    weatherData, 
    loading, 
    error, 
    refetch: fetchWeatherData,
    fetchForecast
  };
};
