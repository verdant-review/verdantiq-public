import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

export interface FarmLocation {
  farmId: string | null;
  farmName: string | null;
  latitude: number | null;
  longitude: number | null;
  region: string | null;
  loading: boolean;
  hasLocation: boolean;
}

/**
 * Resolves the authenticated user's primary farm location for weather queries.
 * Returns farm coordinates as the single source of truth — no hardcoded city fallback.
 */
export const useFarmLocation = (): FarmLocation => {
  const { user } = useAuth();
  const [state, setState] = useState<Omit<FarmLocation, "hasLocation">>({
    farmId: null,
    farmName: null,
    latitude: null,
    longitude: null,
    region: null,
    loading: true,
  });

  useEffect(() => {
    if (!user) {
      setState((s) => ({ ...s, loading: false }));
      return;
    }

    let cancelled = false;
    (async () => {
      const { data } = await (supabase as any)
        .from("farms")
        .select("id, name, latitude, longitude, location")
        .eq("user_id", user.id)
        .order("created_at", { ascending: true })
        .limit(1)
        .maybeSingle();

      if (cancelled) return;

      if (data) {
        setState({
          farmId: data.id,
          farmName: data.name,
          latitude: data.latitude != null ? Number(data.latitude) : null,
          longitude: data.longitude != null ? Number(data.longitude) : null,
          region: data.location ?? null,
          loading: false,
        });
      } else {
        setState((s) => ({ ...s, loading: false }));
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [user?.id]);

  return {
    ...state,
    hasLocation: state.latitude != null && state.longitude != null,
  };
};
