
import React, { useState, useEffect, createContext, useContext } from "react";
import { User, Session } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";

interface AuthContextType {
  user: User | null;
  session: Session | null;
  loading: boolean;
  profile: any;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [profile, setProfile] = useState(null);

  // Ensure children is valid React node
  if (!React.isValidElement(children) && typeof children !== 'string' && typeof children !== 'number' && !Array.isArray(children) && children !== null && children !== undefined) {
    console.error("AuthProvider: Invalid children prop", typeof children, children);
    return null;
  }

  const fetchProfile = async (userId: string) => {
    try {
      console.log("Fetching profile for user:", userId);
      const { data: profileData, error } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", userId)
        .single();
      
      if (error) {
        console.error("Error fetching profile:", error);
        // Don't set profile to null if user doesn't have a profile yet
        // This allows the app to continue loading
        if (error.code !== 'PGRST116') { // PGRST116 is "not found"
          setProfile(null);
        }
      } else {
        console.log("Profile fetched successfully:", profileData);
        setProfile(profileData);
      }
    } catch (error) {
      console.error("Error fetching profile:", error);
      setProfile(null);
    }
  };

  useEffect(() => {
    let mounted = true;
    console.log("Auth provider mounting...");

    // Track the last user id we fetched a profile for so we don't refetch on every
    // TOKEN_REFRESHED event (which fires on tab refocus and would cause UI thrash).
    let lastProfileUserId: string | null = null;

    // Set up auth state listener first
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        console.log("Auth state changed:", event, session?.user?.id);

        if (!mounted) return;

        try {
          const nextUserId = session?.user?.id ?? null;

          setSession(session);
          setUser(session?.user ?? null);

          // Only fetch profile when the user actually changes (sign-in / sign-out / switch).
          // TOKEN_REFRESHED with the same user must NOT trigger a refetch — that's what
          // caused the full-page spinner every time the tab regained focus.
          if (nextUserId && nextUserId !== lastProfileUserId) {
            lastProfileUserId = nextUserId;
            setTimeout(() => {
              if (mounted) fetchProfile(nextUserId);
            }, 0);
          } else if (!nextUserId) {
            lastProfileUserId = null;
            setProfile(null);
          }

          // Loading is only meaningful for the very first auth resolution.
          setLoading(false);
        } catch (error) {
          console.error("Error in auth state change handler:", error);
          if (mounted) setLoading(false);
        }
      }
    );

    // Check for existing session
    const initializeAuth = async () => {
      try {
        console.log("Checking for existing session...");
        const { data: { session }, error } = await supabase.auth.getSession();
        
        if (error) {
          console.error("Error getting session:", error);
          if (mounted) {
            setLoading(false);
          }
          return;
        }
        
        console.log("Existing session found:", !!session);
        
        if (!mounted) return;
        
        // Only set state if we don't already have a session from the listener
        if (!session) {
          setSession(null);
          setUser(null);
          setProfile(null);
          setLoading(false);
        }
      } catch (error) {
        console.error("Error initializing auth:", error);
        if (mounted) {
          setLoading(false);
        }
      }
    };

    initializeAuth();

    // Cleanup function
    return () => {
      console.log("Auth provider unmounting...");
      mounted = false;
      subscription.unsubscribe();
    };
  }, []);

  const signOut = async () => {
    console.log("Signing out...");
    setLoading(true);
    try {
      await supabase.auth.signOut();
    } catch (error) {
      console.error("Error signing out:", error);
    } finally {
      setLoading(false);
    }
  };

  const contextValue = {
    user,
    session,
    loading,
    profile,
    signOut
  };

  return (
    <AuthContext.Provider value={contextValue}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  
  // Add debugging to check context integrity
  if (typeof context.signOut !== 'function') {
    console.error("signOut is not a function:", context.signOut);
    throw new Error("Auth context is corrupted: signOut is not a function");
  }
  
  return context;
};
