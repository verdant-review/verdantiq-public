
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";

interface AIInteraction {
  id: string;
  user_message: string;
  ai_response: string;
  context_data?: any;
  feedback_rating?: number;
  feedback_comment?: string;
  created_at: string;
}

export const useAIInteractions = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isLogging, setIsLogging] = useState(false);

  const logInteraction = async (
    userMessage: string,
    aiResponse: string,
    contextData?: any,
    sessionId?: string
  ) => {
    if (!user) return null;

    setIsLogging(true);
    try {
      const { data, error } = await supabase
        .from('ai_interactions')
        .insert({
          user_id: user.id,
          session_id: sessionId || crypto.randomUUID(),
          user_message: userMessage,
          ai_response: aiResponse,
          context_data: contextData
        })
        .select()
        .single();

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error logging AI interaction:', error);
      toast({
        title: "Logging Error",
        description: "Failed to log interaction for training",
        variant: "destructive"
      });
      return null;
    } finally {
      setIsLogging(false);
    }
  };

  const updateFeedback = async (
    interactionId: string,
    rating: number,
    comment?: string
  ) => {
    if (!user) return false;

    try {
      const { error } = await supabase
        .from('ai_interactions')
        .update({
          feedback_rating: rating,
          feedback_comment: comment,
          updated_at: new Date().toISOString()
        })
        .eq('id', interactionId)
        .eq('user_id', user.id);

      if (error) throw error;
      
      toast({
        title: "Feedback Saved",
        description: "Thank you for helping improve our AI!",
      });
      return true;
    } catch (error) {
      console.error('Error updating feedback:', error);
      toast({
        title: "Feedback Error",
        description: "Failed to save feedback",
        variant: "destructive"
      });
      return false;
    }
  };

  const getUserInteractions = async () => {
    if (!user) return [];

    try {
      const { data, error } = await supabase
        .from('ai_interactions')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data as AIInteraction[];
    } catch (error) {
      console.error('Error fetching interactions:', error);
      return [];
    }
  };

  return {
    logInteraction,
    updateFeedback,
    getUserInteractions,
    isLogging
  };
};
