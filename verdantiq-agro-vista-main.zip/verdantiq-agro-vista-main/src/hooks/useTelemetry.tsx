import { useEffect, useRef } from "react";
import { useLocation } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

interface QueuedEvent {
  user_id: string | null;
  event_name: string;
  properties: Record<string, any>;
  page_route: string;
}

const queue: QueuedEvent[] = [];
let flushTimer: ReturnType<typeof setTimeout> | null = null;
const FLUSH_INTERVAL = 10_000;
const FLUSH_BATCH = 20;

const flush = async () => {
  if (queue.length === 0) return;
  const batch = queue.splice(0, queue.length);
  try {
    await supabase.from("usage_events").insert(batch);
  } catch (e) {
    // swallow — telemetry must never break the app
  }
};

const scheduleFlush = () => {
  if (flushTimer) return;
  flushTimer = setTimeout(() => {
    flushTimer = null;
    flush();
  }, FLUSH_INTERVAL);
};

export const trackEvent = (
  event_name: string,
  properties: Record<string, any> = {},
  user_id: string | null = null,
  page_route: string = typeof window !== "undefined" ? window.location.pathname : "",
) => {
  if (!event_name || event_name.length > 100) return;
  // Strip obviously sensitive keys
  const safeProps: Record<string, any> = {};
  for (const [k, v] of Object.entries(properties)) {
    if (/password|token|secret|email|phone/i.test(k)) continue;
    safeProps[k] = v;
  }
  queue.push({ user_id, event_name, properties: safeProps, page_route });
  if (queue.length >= FLUSH_BATCH) {
    flush();
  } else {
    scheduleFlush();
  }
};

export const useTelemetry = () => {
  const { user } = useAuth();
  const location = useLocation();
  const lastRoute = useRef<string>("");

  useEffect(() => {
    if (location.pathname === lastRoute.current) return;
    lastRoute.current = location.pathname;
    trackEvent("page_view", { search: location.search }, user?.id ?? null, location.pathname);
  }, [location.pathname, location.search, user?.id]);

  // Flush on tab close
  useEffect(() => {
    const handler = () => flush();
    window.addEventListener("beforeunload", handler);
    return () => window.removeEventListener("beforeunload", handler);
  }, []);

  return {
    track: (name: string, props: Record<string, any> = {}) =>
      trackEvent(name, props, user?.id ?? null, location.pathname),
  };
};
