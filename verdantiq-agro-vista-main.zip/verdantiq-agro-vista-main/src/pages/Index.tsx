import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Sprout, Tractor, BarChart3, Cloud, MessageCircle, ArrowRight, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import Navigation from "@/components/Navigation";
import MarketPrices from "@/components/MarketPrices";
import SupplyGapAnalysis from "@/components/SupplyGapAnalysis";
import WeatherModule from "@/components/WeatherModule";
import YieldPrediction from "@/components/YieldPrediction";
import AIAgronomist from "@/components/AIAgronomist";
import AuthPage from "@/components/AuthPage";
import { useAuth } from "@/hooks/useAuth";

// VerdantIQ / Mudhumeni Hungwe WhatsApp number
export const WHATSAPP_NUMBER = "+263775919996";
const WHATSAPP_LINK = "https://wa.me/263775919996";
const VALIDATION_PDF = "https://drive.google.com/file/d/1nOyDNHOQko-t_yzkk2-04gD46vEkh8s5/view?usp=sharing";
const DEMO_QUERY_LIMIT = 2;

const Index = () => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("dashboard");
  const [showAuthModal, setShowAuthModal] = useState(false);

  // Mudhumeni live demo state (in-memory rate limit)
  const [demoInput, setDemoInput] = useState("");
  const [demoAnswer, setDemoAnswer] = useState<string | null>(null);
  const [demoLoading, setDemoLoading] = useState(false);
  const [demoError, setDemoError] = useState<string | null>(null);
  const [demoCount, setDemoCount] = useState(0);

  // Notify-me dialog state
  const [notifyOpen, setNotifyOpen] = useState(false);
  const [notifyEmail, setNotifyEmail] = useState("");

  const mudhumeniRef = useRef<HTMLDivElement>(null);

  const scrollToMudhumeni = () => {
    mudhumeniRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const handleAskMudhumeni = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!demoInput.trim() || demoLoading) return;
    if (demoCount >= DEMO_QUERY_LIMIT) return;

    setDemoLoading(true);
    setDemoError(null);
    setDemoAnswer(null);

    try {
      const { data, error } = await supabase.functions.invoke("ai-agronomist", {
        body: { message: demoInput.trim(), channel: "web" },
      });
      if (error) throw error;
      const answer = (data as any)?.message || (data as any)?.response || (data as any)?.reply;
      if (!answer) throw new Error("Empty response");
      setDemoAnswer(answer);
      setDemoCount((c) => c + 1);
      setDemoInput("");
    } catch (err) {
      console.error("Mudhumeni demo error:", err);
      setDemoError("Mudhumeni is resting. Please try again in a moment.");
    } finally {
      setDemoLoading(false);
    }
  };

  const handleNotifySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!notifyEmail.trim()) return;
    // TODO: wire to a real notification endpoint
    toast.success("You're on the list. We'll email you when v2 ships.");
    setNotifyEmail("");
    setNotifyOpen(false);
  };

  // Sub-tab routing — preserved as-is
  const renderContent = () => {
    switch (activeTab) {
      case "market-prices":
        return <MarketPrices />;
      case "supply-analysis":
        return <SupplyGapAnalysis />;
      case "weather":
        return <WeatherModule />;
      case "yield-prediction":
        return <YieldPrediction />;
      case "ai-agronomist":
        return user ? (
          <AIAgronomist />
        ) : (
          <div className="text-center py-12">
            <MessageCircle className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-xl font-semibold mb-2">AI Agronomist Requires Account</h3>
            <p className="text-muted-foreground mb-4">
              Get personalized farming advice from Mudhumeni Hungwe.
            </p>
            <Button onClick={() => setShowAuthModal(true)}>Sign In to Access AI Agronomist</Button>
          </div>
        );
      default:
        return null;
    }
  };

  // When a sub-tab is active, render it inside the regular shell (light app chrome).
  if (activeTab !== "dashboard") {
    return (
      <div className="min-h-screen bg-background">
        <Navigation activeTab={activeTab} onTabChange={setActiveTab} />
        <main className="container mx-auto px-4 py-8">{renderContent()}</main>
        {showAuthModal && (
          <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
            <div className="bg-background rounded-lg max-w-md w-full">
              <AuthPage onAuthSuccess={() => setShowAuthModal(false)} />
            </div>
          </div>
        )}
      </div>
    );
  }

  // Landing view — dark, typographic, SpaceX-tone
  const bgDark = "hsl(155, 25%, 8%)";
  const bgElevated = "hsl(155, 20%, 12%)";
  const fg = "hsl(60, 9%, 96%)";
  const fgMuted = "hsl(150, 8%, 65%)";
  const brandGreen = "hsl(142, 70%, 45%)";
  const amber = "hsl(38, 92%, 60%)";

  return (
    <div style={{ backgroundColor: bgDark, color: fg }} className="min-h-screen">
      <Navigation activeTab={activeTab} onTabChange={setActiveTab} />

      {/* SECTION 1 — Mission Hero */}
      <section className="min-h-screen flex flex-col items-center justify-center px-6 py-24 text-center relative">
        {/* TODO: full-bleed photograph of Zimbabwean farmer */}
        <h1 className="text-6xl md:text-7xl lg:text-8xl font-bold tracking-tight max-w-5xl">
          From Earth to Enterprise.
        </h1>
        <p
          className="mt-8 text-lg md:text-xl leading-relaxed max-w-2xl"
          style={{ color: fgMuted }}
        >
          Africa's agricultural operating system. Built in Zimbabwe. Engineered for the continent.
        </p>
        <Button
          onClick={scrollToMudhumeni}
          size="lg"
          className="mt-12 text-base px-8 py-6 h-auto rounded-full font-medium border-0"
          style={{ backgroundColor: brandGreen, color: bgDark }}
        >
          See VerdantIQ in action
        </Button>
        <p className="mt-12 text-xs tracking-widest uppercase" style={{ color: fgMuted }}>
          A product of Zyterra.
        </p>
      </section>

      {/* SECTION 2 — Mudhumeni live */}
      <section
        id="mudhumeni-live"
        ref={mudhumeniRef}
        className="py-24 md:py-32 px-6"
        style={{ backgroundColor: bgElevated }}
      >
        <div className="max-w-4xl mx-auto">
          <p
            className="text-xs uppercase tracking-widest font-semibold mb-6"
            style={{ color: brandGreen }}
          >
            The AI Agronomist
          </p>
          <h2 className="text-5xl md:text-6xl font-bold tracking-tight mb-8">
            Meet Mudhumeni Hungwe.
          </h2>
          <p className="text-lg md:text-xl leading-relaxed max-w-3xl mb-12" style={{ color: fgMuted }}>
            Your agronomist on call. Trained on Zimbabwean farming. Fluent in crop science,
            livestock health, and the practical realities of smallholder agriculture. Ask
            Mudhumeni Hungwe a question — in English, Shona, Ndebele — and get a specific,
            actionable answer. On the web, on WhatsApp, day or night.
          </p>

          {demoCount >= DEMO_QUERY_LIMIT ? (
            <div
              className="rounded-2xl p-8 border"
              style={{ backgroundColor: bgDark, borderColor: "hsl(155, 15%, 18%)" }}
            >
              <p className="text-lg mb-6">
                You've reached the homepage demo limit. Sign up to keep the conversation going.
              </p>
              <Button
                onClick={() => setShowAuthModal(true)}
                size="lg"
                className="rounded-full px-8 border-0"
                style={{ backgroundColor: brandGreen, color: bgDark }}
              >
                Sign up to keep the conversation going
              </Button>
            </div>
          ) : (
            <form onSubmit={handleAskMudhumeni} className="flex flex-col sm:flex-row gap-3">
              <Input
                value={demoInput}
                onChange={(e) => setDemoInput(e.target.value)}
                placeholder='Try: "My maize leaves are yellowing at the tips" or "When should I dip my cattle?"'
                disabled={demoLoading}
                className="flex-1 h-14 text-base rounded-full px-6 border"
                style={{
                  backgroundColor: bgDark,
                  borderColor: "hsl(155, 15%, 18%)",
                  color: fg,
                }}
              />
              <Button
                type="submit"
                disabled={demoLoading || !demoInput.trim()}
                size="lg"
                className="h-14 rounded-full px-8 border-0 font-medium"
                style={{ backgroundColor: brandGreen, color: bgDark }}
              >
                {demoLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Ask Mudhumeni"}
              </Button>
            </form>
          )}

          {/* Loading skeleton */}
          {demoLoading && (
            <div
              className="mt-8 rounded-2xl p-8 border animate-pulse"
              style={{ backgroundColor: bgDark, borderColor: "hsl(155, 15%, 18%)" }}
            >
              <div className="text-sm mb-4" style={{ color: fgMuted }}>
                Mudhumeni is thinking…
              </div>
              <div className="space-y-3">
                <div className="h-3 rounded w-full" style={{ backgroundColor: "hsl(155, 15%, 18%)" }} />
                <div className="h-3 rounded w-5/6" style={{ backgroundColor: "hsl(155, 15%, 18%)" }} />
                <div className="h-3 rounded w-4/6" style={{ backgroundColor: "hsl(155, 15%, 18%)" }} />
              </div>
            </div>
          )}

          {/* Error */}
          {demoError && !demoLoading && (
            <p className="mt-6 text-sm" style={{ color: fgMuted }}>
              {demoError}
            </p>
          )}

          {/* Answer */}
          {demoAnswer && !demoLoading && (
            <div
              className="mt-8 rounded-2xl p-8 border"
              style={{ backgroundColor: bgDark, borderColor: "hsl(155, 15%, 18%)" }}
            >
              <div
                className="text-xs uppercase tracking-widest mb-4 font-semibold"
                style={{ color: brandGreen }}
              >
                Mudhumeni Hungwe · VerdantIQ AI Agronomist
              </div>
              <div className="text-base md:text-lg leading-relaxed whitespace-pre-wrap">
                {demoAnswer}
              </div>
            </div>
          )}

          <a
            href={WHATSAPP_LINK}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 mt-12 text-base hover:underline"
            style={{ color: brandGreen }}
          >
            Already a farmer? → Chat on WhatsApp
          </a>
        </div>
      </section>

      {/* SECTION 3 — The 32.74% moment */}
      <section className="py-24 md:py-32 px-6" style={{ backgroundColor: bgDark }}>
        <div className="max-w-4xl mx-auto">
          <p
            className="text-xs uppercase tracking-widest font-semibold mb-6"
            style={{ color: amber }}
          >
            A note on honesty.
          </p>
          <h2 className="text-5xl md:text-6xl font-bold tracking-tight mb-8">
            Our first yield model was{" "}
            <span style={{ color: amber }}>32.74% wrong.</span>
          </h2>
          <p className="text-lg md:text-xl leading-relaxed mb-10" style={{ color: fgMuted }}>
            When we validated v1 of our yield prediction engine against real data from 2014 to
            2024, the Mean Absolute Percentage Error was 32.74%. That is not good enough. Not for
            us. Not for Zimbabwe. We published the full validation report. We're rebuilding v2
            from the ground up — integrating climate shocks, hybrid machine-learning, and
            continuous retraining. Because Zimbabwe's food security deserves the truth, not a
            comfortable lie.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <a href={VALIDATION_PDF} target="_blank" rel="noopener noreferrer">
              <Button
                size="lg"
                className="rounded-full px-8 border-0 font-medium w-full sm:w-auto"
                style={{ backgroundColor: brandGreen, color: bgDark }}
              >
                Read the validation report
              </Button>
            </a>
            <Dialog open={notifyOpen} onOpenChange={setNotifyOpen}>
              <DialogTrigger asChild>
                <Button
                  size="lg"
                  variant="outline"
                  className="rounded-full px-8 font-medium w-full sm:w-auto bg-transparent"
                  style={{ borderColor: "hsl(155, 15%, 28%)", color: fg }}
                >
                  Notify me when v2 launches
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Get notified when v2 launches</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleNotifySubmit} className="space-y-4 pt-2">
                  <div>
                    <Label htmlFor="notify-email">Email</Label>
                    <Input
                      id="notify-email"
                      type="email"
                      required
                      value={notifyEmail}
                      onChange={(e) => setNotifyEmail(e.target.value)}
                      placeholder="you@farm.co.zw"
                    />
                  </div>
                  <Button type="submit" className="w-full">
                    Notify me
                  </Button>
                </form>
              </DialogContent>
            </Dialog>
          </div>
          <p className="mt-8 text-sm" style={{ color: fgMuted }}>
            Methodology: MAPE computed against FAO, USDA, and ZIMSTAT yield data across eight
            crops, 2014–2022.
          </p>
        </div>
      </section>

      {/* SECTION 4 — The vehicle lineup */}
      <section className="py-24 md:py-32 px-6" style={{ backgroundColor: bgElevated }}>
        <div className="max-w-6xl mx-auto">
          <p
            className="text-xs uppercase tracking-widest font-semibold mb-6"
            style={{ color: brandGreen }}
          >
            What ships today.
          </p>
          <h2 className="text-5xl md:text-6xl font-bold tracking-tight mb-6">
            Five systems. One platform.
          </h2>
          <p className="text-lg md:text-xl leading-relaxed max-w-3xl mb-16" style={{ color: fgMuted }}>
            Every capability below is live, in production, and in the hands of real farmers. What
            you see is what runs.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                icon: MessageCircle,
                title: "Mudhumeni Hungwe — AI Agronomist",
                body: "Vision-capable. Trained on Zimbabwean agronomy, from maize planting windows to cattle vaccination calendars. Available on web and WhatsApp.",
                tab: "ai-agronomist",
                requiresAuth: true,
              },
              {
                icon: Sprout,
                title: "VerdantOS — Farm Management",
                body: "Your farm, in one system. Crop cycles, cycle tasks, soil tests, livestock herds, equipment, and farm boundaries — all tracked, all analysable, all yours.",
                tab: "my-farm",
                requiresAuth: true,
              },
              {
                icon: BarChart3,
                title: "Market Intelligence",
                body: "Verified Mbare Musika prices with a full audit trail, historical trends, and province-by-province breakdowns. Because the farmer who knows the market price is the farmer who keeps the margin.",
                tab: "market-prices",
                requiresAuth: false,
              },
              {
                icon: Cloud,
                title: "Weather Module",
                body: "Seven-day forecasts, rainfall anomaly alerts, and location-aware advisories. Because the weather is no longer what it was, and pretending otherwise costs harvests.",
                tab: "weather",
                requiresAuth: false,
              },
              {
                icon: Tractor,
                title: "WhatsApp Daily",
                body: "Every morning, a digest on your phone. Prices, weather, farming tips, in your language. The rural access layer — because not every farmer has a smartphone browser, but every farmer has WhatsApp.",
                tab: "my-farm",
                requiresAuth: true,
              },
            ].map(({ icon: Icon, title, body, tab, requiresAuth }) => (
              <button
                key={title}
                onClick={() => {
                  if (requiresAuth && !user) {
                    setShowAuthModal(true);
                  } else {
                    setActiveTab(tab);
                  }
                }}
                className="text-left rounded-2xl p-8 border transition-colors group hover:border-current"
                style={{
                  backgroundColor: bgDark,
                  borderColor: "hsl(155, 15%, 18%)",
                  color: fg,
                }}
              >
                <Icon className="h-7 w-7 mb-6" style={{ color: brandGreen }} />
                <h3 className="text-xl font-semibold mb-3" style={{ color: brandGreen }}>
                  {title}
                </h3>
                <p className="text-base leading-relaxed mb-6" style={{ color: fgMuted }}>
                  {body}
                </p>
                <span
                  className="inline-flex items-center gap-1 text-sm font-medium"
                  style={{ color: brandGreen }}
                >
                  Explore <ArrowRight className="h-4 w-4" />
                </span>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* SECTION 5 — The mission */}
      <section className="py-24 md:py-32 px-6" style={{ backgroundColor: bgDark }}>
        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-12">
          <div className="hidden md:block" />
          <div className="md:col-span-2">
            <p
              className="text-xs uppercase tracking-widest font-semibold mb-6"
              style={{ color: brandGreen }}
            >
              Why we are building this.
            </p>
            <h2 className="text-5xl md:text-6xl font-bold tracking-tight mb-10">
              Africa does not have a food problem. It has a coordination problem.
            </h2>
            <div className="space-y-6 text-lg md:text-xl leading-relaxed" style={{ color: fgMuted }}>
              <p>
                Africa grows enough food to feed itself. What it lacks is the infrastructure — the
                intelligence layer — to move knowledge, prices, forecasts, and capital between the
                farmer and the market, fast enough and accurately enough to matter.
              </p>
              <p>
                That is what we are building. Not an app. Not a marketplace. A nervous system. A
                continent-scale agricultural operating system that turns every smallholder farm
                into a data-rich, market-connected, intelligence-augmented enterprise.
              </p>
              <p>
                Zimbabwe is where we start. The continent is where we go. Zero hunger is the
                outcome. From Earth to Enterprise is the arc.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 6 — Honest progress */}
      <section className="py-24 md:py-32 px-6" style={{ backgroundColor: bgElevated }}>
        <div className="max-w-6xl mx-auto">
          <p
            className="text-xs uppercase tracking-widest font-semibold mb-6"
            style={{ color: brandGreen }}
          >
            The roadmap, in public.
          </p>
          <h2 className="text-5xl md:text-6xl font-bold tracking-tight mb-16">
            What's live. What's next. What's on the horizon.
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {[
              {
                heading: "Live today.",
                items: [
                  "AI Agronomist (Mudhumeni Hungwe)",
                  "Farm management (VerdantOS)",
                  "Livestock intelligence",
                  "Market prices (verified Mbare Musika)",
                  "Weather module",
                  "WhatsApp integration",
                  "Mechanization scoring",
                ],
                color: brandGreen,
              },
              {
                heading: "Shipping Q3 2026.",
                items: [
                  "Yield Prediction Engine v2",
                  "Supply Gap Analysis (pilot)",
                  "Cold chain coordination",
                ],
                color: amber,
              },
              {
                heading: "On the multi-year horizon.",
                items: [
                  "Farm-level digital twin",
                  "Blockchain traceability (field to export)",
                  "Continental price and supply network",
                ],
                color: fgMuted,
              },
            ].map((col) => (
              <div key={col.heading}>
                <h3
                  className="text-xl font-semibold mb-6 tracking-tight"
                  style={{ color: col.color }}
                >
                  {col.heading}
                </h3>
                <ul className="space-y-3">
                  {col.items.map((item) => (
                    <li key={item} className="text-base leading-relaxed" style={{ color: fg }}>
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SECTION 7 — Find your door */}
      <section className="py-24 md:py-32 px-6" style={{ backgroundColor: bgDark }}>
        <div className="max-w-6xl mx-auto">
          <h2 className="text-5xl md:text-6xl font-bold tracking-tight mb-16">Find your door.</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                label: "Farmer",
                copy: "Start today. Chat with Mudhumeni on WhatsApp — no signup required.",
                cta: "Start on WhatsApp",
                href: WHATSAPP_LINK,
              },
              {
                label: "Government",
                copy: "Zimbabwe's food security is a policy problem with a technology answer. Let us show you what an agricultural OS looks like at national scale.",
                cta: "Book a briefing",
                href: "mailto:hello@zyterra.co.zw?subject=Government%20briefing",
              },
              {
                label: "Partner",
                copy: "We're building the rails. If you're a cooperative, offtaker, or logistics operator, let's connect.",
                cta: "Partner with us",
                href: "mailto:hello@zyterra.co.zw?subject=Partnership",
              },
              {
                label: "Investor",
                copy: "We're raising to scale VerdantIQ across Southern Africa. Request access to our data room.",
                cta: "Request the data room",
                href: "mailto:hello@zyterra.co.zw?subject=Investor%20data%20room",
              },
            ].map(({ label, copy, cta, href }) => (
              <a
                key={label}
                href={href}
                target={href.startsWith("http") ? "_blank" : undefined}
                rel="noopener noreferrer"
                className="rounded-2xl p-8 border block hover:border-current transition-colors"
                style={{ backgroundColor: bgElevated, borderColor: "hsl(155, 15%, 18%)" }}
              >
                <div className="text-2xl font-semibold mb-4" style={{ color: brandGreen }}>
                  {label}
                </div>
                <p className="text-base leading-relaxed mb-8" style={{ color: fgMuted }}>
                  {copy}
                </p>
                <span
                  className="inline-flex items-center gap-1 text-sm font-medium"
                  style={{ color: brandGreen }}
                >
                  {cta} <ArrowRight className="h-4 w-4" />
                </span>
              </a>
            ))}
          </div>
        </div>
      </section>

      {/* SECTION 8 — Footer */}
      <footer
        className="py-12 px-6 border-t"
        style={{ backgroundColor: bgDark, borderColor: "hsl(155, 15%, 18%)" }}
      >
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between gap-8">
          <div>
            <div className="text-xl font-bold tracking-tight">VerdantIQ</div>
            <p className="text-sm mt-2" style={{ color: fgMuted }}>
              A product of Zyterra. From Earth to Enterprise.
            </p>
          </div>
          <div className="flex flex-wrap gap-6 md:gap-8 items-start">
            <a
              href={VALIDATION_PDF}
              target="_blank"
              rel="noopener noreferrer"
              className="text-sm hover:underline"
              style={{ color: fgMuted }}
            >
              Validation Report
            </a>
            <a
              href="/privacy"
              className="text-sm hover:underline"
              style={{ color: fgMuted }}
            >
              Privacy Policy
            </a>
            <a
              href="/terms"
              className="text-sm hover:underline"
              style={{ color: fgMuted }}
            >
              Terms of Use
            </a>
            <a
              href="/status"
              className="text-sm hover:underline"
              style={{ color: fgMuted }}
            >
              System Status
            </a>
            <a
              href="mailto:hello@zyterra.co.zw"
              className="text-sm hover:underline"
              style={{ color: fgMuted }}
            >
              Contact
            </a>
          </div>
        </div>
        <div className="max-w-6xl mx-auto mt-8 text-xs" style={{ color: fgMuted }}>
          © 2026 Zyterra. Harare, Zimbabwe.
        </div>
      </footer>

      {showAuthModal && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-background rounded-lg max-w-md w-full">
            <AuthPage onAuthSuccess={() => setShowAuthModal(false)} />
          </div>
        </div>
      )}
    </div>
  );
};

export default Index;
