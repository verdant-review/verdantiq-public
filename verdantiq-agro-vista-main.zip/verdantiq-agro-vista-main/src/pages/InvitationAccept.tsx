import React, { useEffect, useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2, CheckCircle2 } from "lucide-react";
import { toast } from "@/hooks/use-toast";

interface Invite {
  id: string;
  scheme_id: string;
  status: string;
  expires_at: string;
  farmer_name: string | null;
}

const InvitationAccept: React.FC = () => {
  const { token } = useParams<{ token: string }>();
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();
  const [invite, setInvite] = useState<Invite | null>(null);
  const [schemeName, setSchemeName] = useState<string>("");
  const [orgName, setOrgName] = useState<string>("");
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [accepted, setAccepted] = useState(false);

  useEffect(() => {
    if (!token) return;
    (async () => {
      const { data, error } = await supabase.functions.invoke("scheme-invite-preview", { body: { token } });
      if (!error && data && !(data as any).error) {
        const d = data as any;
        setInvite(d.invite as Invite);
        setSchemeName(d.scheme?.name || "");
        setOrgName(d.organization?.name || "");
      }
      setLoading(false);
    })();
  }, [token]);

  const accept = async () => {
    if (!token) return;
    setBusy(true);
    const { data, error } = await supabase.functions.invoke("scheme-invite-accept", { body: { token } });
    setBusy(false);
    if (error || (data as any)?.error) {
      toast({ title: "Could not accept", description: error?.message || (data as any)?.error, variant: "destructive" });
      return;
    }
    setAccepted(true);
    toast({ title: "You're enrolled!" });
  };

  if (loading || authLoading) {
    return <div className="min-h-screen flex items-center justify-center"><Loader2 className="h-6 w-6 animate-spin" /></div>;
  }

  if (!invite) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <Card className="max-w-md">
          <CardHeader><CardTitle>Invitation not found</CardTitle></CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">This invitation link is invalid.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const expired = new Date(invite.expires_at) < new Date();
  const used = invite.status !== "pending";

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-gradient-to-br from-green-50 to-yellow-50">
      <Card className="max-w-md w-full">
        <CardHeader>
          <CardTitle>Join {schemeName}</CardTitle>
          <p className="text-sm text-muted-foreground">{orgName} has invited you to enroll.</p>
        </CardHeader>
        <CardContent className="space-y-4">
          {accepted ? (
            <div className="text-center space-y-3">
              <CheckCircle2 className="h-12 w-12 text-green-600 mx-auto" />
              <p className="font-medium">You're enrolled in {schemeName}.</p>
              <Button asChild><Link to="/my-farm">Go to my farm</Link></Button>
            </div>
          ) : expired ? (
            <p className="text-sm text-destructive">This invitation has expired. Ask the organization to send a new one.</p>
          ) : used ? (
            <p className="text-sm text-muted-foreground">This invitation has already been {invite.status}.</p>
          ) : !user ? (
            <>
              <p className="text-sm">Sign in or create a farmer account to accept this invitation.</p>
              <Button asChild className="w-full">
                <Link to={`/auth?redirect=/invite/${token}`}>Sign in to accept</Link>
              </Button>
            </>
          ) : (
            <Button onClick={accept} disabled={busy} className="w-full">
              {busy && <Loader2 className="h-4 w-4 mr-1 animate-spin" />}
              Accept invitation
            </Button>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default InvitationAccept;
