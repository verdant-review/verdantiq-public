import { Link } from "react-router-dom";

const Terms = () => {
  const bgDark = "hsl(155, 25%, 8%)";
  const fgMuted = "hsl(150, 10%, 70%)";

  return (
    <div className="min-h-screen" style={{ backgroundColor: bgDark, color: "hsl(150, 10%, 95%)" }}>
      <header className="border-b" style={{ borderColor: "hsl(155, 15%, 18%)" }}>
        <div className="max-w-4xl mx-auto px-6 py-6 flex items-center justify-between">
          <Link to="/" className="text-xl font-bold tracking-tight">VerdantIQ</Link>
          <Link to="/privacy" className="text-sm hover:underline" style={{ color: fgMuted }}>
            ← Privacy Policy
          </Link>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-6 py-12">
        <h1 className="text-4xl font-bold mb-2">Terms of Use</h1>
        <p className="text-sm mb-10" style={{ color: fgMuted }}>
          Last updated: 29 April 2026 • Effective immediately
        </p>

        <div className="space-y-8 text-base leading-relaxed">
          <section className="p-4 rounded-md border" style={{ borderColor: "hsl(45, 90%, 50%)", backgroundColor: "hsl(45, 60%, 12%)" }}>
            <p className="font-semibold uppercase tracking-wide text-sm mb-2" style={{ color: "hsl(45, 90%, 65%)" }}>
              Important — Please read carefully
            </p>
            <p className="text-sm">
              These Terms contain (a) an <strong>AI accuracy disclaimer</strong>, (b) a
              <strong> limitation of liability</strong>, (c) an <strong>indemnification</strong>
              {" "}clause where you agree to hold us harmless for losses arising from your use of
              the Service, and (d) a <strong>governing-law</strong> clause selecting Zimbabwean
              law. By using VerdantIQ you confirm you have read and accept these terms.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-3">1. Acceptance of terms</h2>
            <p>
              These Terms of Use ("Terms") form a binding agreement between you ("you", "User")
              and <strong>Zyvatek Food Systems and Logistics (Private) Limited</strong>, trading as <strong>Zyterra</strong> ("Zyterra", "we", "us"), the
              operator of the VerdantIQ platform, the Mudhumeni Hungwe AI agronomist, and any
              related WhatsApp, web, or mobile interfaces (the "Service"). By creating an
              account, messaging our WhatsApp bot, or otherwise using the Service, you agree
              to these Terms and our Privacy Policy. If you do not agree, do not use the
              Service.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-3">2. Eligibility & accounts</h2>
            <ul className="list-disc pl-6 space-y-2">
              <li>You must be at least 16 years old to use the Service.</li>
              <li>You agree to provide accurate registration information, including your real farm location.</li>
              <li>You are responsible for safeguarding your credentials and for all activity on your account.</li>
              <li>You must promptly notify us of any suspected unauthorised access.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-3">3. The Service</h2>
            <p>
              VerdantIQ provides agricultural intelligence — including market prices, weather
              forecasts, satellite-derived crop health (NDVI), yield predictions, livestock
              tracking, mechanization scoring, AI agronomy advice, and logistics tools.
              Features may change, be added, or be removed at any time.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-3">4. AI accuracy disclaimer (READ CAREFULLY)</h2>
            <p>
              A core part of the Service is artificial intelligence — including the
              "Mudhumeni Hungwe" AI agronomist, yield-prediction models, NDVI interpretation,
              market-trend analysis, and credit-scoring inputs. You acknowledge and agree that:
            </p>
            <ul className="list-disc pl-6 space-y-2 mt-3">
              <li>
                <strong>AI can and does make mistakes.</strong> AI outputs may be inaccurate,
                incomplete, outdated, biased, or fabricated ("hallucinated"). Recommendations
                may be wrong for your specific soil, microclimate, crop variety, livestock
                breed, market conditions, or regulatory environment.
              </li>
              <li>
                <strong>AI is not a licensed professional.</strong> Outputs do not constitute
                professional agronomic, veterinary, financial, legal, or medical advice. They
                are informational only.
              </li>
              <li>
                <strong>You must verify before acting.</strong> You are solely responsible for
                independently verifying any AI output with a qualified agronomist, vet,
                extension officer, lender, or other expert <em>before</em> taking action that
                could affect your crops, livestock, finances, equipment, or safety.
              </li>
              <li>
                <strong>Weather and market data are estimates.</strong> Forecasts and prices
                are sourced from third parties (e.g. OpenMeteo) and may differ from actual
                conditions. Do not rely on them as the sole basis for irreplaceable decisions.
              </li>
              <li>
                <strong>Satellite imagery has limitations.</strong> NDVI and remote-sensing
                outputs are affected by cloud cover, sensor calibration, and revisit time.
              </li>
              <li>
                <strong>No guarantee of yield or income.</strong> Yield predictions and credit
                scores are probabilistic estimates and are not promises of outcome.
              </li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-3">5. Acceptable use</h2>
            <p>You agree not to:</p>
            <ul className="list-disc pl-6 space-y-2 mt-3">
              <li>Use the Service for any unlawful purpose or in violation of Zimbabwean law.</li>
              <li>Attempt to reverse engineer, scrape, decompile, or bypass security controls.</li>
              <li>Submit false farm data, impersonate others, or manipulate market submissions.</li>
              <li>Resell, sublicense, or commercially redistribute the Service or its data without written permission.</li>
              <li>Upload malicious code or content that infringes third-party rights.</li>
              <li>Use AI outputs in ways that could endanger people, animals, food safety, or the environment.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-3">6. Your data and content</h2>
            <p>
              You retain ownership of farm data and content you submit ("User Content"). You
              grant us a worldwide, royalty-free, non-exclusive licence to host, process,
              analyse, anonymise, aggregate, and use User Content to operate and improve the
              Service, train our models, and produce de-identified statistical reports. You
              warrant that you have the rights to grant this licence.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-3">7. Intellectual property</h2>
            <p>
              The Service, including the VerdantIQ and Mudhumeni Hungwe brands, software,
              models, designs, dashboards, and documentation, is owned by Zyterra and
              protected by copyright, trademark, and other laws. We grant you a limited,
              revocable, non-transferable, non-exclusive licence to use the Service for its
              intended purpose. All rights not expressly granted are reserved.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-3">8. Third-party services</h2>
            <p>
              The Service integrates third-party providers (Supabase, Twilio, OpenMeteo, AI
              gateway providers, satellite data sources, payment providers, and others). We
              are not responsible for the availability, accuracy, or actions of third-party
              services. Your use of them may be governed by their own terms.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-3">9. Service availability</h2>
            <p>
              The Service is provided on an "as is" and "as available" basis. We do not
              guarantee uptime, error-free operation, or that defects will be corrected. We
              may suspend or terminate the Service, or any feature, at any time without
              notice.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-3">10. Disclaimer of warranties</h2>
            <p className="uppercase text-sm">
              To the fullest extent permitted by law, the Service and all content (including
              AI outputs, weather data, market prices, NDVI, yield forecasts, and
              recommendations) are provided "AS IS" and "AS AVAILABLE" without warranty of
              any kind, express or implied, including warranties of merchantability, fitness
              for a particular purpose, accuracy, non-infringement, or that the Service will
              meet your requirements or be uninterrupted, secure, or error-free.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-3">11. Limitation of liability</h2>
            <p className="uppercase text-sm">
              To the maximum extent permitted by law, Zyterra, its directors, employees,
              affiliates, suppliers, and licensors shall NOT be liable for any indirect,
              incidental, special, consequential, exemplary, or punitive damages, or for any
              loss of profits, revenue, yield, livestock, crops, equipment, business,
              goodwill, data, or opportunity, arising out of or related to your use of (or
              inability to use) the Service, AI outputs, weather forecasts, market prices,
              yield predictions, or any third-party service — whether based on warranty,
              contract, tort (including negligence), statute, or any other legal theory, and
              whether or not we have been advised of the possibility of such damages.
            </p>
            <p className="uppercase text-sm mt-3">
              Our aggregate liability for any and all claims arising out of or relating to the
              Service shall not exceed the greater of (a) the amounts you paid to us in the
              twelve (12) months preceding the claim, or (b) USD 50.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-3">12. Indemnification</h2>
            <p className="font-semibold">
              You agree to defend, indemnify, and hold harmless Zyvatek Food Systems and Logistics (Private) Limited, its
              affiliates, officers, directors, employees, agents, partners, suppliers, and
              licensors (the "Indemnified Parties") from and against any and all claims,
              liabilities, damages, losses, costs, expenses, and fees (including reasonable
              legal fees) arising out of or in any way connected with:
            </p>
            <ul className="list-disc pl-6 space-y-2 mt-3">
              <li>Your access to or use of the Service.</li>
              <li>
                Any decision or action you (or anyone acting on your behalf) take in reliance
                on AI outputs, weather forecasts, market prices, yield predictions, NDVI
                analyses, agronomic advice, livestock recommendations, or any other content
                produced by or through the Service — including any resulting <strong>crop
                loss, livestock loss, equipment damage, financial loss, business
                interruption, regulatory penalty, personal injury, or environmental
                harm</strong>.
              </li>
              <li>Your User Content, including any claim that it infringes third-party rights.</li>
              <li>Your violation of these Terms, the Privacy Policy, or applicable law.</li>
              <li>Your violation of any third-party right, including intellectual property, privacy, or contractual rights.</li>
            </ul>
            <p className="mt-3">
              We reserve the right, at our own expense, to assume the exclusive defence and
              control of any matter otherwise subject to indemnification by you, in which case
              you agree to cooperate with our defence.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-3">13. Assumption of risk</h2>
            <p>
              Farming inherently involves risk from weather, pests, disease, market
              volatility, and other factors outside anyone's control. By using the Service you
              expressly assume all such risks and acknowledge that VerdantIQ is a
              decision-support tool, not a guarantor of agricultural or financial outcomes.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-3">14. Termination</h2>
            <p>
              We may suspend or terminate your account at any time for breach of these Terms,
              suspected fraud, or any reason at our discretion. You may close your account at
              any time by contacting us. Sections 4, 6, 7, 10, 11, 12, 13, 16, and 17 survive
              termination.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-3">15. Changes to the Terms</h2>
            <p>
              We may update these Terms from time to time. Material changes will be posted on
              the Service or sent to you. Continued use after changes constitutes acceptance.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-3">16. Governing law and jurisdiction</h2>
            <p>
              These Terms are governed by the laws of <strong>Zimbabwe</strong>, without
              regard to conflict-of-law principles. You agree to submit to the exclusive
              jurisdiction of the courts of Harare, Zimbabwe for any dispute arising out of or
              relating to these Terms or the Service.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-3">17. Miscellaneous</h2>
            <ul className="list-disc pl-6 space-y-2">
              <li><strong>Entire agreement:</strong> These Terms and the Privacy Policy are the entire agreement between you and us.</li>
              <li><strong>Severability:</strong> If any provision is held unenforceable, the remainder remains in effect.</li>
              <li><strong>No waiver:</strong> Our failure to enforce a right is not a waiver of that right.</li>
              <li><strong>Assignment:</strong> You may not assign these Terms; we may assign them to an affiliate or successor.</li>
              <li><strong>Force majeure:</strong> We are not liable for failures caused by events beyond our reasonable control.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-3">18. Contact</h2>
            <p>
              Zyvatek Food Systems and Logistics (Private) Limited<br />
              Harare, Zimbabwe<br />
              Legal: <a className="underline" href="mailto:legal@zyterra.co.zw">legal@zyterra.co.zw</a><br />
              Support: <a className="underline" href="mailto:hello@zyterra.co.zw">hello@zyterra.co.zw</a>
            </p>
          </section>
        </div>
      </main>

      <footer className="border-t mt-16 py-8 text-center text-xs" style={{ borderColor: "hsl(155, 15%, 18%)", color: fgMuted }}>
        © 2026 Zyterra. All rights reserved. •{" "}
        <Link to="/privacy" className="hover:underline">Privacy Policy</Link> •{" "}
        <Link to="/" className="hover:underline">Home</Link>
      </footer>
    </div>
  );
};

export default Terms;
