import React, { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Sprout, Leaf, MapPin, CloudRain, TrendingUp, Users,
  Beaker, Beef, Activity, Globe2, Satellite, Truck, MessageCircle, BarChart3,
} from "lucide-react";

import NationalNdviMap from "@/components/pitch/NationalNdviMap";
import NdviTimeSeries from "@/components/pitch/NdviTimeSeries";
import ClimatePanel from "@/components/pitch/ClimatePanel";
import CropsYieldPanel from "@/components/pitch/CropsYieldPanel";
import LivestockPanel from "@/components/pitch/LivestockPanel";
import MarketsPanel from "@/components/pitch/MarketsPanel";
import LogisticsPanel from "@/components/pitch/LogisticsPanel";
import WhatsAppReachPanel from "@/components/pitch/WhatsAppReachPanel";
import SoilScatter from "@/components/pitch/SoilScatter";

type Stats = {
  total_farms: number;
  mapped_farms: number;
  total_hectares: number;
  total_farmers: number;
  soil_cards_issued: number;
  avg_ndvi: number | null;
  avg_agroecology_score: number;
  zones: { region_code: string; region_name: string; farm_count: number }[];
  soil_grades: Record<string, number>;
  confidence_tiers: Record<string, number>;
  practice_adoption: { method: string; pct: number }[];
  active_alerts: number;
  livestock_total: number;
};

export default function PitchDashboard() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    document.title = "Zimbabwe National Agricultural Intelligence System";
    let m = document.querySelector('meta[name="description"]');
    if (!m) { m = document.createElement("meta"); m.setAttribute("name", "description"); document.head.appendChild(m); }
    m.setAttribute("content", "National agricultural intelligence: vegetation, soil, climate, crops, livestock, markets and logistics — powered by VerdantIQ.");
  }, []);

  useEffect(() => {
    (async () => {
      try {
        const [farmsRes, zonesRes, soilCardsRes, herdsRes, alertsRes, practicesRes, ndviRes] = await Promise.all([
          supabase.from("farms").select("id, size_hectares, user_id, agroecological_zone_id, boundary"),
          supabase.from("agroecological_zones").select("id, region_code, region_name"),
          supabase.from("soil_health_cards" as any).select("farm_id, health_grade, soil_confidence"),
          supabase.from("livestock_herds").select("herd_size"),
          supabase.from("weather_alerts" as any).select("id", { count: "exact", head: true }).eq("is_active", true),
          supabase.from("farm_practices").select("adoption_score, cover_crops, conservation_ag_methods, agroforestry_species, rotation_sequence"),
          supabase.from("satellite_imagery").select("ndvi_value").gte("captured_at", new Date(Date.now() - 30 * 86400000).toISOString()).limit(2000),
        ]);

        const farms = farmsRes.data || [];
        const zones = zonesRes.data || [];
        const cards = ((soilCardsRes.data as unknown) as any[]) || [];
        const herds = herdsRes.data || [];
        const practices = practicesRes.data || [];
        const ndviRows = (ndviRes.data || []).map((r: any) => Number(r.ndvi_value)).filter((n) => !isNaN(n));

        const zoneCounts = zones.map((z) => ({
          region_code: z.region_code, region_name: z.region_name,
          farm_count: farms.filter((f) => f.agroecological_zone_id === z.id).length,
        }));

        const grades: Record<string, number> = { A: 0, B: 0, C: 0, D: 0, E: 0 };
        cards.forEach((c: any) => { if (grades[c.health_grade] !== undefined) grades[c.health_grade]++; });

        const tiers: Record<string, number> = { low: 0, medium: 0, high: 0, validated: 0 };
        cards.forEach((c: any) => { if (tiers[c.soil_confidence] !== undefined) tiers[c.soil_confidence]++; });

        const tot = Math.max(practices.length, 1);
        const pct = (k: string) =>
          Math.round((practices.filter((p: any) => Array.isArray(p[k]) && p[k].length > 0).length / tot) * 100);
        const practiceAdoption = [
          { method: "Cover crops", pct: pct("cover_crops") },
          { method: "Conservation ag", pct: pct("conservation_ag_methods") },
          { method: "Agroforestry", pct: pct("agroforestry_species") },
          { method: "Crop rotation", pct: pct("rotation_sequence") },
        ];

        const avgScore = practices.length
          ? Math.round(practices.reduce((s: number, p: any) => s + Number(p.adoption_score || 0), 0) / practices.length)
          : 0;

        setStats({
          total_farms: farms.length,
          mapped_farms: farms.filter((f: any) => f.boundary).length,
          total_hectares: Math.round(farms.reduce((s, f) => s + Number(f.size_hectares || 0), 0)),
          total_farmers: new Set(farms.map((f) => f.user_id)).size,
          soil_cards_issued: cards.length,
          avg_ndvi: ndviRows.length ? +(ndviRows.reduce((s, n) => s + n, 0) / ndviRows.length).toFixed(2) : null,
          avg_agroecology_score: avgScore,
          zones: zoneCounts,
          soil_grades: grades,
          confidence_tiers: tiers,
          practice_adoption: practiceAdoption,
          active_alerts: alertsRes.count || 0,
          livestock_total: herds.reduce((s, h) => s + Number(h.herd_size || 0), 0),
        });
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-emerald-950 via-green-900 to-emerald-800 flex items-center justify-center text-white">
        <div className="text-xl">Loading national agricultural intelligence…</div>
      </div>
    );
  }
  if (!stats) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-950 via-green-900 to-emerald-800 text-white">
      {/* Hero */}
      <section className="px-6 py-12 md:py-16 text-center max-w-7xl mx-auto">
        <Badge className="bg-yellow-400 text-emerald-950 hover:bg-yellow-400 mb-4">Live national data</Badge>
        <h1 className="text-3xl md:text-5xl font-bold mb-3 leading-tight">
          Zimbabwe National Agricultural Intelligence System
        </h1>
        <p className="text-lg md:text-xl text-emerald-100 mb-1">
          Soil · Climate · Vegetation · Crops · Livestock · Markets · Logistics
        </p>
        <p className="text-xs text-emerald-300 mb-8">Powered by VerdantIQ · Built in Zimbabwe</p>

        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-3 max-w-7xl mx-auto">
          <Stat icon={<Users className="w-4 h-4" />} label="Farmers" value={stats.total_farmers} />
          <Stat icon={<MapPin className="w-4 h-4" />} label="Farms" value={stats.total_farms} />
          <Stat icon={<Globe2 className="w-4 h-4" />} label="Hectares" value={stats.total_hectares.toLocaleString()} />
          <Stat icon={<Satellite className="w-4 h-4" />} label="Mapped" value={stats.mapped_farms} />
          <Stat icon={<Beaker className="w-4 h-4" />} label="Soil Cards" value={stats.soil_cards_issued} />
          <Stat icon={<Activity className="w-4 h-4" />} label="Avg NDVI" value={stats.avg_ndvi ?? "—"} />
          <Stat icon={<CloudRain className="w-4 h-4" />} label="Alerts" value={stats.active_alerts} />
          <Stat icon={<Beef className="w-4 h-4" />} label="Livestock" value={stats.livestock_total.toLocaleString()} />
        </div>
      </section>

      {/* Body */}
      <section className="px-6 pb-16 max-w-7xl mx-auto space-y-6">
        {/* National map — full width */}
        <DarkCard icon={<Satellite className="w-5 h-5" />} title="National Vegetation Health Map" subtitle="Latest NDVI per farm · agroecological zones overlaid">
          <NationalNdviMap />
        </DarkCard>

        {/* NDVI time-series */}
        <DarkCard icon={<TrendingUp className="w-5 h-5" />} title="NDVI Trend (last 120 days)" subtitle="National average + per-zone breakdown">
          <NdviTimeSeries />
        </DarkCard>

        {/* 2-col: Zones + Soil */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <DarkCard icon={<MapPin className="w-5 h-5" />} title="Agroecological Zones" subtitle="Natural Regions I–Vb · auto-assigned by farm boundary">
            <div className="space-y-2">
              {stats.zones.map((z) => (
                <div key={z.region_code} className="flex items-center justify-between text-sm">
                  <span>{z.region_name}</span>
                  <Badge variant="secondary" className="bg-emerald-700 text-white">{z.farm_count} farms</Badge>
                </div>
              ))}
            </div>
          </DarkCard>

          <DarkCard icon={<Sprout className="w-5 h-5" />} title="National Soil Health" subtitle="Grade distribution · pH vs organic carbon">
            <div className="space-y-2 mb-4">
              {(["A", "B", "C", "D", "E"] as const).map((g) => {
                const n = stats.soil_grades[g] || 0;
                const total = Object.values(stats.soil_grades).reduce((a, b) => a + b, 0) || 1;
                return (
                  <div key={g}>
                    <div className="flex justify-between text-xs"><span>Grade {g}</span><span>{n}</span></div>
                    <Progress value={(n / total) * 100} className="h-1.5 bg-emerald-950" />
                  </div>
                );
              })}
            </div>
            <SoilScatter />
            <div className="mt-3 grid grid-cols-4 gap-1.5 text-center text-xs">
              {(["low", "medium", "high", "validated"] as const).map((t) => (
                <div key={t} className="bg-emerald-800 rounded p-1.5">
                  <div className="text-base font-bold">{stats.confidence_tiers[t] || 0}</div>
                  <div className="capitalize text-emerald-200 text-[10px]">{t}</div>
                </div>
              ))}
            </div>
          </DarkCard>
        </div>

        {/* 2-col: Climate + Crops */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <DarkCard icon={<CloudRain className="w-5 h-5" />} title="Climate & Active Alerts" subtitle="OpenMeteo · frost · drought · heavy rain">
            <ClimatePanel />
          </DarkCard>
          <DarkCard icon={<TrendingUp className="w-5 h-5" />} title="Crops & Yield Forecast vs Actual" subtitle="Top crops by registered area">
            <CropsYieldPanel />
          </DarkCard>
        </div>

        {/* 2-col: Livestock + Markets */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <DarkCard icon={<Beef className="w-5 h-5" />} title="Livestock Census" subtitle="Cattle · goats · sheep · poultry · pigs">
            <LivestockPanel />
          </DarkCard>
          <DarkCard icon={<BarChart3 className="w-5 h-5" />} title="National Market Prices" subtitle="Top commodities · USD or ZiG">
            <MarketsPanel />
          </DarkCard>
        </div>

        {/* 2-col: Logistics + WhatsApp */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <DarkCard icon={<Truck className="w-5 h-5" />} title="Logistics Pipeline" subtitle="Collection requests by status · GRNs issued">
            <LogisticsPanel />
          </DarkCard>
          <DarkCard icon={<MessageCircle className="w-5 h-5" />} title="WhatsApp Reach" subtitle="Messages delivered last 30 days">
            <WhatsAppReachPanel />
          </DarkCard>
        </div>

        {/* Practice adoption — full width */}
        <DarkCard icon={<Leaf className="w-5 h-5" />} title="Agroecology Practice Adoption" subtitle={`Average score ${stats.avg_agroecology_score}/100`}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {stats.practice_adoption.map((p) => (
              <div key={p.method}>
                <div className="flex justify-between text-sm"><span>{p.method}</span><span>{p.pct}%</span></div>
                <Progress value={p.pct} className="h-2 bg-emerald-950" />
              </div>
            ))}
          </div>
        </DarkCard>
      </section>

      {/* Footer */}
      <section className="bg-emerald-950 px-6 py-10 text-center">
        <h2 className="text-2xl md:text-3xl font-bold mb-2">A national AIS, ready for pilot</h2>
        <p className="text-emerald-200 max-w-2xl mx-auto">
          Soil health cards from day one via progressive enrichment. Climate, crop, livestock and market intelligence delivered via dashboard and WhatsApp in Shona, Ndebele and English.
        </p>
        <p className="text-xs text-emerald-400 mt-4">Powered by VerdantIQ</p>
      </section>
    </div>
  );
}

function Stat({ icon, label, value }: { icon: React.ReactNode; label: string; value: string | number }) {
  return (
    <div className="bg-emerald-900/60 backdrop-blur border border-emerald-700 rounded-xl p-3">
      <div className="flex items-center justify-center gap-1 text-emerald-300 text-[10px] mb-1">{icon}<span>{label}</span></div>
      <div className="text-xl md:text-2xl font-bold">{value}</div>
    </div>
  );
}

function DarkCard({ icon, title, subtitle, children }: { icon: React.ReactNode; title: string; subtitle?: string; children: React.ReactNode }) {
  return (
    <Card className="bg-emerald-900/60 backdrop-blur border-emerald-700 text-white">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-white text-base">{icon}{title}</CardTitle>
        {subtitle && <CardDescription className="text-emerald-200 text-xs">{subtitle}</CardDescription>}
      </CardHeader>
      <CardContent>{children}</CardContent>
    </Card>
  );
}
