import { Link } from "react-router-dom";

const PrivacyPolicy = () => {
  const bgDark = "hsl(155, 25%, 8%)";
  const fgMuted = "hsl(150, 10%, 70%)";

  return (
    <div className="min-h-screen" style={{ backgroundColor: bgDark, color: "hsl(150, 10%, 95%)" }}>
      <header className="border-b" style={{ borderColor: "hsl(155, 15%, 18%)" }}>
        <div className="max-w-4xl mx-auto px-6 py-6 flex items-center justify-between">
          <Link to="/" className="text-xl font-bold tracking-tight">VerdantIQ</Link>
          <Link to="/terms" className="text-sm hover:underline" style={{ color: fgMuted }}>
            Terms of Use →
          </Link>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-6 py-12">
        <h1 className="text-4xl font-bold mb-2">Privacy Policy</h1>
        <p className="text-sm mb-10" style={{ color: fgMuted }}>
          Last updated: 29 April 2026 • Effective immediately
        </p>

        <div className="prose prose-invert max-w-none space-y-8 text-base leading-relaxed">
          <section>
            <h2 className="text-2xl font-semibold mb-3">1. Who we are</h2>
            <p>
              VerdantIQ ("VerdantIQ", "we", "us", "our") is an agricultural intelligence
              platform operated by <strong>Zyvatek Food Systems and Logistics (Private) Limited</strong>, trading as <strong>Zyterra</strong>, a company
              registered in Zimbabwe with offices in Harare. We are the data controller for
              personal information processed through this platform, our WhatsApp bot
              ("Mudhumeni Hungwe"), and any related services (collectively, the "Service").
            </p>
            <p className="mt-3">
              Contact: <a className="underline" href="mailto:privacy@zyterra.co.zw">privacy@zyterra.co.zw</a>
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-3">2. Information we collect</h2>
            <p>We collect the following categories of information:</p>
            <ul className="list-disc pl-6 space-y-2 mt-3">
              <li><strong>Account data:</strong> name, email, phone number, password hash, role, language preference.</li>
              <li><strong>Farm data:</strong> farm location, georeferenced boundaries, crop and livestock records, soil tests, yield logs, equipment inventory, activity logs.</li>
              <li><strong>WhatsApp conversation data:</strong> messages, media (e.g. crop images), and metadata when you contact our bot.</li>
              <li><strong>Derived insights:</strong> AI-generated recommendations, NDVI/satellite analyses, yield forecasts, credit score inputs.</li>
              <li><strong>Technical data:</strong> IP address, device type, browser, log files, cookies, error reports.</li>
              <li><strong>Market & weather queries:</strong> location queries, commodity searches, alert subscriptions.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-3">3. How we use your data</h2>
            <ul className="list-disc pl-6 space-y-2">
              <li>To deliver the Service, including dashboards, alerts, and AI advice.</li>
              <li>To improve our models, including training and fine-tuning agronomic AI on aggregated and de-identified data.</li>
              <li>To send transactional messages (WhatsApp digests, weather alerts, top-dressing reminders).</li>
              <li>To produce anonymised, aggregated reports for ministries, partners, lenders, and researchers.</li>
              <li>To detect fraud, abuse, and security threats.</li>
              <li>To comply with legal obligations under Zimbabwean law (including the Data Protection Act [Chapter 11:24]).</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-3">4. Legal bases for processing</h2>
            <p>
              We process personal data on the basis of (a) your consent, (b) performance of a
              contract with you, (c) our legitimate interests in operating and improving the
              Service, and (d) compliance with legal obligations.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-3">5. Sharing your data</h2>
            <p>We share data only as described below:</p>
            <ul className="list-disc pl-6 space-y-2 mt-3">
              <li><strong>Service providers:</strong> Supabase (hosting, database), Twilio (WhatsApp), OpenMeteo (weather), AI gateway providers, and analytics tools — all bound by confidentiality.</li>
              <li><strong>Aggregated insights:</strong> de-identified, statistical data may be shared with government agencies, financial institutions, and research partners.</li>
              <li><strong>Legal compliance:</strong> when required by law, court order, or to protect rights, property, or safety.</li>
              <li><strong>Business transfers:</strong> in the event of a merger, acquisition, or sale of assets.</li>
            </ul>
            <p className="mt-3">
              We <strong>do not sell</strong> your personal data.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-3">6. International transfers</h2>
            <p>
              Our infrastructure providers may process data outside Zimbabwe (including in the
              EU and US). Where this happens, we rely on standard contractual safeguards.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-3">7. Data retention</h2>
            <p>
              We retain account and farm data for as long as your account is active and for up
              to 24 months after closure to honour legal, accounting, and audit requirements.
              Aggregated, de-identified data may be retained indefinitely for research.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-3">8. Your rights</h2>
            <p>Under Zimbabwean and international data protection norms you may:</p>
            <ul className="list-disc pl-6 space-y-2 mt-3">
              <li>Request access to the personal data we hold about you.</li>
              <li>Request correction of inaccurate data.</li>
              <li>Request deletion of your account and personal data (subject to legal retention).</li>
              <li>Withdraw consent at any time, including unsubscribing from WhatsApp messages by replying STOP.</li>
              <li>Lodge a complaint with the Postal and Telecommunications Regulatory Authority of Zimbabwe (POTRAZ) acting as the data protection authority.</li>
            </ul>
            <p className="mt-3">To exercise any right, email <a className="underline" href="mailto:privacy@zyterra.co.zw">privacy@zyterra.co.zw</a>.</p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-3">9. Security</h2>
            <p>
              We use Row-Level Security on our database, encrypted transport (TLS), hashed
              credentials, role-based access control, and routine security scans. No system is
              perfectly secure; we cannot guarantee absolute security and you use the Service
              at your own risk (see Terms of Use, section on indemnity).
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-3">10. Children</h2>
            <p>
              The Service is not directed at children under 16. If you believe a child has
              provided us with personal data, please contact us so we can remove it.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-3">11. Cookies</h2>
            <p>
              We use essential cookies for authentication and session management, and may use
              analytics cookies to understand usage. You can disable cookies in your browser,
              but parts of the Service may not function.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-3">12. Changes to this policy</h2>
            <p>
              We may update this policy from time to time. Material changes will be announced
              on the dashboard or via WhatsApp. Continued use after changes constitutes
              acceptance.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-3">13. Contact</h2>
            <p>
              Zyvatek Food Systems and Logistics (Private) Limited<br />
              Harare, Zimbabwe<br />
              <a className="underline" href="mailto:privacy@zyterra.co.zw">privacy@zyterra.co.zw</a>
            </p>
          </section>
        </div>
      </main>

      <footer className="border-t mt-16 py-8 text-center text-xs" style={{ borderColor: "hsl(155, 15%, 18%)", color: fgMuted }}>
        © 2026 Zyterra. All rights reserved. •{" "}
        <Link to="/terms" className="hover:underline">Terms of Use</Link> •{" "}
        <Link to="/" className="hover:underline">Home</Link>
      </footer>
    </div>
  );
};

export default PrivacyPolicy;
