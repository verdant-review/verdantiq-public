import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/hooks/useAuth";
import SchemeManager from "@/components/org/SchemeManager";
import SchemeReports from "@/components/org/SchemeReports";
import OrgDemoDashboard from "@/components/org/OrgDemoDashboard";
import OrgLiveMap from "@/components/org/OrgLiveMap";
import { CheckCircle2, Sparkles } from "lucide-react";



interface Org {
  id: string;
  slug: string;
  name: string;
  type: string;
  status: string;
  plan: string;
  pilot_expires_at: string | null;
}

interface Branding {
  logo_url: string | null;
  primary_color: string | null;
  accent_color: string | null;
  tagline: string | null;
  contact_email: string | null;
  contact_phone: string | null;
  website_url: string | null;
}

const OrgPage = () => {
  const { slug } = useParams<{ slug: string }>();
  const { user } = useAuth();
  const [org, setOrg] = useState<Org | null>(null);
  const [branding, setBranding] = useState<Branding | null>(null);
  const [isMember, setIsMember] = useState(false);
  const [memberRole, setMemberRole] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);


  useEffect(() => {
    let mounted = true;
    (async () => {
      if (!slug) return;
      const { data: orgRow } = await supabase
        .from("organizations")
        .select("id, slug, name, type, status, plan, pilot_expires_at")
        .eq("slug", slug)
        .maybeSingle();
      if (!mounted) return;
      if (!orgRow) {
        setNotFound(true);
        setLoading(false);
        return;
      }
      setOrg(orgRow as Org);

      const { data: brandRow } = await supabase
        .from("org_branding")
        .select("logo_url, primary_color, accent_color, tagline, contact_email, contact_phone, website_url")
        .eq("organization_id", orgRow.id)
        .maybeSingle();
      if (!mounted) return;
      setBranding(brandRow as Branding | null);

      if (user) {
        const { data: m } = await supabase
          .from("org_members")
          .select("id, role")
          .eq("organization_id", orgRow.id)
          .eq("user_id", user.id)
          .maybeSingle();
        if (!mounted) return;
        setIsMember(!!m);
        setMemberRole((m as any)?.role || null);
      }
      setLoading(false);

    })();
    return () => {
      mounted = false;
    };
  }, [slug, user]);

  if (loading) {
    return (
      <div className="min-h-screen p-8 max-w-5xl mx-auto space-y-4">
        <Skeleton className="h-24 w-full" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  if (notFound || !org) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle>Organization not found</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">
              No organization exists at <code>/org/{slug}</code>.
            </p>
            <Button asChild variant="outline">
              <Link to="/">Go home</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const primary = branding?.primary_color || "#1B5E20";
  const accent = branding?.accent_color || "#FBC02D";

  const statusBadge = {
    prospect: { label: "Demo", className: "bg-muted text-muted-foreground" },
    pilot: { label: "Pilot", className: "bg-yellow-100 text-yellow-900" },
    active: { label: "Active", className: "bg-green-100 text-green-900" },
    suspended: { label: "Suspended", className: "bg-red-100 text-red-900" },
    archived: { label: "Archived", className: "bg-muted text-muted-foreground" },
  }[org.status] || { label: org.status, className: "" };

  return (
    <div className="min-h-screen bg-background">
      {/* Branded header */}
      <header
        className="border-b"
        style={{ background: `linear-gradient(135deg, ${primary} 0%, ${primary}dd 100%)`, color: "white" }}
      >
        <div className="max-w-6xl mx-auto px-6 py-12">
          <div className="flex items-start justify-between gap-6 flex-wrap">
            <div className="flex items-center gap-4">
              {branding?.logo_url ? (
                <img src={branding.logo_url} alt={`${org.name} logo`} className="h-16 w-16 rounded bg-white p-2 object-contain" />
              ) : (
                <div
                  className="h-16 w-16 rounded flex items-center justify-center font-bold text-2xl"
                  style={{ background: accent, color: primary }}
                >
                  {org.name.charAt(0)}
                </div>
              )}
              <div>
                <h1 className="text-3xl font-bold">{org.name}</h1>
                {branding?.tagline && <p className="text-white/80 mt-1">{branding.tagline}</p>}
              </div>
            </div>
            <div className="flex flex-col items-end gap-2">
              <Badge className={statusBadge.className}>{statusBadge.label}</Badge>
              <span className="text-xs text-white/70 capitalize">{org.type} • {org.plan}</span>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 py-10 space-y-8">
        {/* Member dashboard — Phase 2 & 3 */}
        {isMember ? (
          <>
            {org.status === "active" ? (
              <div className="rounded-lg border-l-4 px-4 py-3 bg-green-50 dark:bg-green-950/30 border-green-600 flex items-start gap-3">
                <CheckCircle2 className="h-5 w-5 text-green-700 dark:text-green-400 mt-0.5" />
                <div className="text-sm">
                  <div className="font-semibold text-green-900 dark:text-green-200">Live workspace · demo cleared</div>
                  <p className="text-green-800/80 dark:text-green-300/80">
                    This organisation is now active. The demo data has been retired — onboard real farmers, create schemes,
                    and live GIS will populate as farms pin their boundaries.
                  </p>
                </div>
              </div>
            ) : (
              <div className="rounded-lg border-l-4 px-4 py-3 bg-amber-50 dark:bg-amber-950/30 border-amber-500 flex items-start gap-3">
                <Sparkles className="h-5 w-5 text-amber-700 dark:text-amber-400 mt-0.5" />
                <div className="text-sm">
                  <div className="font-semibold text-amber-900 dark:text-amber-200 capitalize">{org.status} workspace</div>
                  <p className="text-amber-800/80 dark:text-amber-300/80">
                    You can start building schemes and onboarding farmers now. Once an admin marks this organisation as
                    <strong> active</strong>, the public demo will be replaced by your real programme.
                  </p>
                </div>
              </div>
            )}

            <SchemeManager
              organizationId={org.id}
              canManage={["org_owner", "org_manager", "org_agronomist", "org_extension"].includes(memberRole || "")}
            />
            <OrgLiveMap organizationId={org.id} primary={primary} />
            <SchemeReports organizationId={org.id} />
          </>
        ) : org.status === "active" ? (
          <Card>
            <CardHeader>
              <CardTitle>{org.name} is live on VerdantOS</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <p className="text-muted-foreground">
                This organisation is running a real programme. Public demo data has been retired. Sign in as a member to access the live workspace, schemes, and field GIS.
              </p>
              <Button asChild style={{ background: primary }}>
                <Link to="/auth">Sign in</Link>
              </Button>
            </CardContent>
          </Card>
        ) : (
          <OrgDemoDashboard
            orgName={org.name}
            orgType={org.type}
            slug={org.slug}
            primary={primary}
            accent={accent}
            isAuthed={!!user}
          />
        )}

        <Card>
          <CardHeader>
            <CardTitle>What this organization can do</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="grid sm:grid-cols-2 gap-3 text-sm">
              <li className="border rounded p-3"><strong>Branded portal</strong> — your colours, logo, and tagline</li>
              <li className="border rounded p-3"><strong>Scheme management</strong> — per-commodity, per-season cohorts (Phase 2)</li>
              <li className="border rounded p-3"><strong>Farmer roster & GIS</strong> — read-only view of fields enrolled in your schemes</li>
              <li className="border rounded p-3"><strong>Branded reports</strong> — PDF + CSV exports for compliance & impact (Phase 3)</li>
            </ul>
          </CardContent>
        </Card>

        <footer className="text-center text-xs text-muted-foreground pt-8">
          Powered by VerdantOS · Zyterra
        </footer>
      </main>
    </div>
  );
};

export default OrgPage;
