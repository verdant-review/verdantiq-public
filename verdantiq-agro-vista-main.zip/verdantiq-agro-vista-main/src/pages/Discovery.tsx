import { useState } from "react";
import { useSearchParams, Link } from "react-router-dom";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { Loader2, ArrowUp, ArrowDown, CheckCircle2, Sprout, Building2, HeartHandshake } from "lucide-react";
import { toast } from "sonner";

type Audience = "agribusiness" | "ngo";

// ===== Agribusiness options =====
const RELATIONSHIP_OPTIONS = [
  { value: "seed_house", label: "Seed house" },
  { value: "contract_buyer", label: "Contract grain/crop buyer" },
  { value: "processor", label: "Processor / off-taker" },
  { value: "input_supplier", label: "Input supplier (fertiliser, chems)" },
  { value: "other", label: "Other" },
];
const FARMER_BANDS = [
  { value: "lt_100", label: "Fewer than 100" },
  { value: "100_500", label: "100 – 500" },
  { value: "500_2000", label: "500 – 2,000" },
  { value: "2000_plus", label: "2,000+" },
];
const MONITORING_OPTIONS = [
  { value: "field_officers", label: "Field officers only (visits, paper)" },
  { value: "spreadsheets", label: "Spreadsheets" },
  { value: "whatsapp", label: "WhatsApp groups" },
  { value: "software", label: "An existing software platform" },
  { value: "none", label: "We don't really monitor" },
];
const AGRI_PAINS = [
  { id: "side_selling", label: "Side-selling (farmers selling outside contract)" },
  { id: "low_yields", label: "Low yields per hectare" },
  { id: "late_deliveries", label: "Late or missed deliveries to us" },
  { id: "input_misuse", label: "Inputs being misused or sold on" },
  { id: "no_visibility", label: "No visibility into what's actually happening on farms" },
];
const WOULD_PAY_OPTIONS = [
  { value: "yes", label: "Yes" },
  { value: "depends", label: "Depends" },
  { value: "no", label: "No" },
];

// ===== NGO options =====
const NGO_PROGRAM_TYPES = [
  { value: "climate_resilience", label: "Climate resilience / adaptation" },
  { value: "food_security", label: "Food security & nutrition" },
  { value: "livelihoods", label: "Livelihoods / income generation" },
  { value: "value_chain", label: "Value chain development" },
  { value: "input_distribution", label: "Input distribution / vouchers" },
  { value: "other", label: "Other" },
];
const NGO_FUNDER_TYPES = [
  { value: "bilateral", label: "Bilateral donor (USAID, FCDO, GIZ, etc.)" },
  { value: "multilateral", label: "Multilateral (UN, World Bank, IFAD)" },
  { value: "foundation", label: "Foundation (Gates, Rockefeller, Mastercard)" },
  { value: "private", label: "Private / corporate" },
  { value: "mixed", label: "Mixed funding sources" },
];
const NGO_BENEFICIARY_BANDS = [
  { value: "lt_500", label: "Fewer than 500" },
  { value: "500_5k", label: "500 – 5,000" },
  { value: "5k_25k", label: "5,000 – 25,000" },
  { value: "25k_plus", label: "25,000+" },
];
const NGO_ME_TOOLS = [
  { value: "kobo_ona", label: "KoboToolbox / ONA / SurveyCTO" },
  { value: "commcare", label: "CommCare / Dimagi" },
  { value: "excel", label: "Excel + paper forms" },
  { value: "custom", label: "Custom-built database" },
  { value: "none", label: "No formal M&E system" },
];
const NGO_PAINS = [
  { id: "beneficiary_dedup", label: "Deduplicating beneficiaries across projects" },
  { id: "donor_reporting", label: "Producing donor reports on time" },
  { id: "outcome_evidence", label: "Proving outcomes (yield, income changes) credibly" },
  { id: "field_data_quality", label: "Field data quality from enumerators" },
  { id: "geo_verification", label: "Verifying activities actually happened on the ground" },
];
const NGO_REPORTING_BURDEN = [
  { value: "low", label: "Manageable" },
  { value: "medium", label: "A real cost — multiple staff weeks per quarter" },
  { value: "high", label: "Crippling — dominates the team's calendar" },
];
const NGO_BUDGET_BANDS = [
  { value: "lt_5", label: "<$5 per beneficiary / year" },
  { value: "5_15", label: "$5 – $15 per beneficiary / year" },
  { value: "15_50", label: "$15 – $50 per beneficiary / year" },
  { value: "depends_donor", label: "Depends entirely on the donor budget line" },
  { value: "no_budget", label: "No M&E tech budget today" },
];

// ===== Schemas =====
const baseIdentity = {
  name: z.string().trim().min(1).max(120),
  company: z.string().trim().min(1).max(160),
  role: z.string().trim().min(1).max(120),
  email: z.string().trim().email().max(255),
};

const agriSchema = z.object({
  ...baseIdentity,
  relationship_type: z.string().min(1),
  farmer_count_band: z.string().min(1),
  current_monitoring: z.string().min(1),
  would_pay: z.enum(["yes", "depends", "no"]),
  would_pay_notes: z.string().max(500).optional(),
  one_fix: z.string().trim().min(1).max(500),
  follow_up_ok: z.boolean(),
  follow_up_contact: z.string().max(160).optional(),
});

const ngoSchema = z.object({
  ...baseIdentity,
  ngo_program_type: z.string().min(1),
  ngo_funder_type: z.string().min(1),
  ngo_beneficiary_band: z.string().min(1),
  ngo_me_tools: z.string().min(1),
  ngo_reporting_burden: z.string().min(1),
  ngo_budget_band: z.string().min(1),
  ngo_must_have: z.string().trim().min(1).max(500),
  follow_up_ok: z.boolean(),
  follow_up_contact: z.string().max(160).optional(),
});

const Discovery = () => {
  const [searchParams] = useSearchParams();
  const source = searchParams.get("source") || undefined;
  const initialAudience = (searchParams.get("audience") === "ngo" ? "ngo" : "agribusiness") as Audience;

  const [audience, setAudience] = useState<Audience>(initialAudience);
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);

  // Shared
  const [name, setName] = useState("");
  const [company, setCompany] = useState("");
  const [role, setRole] = useState("");
  const [email, setEmail] = useState("");
  const [followUp, setFollowUp] = useState(false);
  const [followUpContact, setFollowUpContact] = useState("");

  // Agri
  const [relationship, setRelationship] = useState("");
  const [band, setBand] = useState("");
  const [monitoring, setMonitoring] = useState("");
  const [agriPains, setAgriPains] = useState(AGRI_PAINS);
  const [wouldPay, setWouldPay] = useState<"yes" | "depends" | "no" | "">("");
  const [wouldPayNotes, setWouldPayNotes] = useState("");
  const [oneFix, setOneFix] = useState("");

  // NGO
  const [ngoProgram, setNgoProgram] = useState("");
  const [ngoFunder, setNgoFunder] = useState("");
  const [ngoBeneficiary, setNgoBeneficiary] = useState("");
  const [ngoMe, setNgoMe] = useState("");
  const [ngoPains, setNgoPains] = useState(NGO_PAINS);
  const [ngoReportingBurden, setNgoReportingBurden] = useState("");
  const [ngoBudget, setNgoBudget] = useState("");
  const [ngoMustHave, setNgoMustHave] = useState("");

  const movePain = (
    list: { id: string; label: string }[],
    setList: (v: { id: string; label: string }[]) => void,
    idx: number,
    dir: -1 | 1,
  ) => {
    const next = [...list];
    const target = idx + dir;
    if (target < 0 || target >= next.length) return;
    [next[idx], next[target]] = [next[target], next[idx]];
    setList(next);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    let payload: Record<string, unknown>;
    if (audience === "agribusiness") {
      const parsed = agriSchema.safeParse({
        name, company, role, email,
        relationship_type: relationship,
        farmer_count_band: band,
        current_monitoring: monitoring,
        would_pay: wouldPay || undefined,
        would_pay_notes: wouldPayNotes || undefined,
        one_fix: oneFix,
        follow_up_ok: followUp,
        follow_up_contact: followUp ? (followUpContact || undefined) : undefined,
      });
      if (!parsed.success) {
        toast.error(parsed.error.issues[0]?.message ?? "Please fill in all required fields");
        return;
      }
      payload = {
        ...parsed.data,
        audience: "agribusiness",
        pain_ranking: agriPains.map(p => p.id),
        would_pay_notes: parsed.data.would_pay_notes ?? null,
        follow_up_contact: parsed.data.follow_up_contact ?? null,
      };
    } else {
      const parsed = ngoSchema.safeParse({
        name, company, role, email,
        ngo_program_type: ngoProgram,
        ngo_funder_type: ngoFunder,
        ngo_beneficiary_band: ngoBeneficiary,
        ngo_me_tools: ngoMe,
        ngo_reporting_burden: ngoReportingBurden,
        ngo_budget_band: ngoBudget,
        ngo_must_have: ngoMustHave,
        follow_up_ok: followUp,
        follow_up_contact: followUp ? (followUpContact || undefined) : undefined,
      });
      if (!parsed.success) {
        toast.error(parsed.error.issues[0]?.message ?? "Please fill in all required fields");
        return;
      }
      payload = {
        ...parsed.data,
        audience: "ngo",
        ngo_pain_ranking: ngoPains.map(p => p.id),
        relationship_type: "ngo",
        follow_up_contact: parsed.data.follow_up_contact ?? null,
      };
    }

    setSubmitting(true);
    try {
      const { error } = await supabase.from("discovery_responses").insert({
        ...payload,
        source: source ?? null,
        user_agent: navigator.userAgent.slice(0, 500),
      } as never);
      if (error) throw error;
      setDone(true);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Failed to submit. Please try again.";
      toast.error(msg);
    } finally {
      setSubmitting(false);
    }
  };

  if (done) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-yellow-50 flex items-center justify-center p-4">
        <Card className="max-w-lg w-full">
          <CardHeader className="text-center">
            <CheckCircle2 className="h-14 w-14 mx-auto text-green-700" />
            <CardTitle className="mt-3 text-2xl">Thank you</CardTitle>
            <CardDescription className="text-base mt-2">
              Your answers have been received. We'll be in touch if we have follow-up questions or a pilot to share.
            </CardDescription>
          </CardHeader>
          <CardContent className="text-center">
            <Link to="/">
              <Button variant="outline">Back to VerdantOS</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  const isAgri = audience === "agribusiness";

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-yellow-50 py-10 px-4">
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-6">
          <Sprout className="h-12 w-12 mx-auto text-green-800" />
          <h1 className="text-3xl font-bold text-green-950 mt-2">
            {isAgri ? "Outgrower scheme monitoring — 4 minute survey" : "NGO programme monitoring — 4 minute survey"}
          </h1>
          <p className="text-muted-foreground mt-3">
            {isAgri
              ? "We're building a tool to help companies monitor their contracted farmers using satellite, weather and yield data. Before we build, we want to hear from people who actually run these schemes."
              : "We're building a tool to help NGOs monitor agricultural programmes — beneficiary tracking, geo-verified activities, and donor-grade outcome evidence. Before we build, we want to hear from M&E and programme staff."}
          </p>
        </div>

        {/* Audience switcher */}
        <div className="mb-6 flex justify-center">
          <div className="inline-flex rounded-lg border bg-background p-1" role="tablist" aria-label="Choose your organisation type">
            <button
              type="button"
              role="tab"
              aria-selected={isAgri}
              onClick={() => setAudience("agribusiness")}
              className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                isAgri ? "bg-green-900 text-white" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Building2 className="h-4 w-4" /> Agribusiness
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={!isAgri}
              onClick={() => setAudience("ngo")}
              className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                !isAgri ? "bg-green-900 text-white" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <HeartHandshake className="h-4 w-4" /> NGO / Programme
            </button>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* 1. Identity (shared) */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">1. About you</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid sm:grid-cols-2 gap-3">
                <div>
                  <Label htmlFor="d-name">Full name *</Label>
                  <Input id="d-name" value={name} onChange={e => setName(e.target.value)} required maxLength={120} />
                </div>
                <div>
                  <Label htmlFor="d-company">{isAgri ? "Company *" : "Organisation *"}</Label>
                  <Input id="d-company" value={company} onChange={e => setCompany(e.target.value)} required maxLength={160} />
                </div>
                <div>
                  <Label htmlFor="d-role">Your role *</Label>
                  <Input id="d-role" value={role} onChange={e => setRole(e.target.value)} required maxLength={120}
                    placeholder={isAgri ? "e.g. Outgrower Manager" : "e.g. M&E Officer, Programme Manager"} />
                </div>
                <div>
                  <Label htmlFor="d-email">Work email *</Label>
                  <Input id="d-email" type="email" value={email} onChange={e => setEmail(e.target.value)} required maxLength={255} />
                </div>
              </div>
            </CardContent>
          </Card>

          {isAgri ? (
            <>
              {/* Agri Q2 */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">2. Which best describes your relationship with farmers?</CardTitle>
                </CardHeader>
                <CardContent>
                  <RadioGroup value={relationship} onValueChange={setRelationship}>
                    {RELATIONSHIP_OPTIONS.map(o => (
                      <div key={o.value} className="flex items-center space-x-2">
                        <RadioGroupItem value={o.value} id={`rel-${o.value}`} />
                        <Label htmlFor={`rel-${o.value}`} className="font-normal cursor-pointer">{o.label}</Label>
                      </div>
                    ))}
                  </RadioGroup>
                </CardContent>
              </Card>

              {/* Agri Q3 */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">3. How many farmers do you work with?</CardTitle>
                </CardHeader>
                <CardContent>
                  <RadioGroup value={band} onValueChange={setBand}>
                    {FARMER_BANDS.map(o => (
                      <div key={o.value} className="flex items-center space-x-2">
                        <RadioGroupItem value={o.value} id={`band-${o.value}`} />
                        <Label htmlFor={`band-${o.value}`} className="font-normal cursor-pointer">{o.label}</Label>
                      </div>
                    ))}
                  </RadioGroup>
                </CardContent>
              </Card>

              {/* Agri Q4 */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">4. Rank these problems — most painful at the top</CardTitle>
                  <CardDescription>Use the arrows to reorder.</CardDescription>
                </CardHeader>
                <CardContent>
                  <ol className="space-y-2">
                    {agriPains.map((p, idx) => (
                      <li key={p.id} className="flex items-center gap-2 p-2 border rounded-md bg-background">
                        <span className="font-bold text-green-800 w-5 text-center">{idx + 1}</span>
                        <span className="flex-1 text-sm">{p.label}</span>
                        <Button type="button" size="icon" variant="ghost" onClick={() => movePain(agriPains, setAgriPains, idx, -1)} disabled={idx === 0} aria-label="Move up">
                          <ArrowUp className="h-4 w-4" />
                        </Button>
                        <Button type="button" size="icon" variant="ghost" onClick={() => movePain(agriPains, setAgriPains, idx, 1)} disabled={idx === agriPains.length - 1} aria-label="Move down">
                          <ArrowDown className="h-4 w-4" />
                        </Button>
                      </li>
                    ))}
                  </ol>
                </CardContent>
              </Card>

              {/* Agri Q5 */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">5. How do you currently monitor contracted farmers?</CardTitle>
                </CardHeader>
                <CardContent>
                  <RadioGroup value={monitoring} onValueChange={setMonitoring}>
                    {MONITORING_OPTIONS.map(o => (
                      <div key={o.value} className="flex items-center space-x-2">
                        <RadioGroupItem value={o.value} id={`mon-${o.value}`} />
                        <Label htmlFor={`mon-${o.value}`} className="font-normal cursor-pointer">{o.label}</Label>
                      </div>
                    ))}
                  </RadioGroup>
                </CardContent>
              </Card>

              {/* Agri Q6 */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">6. Would you pay $5 per farmer per season?</CardTitle>
                  <CardDescription>
                    For: satellite-verified crop monitoring, yield forecasts, and weekly alert digests on every contracted farm.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <RadioGroup value={wouldPay} onValueChange={(v) => setWouldPay(v as "yes" | "depends" | "no")}>
                    {WOULD_PAY_OPTIONS.map(o => (
                      <div key={o.value} className="flex items-center space-x-2">
                        <RadioGroupItem value={o.value} id={`pay-${o.value}`} />
                        <Label htmlFor={`pay-${o.value}`} className="font-normal cursor-pointer">{o.label}</Label>
                      </div>
                    ))}
                  </RadioGroup>
                  <div>
                    <Label htmlFor="d-paynotes" className="text-sm text-muted-foreground">
                      What would change your answer? (optional)
                    </Label>
                    <Textarea id="d-paynotes" value={wouldPayNotes}
                      onChange={e => setWouldPayNotes(e.target.value.slice(0, 500))} rows={2} maxLength={500} />
                  </div>
                </CardContent>
              </Card>

              {/* Agri Q7 */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">7. If you could fix one thing in your scheme operations tomorrow, what would it be?</CardTitle>
                </CardHeader>
                <CardContent>
                  <Textarea value={oneFix} onChange={e => setOneFix(e.target.value.slice(0, 500))}
                    rows={4} required maxLength={500} placeholder="In your own words..." />
                  <div className="text-xs text-muted-foreground text-right mt-1">{oneFix.length} / 500</div>
                </CardContent>
              </Card>
            </>
          ) : (
            <>
              {/* NGO Q2 */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">2. What kind of programme do you run?</CardTitle>
                </CardHeader>
                <CardContent>
                  <RadioGroup value={ngoProgram} onValueChange={setNgoProgram}>
                    {NGO_PROGRAM_TYPES.map(o => (
                      <div key={o.value} className="flex items-center space-x-2">
                        <RadioGroupItem value={o.value} id={`prog-${o.value}`} />
                        <Label htmlFor={`prog-${o.value}`} className="font-normal cursor-pointer">{o.label}</Label>
                      </div>
                    ))}
                  </RadioGroup>
                </CardContent>
              </Card>

              {/* NGO Q3 */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">3. Who funds the work?</CardTitle>
                </CardHeader>
                <CardContent>
                  <RadioGroup value={ngoFunder} onValueChange={setNgoFunder}>
                    {NGO_FUNDER_TYPES.map(o => (
                      <div key={o.value} className="flex items-center space-x-2">
                        <RadioGroupItem value={o.value} id={`fund-${o.value}`} />
                        <Label htmlFor={`fund-${o.value}`} className="font-normal cursor-pointer">{o.label}</Label>
                      </div>
                    ))}
                  </RadioGroup>
                </CardContent>
              </Card>

              {/* NGO Q4 */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">4. How many beneficiary farmers does the programme reach?</CardTitle>
                </CardHeader>
                <CardContent>
                  <RadioGroup value={ngoBeneficiary} onValueChange={setNgoBeneficiary}>
                    {NGO_BENEFICIARY_BANDS.map(o => (
                      <div key={o.value} className="flex items-center space-x-2">
                        <RadioGroupItem value={o.value} id={`ben-${o.value}`} />
                        <Label htmlFor={`ben-${o.value}`} className="font-normal cursor-pointer">{o.label}</Label>
                      </div>
                    ))}
                  </RadioGroup>
                </CardContent>
              </Card>

              {/* NGO Q5 */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">5. What M&amp;E tools do you use today?</CardTitle>
                </CardHeader>
                <CardContent>
                  <RadioGroup value={ngoMe} onValueChange={setNgoMe}>
                    {NGO_ME_TOOLS.map(o => (
                      <div key={o.value} className="flex items-center space-x-2">
                        <RadioGroupItem value={o.value} id={`me-${o.value}`} />
                        <Label htmlFor={`me-${o.value}`} className="font-normal cursor-pointer">{o.label}</Label>
                      </div>
                    ))}
                  </RadioGroup>
                </CardContent>
              </Card>

              {/* NGO Q6 - Pain ranking */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">6. Rank these problems — most painful at the top</CardTitle>
                  <CardDescription>Use the arrows to reorder.</CardDescription>
                </CardHeader>
                <CardContent>
                  <ol className="space-y-2">
                    {ngoPains.map((p, idx) => (
                      <li key={p.id} className="flex items-center gap-2 p-2 border rounded-md bg-background">
                        <span className="font-bold text-green-800 w-5 text-center">{idx + 1}</span>
                        <span className="flex-1 text-sm">{p.label}</span>
                        <Button type="button" size="icon" variant="ghost" onClick={() => movePain(ngoPains, setNgoPains, idx, -1)} disabled={idx === 0} aria-label="Move up">
                          <ArrowUp className="h-4 w-4" />
                        </Button>
                        <Button type="button" size="icon" variant="ghost" onClick={() => movePain(ngoPains, setNgoPains, idx, 1)} disabled={idx === ngoPains.length - 1} aria-label="Move down">
                          <ArrowDown className="h-4 w-4" />
                        </Button>
                      </li>
                    ))}
                  </ol>
                </CardContent>
              </Card>

              {/* NGO Q7 */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">7. How much of a burden is donor reporting on your team?</CardTitle>
                </CardHeader>
                <CardContent>
                  <RadioGroup value={ngoReportingBurden} onValueChange={setNgoReportingBurden}>
                    {NGO_REPORTING_BURDEN.map(o => (
                      <div key={o.value} className="flex items-center space-x-2">
                        <RadioGroupItem value={o.value} id={`burd-${o.value}`} />
                        <Label htmlFor={`burd-${o.value}`} className="font-normal cursor-pointer">{o.label}</Label>
                      </div>
                    ))}
                  </RadioGroup>
                </CardContent>
              </Card>

              {/* NGO Q8 */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">8. Realistic budget range for an M&amp;E / monitoring tool?</CardTitle>
                  <CardDescription>Per beneficiary, per year — what would a donor actually fund?</CardDescription>
                </CardHeader>
                <CardContent>
                  <RadioGroup value={ngoBudget} onValueChange={setNgoBudget}>
                    {NGO_BUDGET_BANDS.map(o => (
                      <div key={o.value} className="flex items-center space-x-2">
                        <RadioGroupItem value={o.value} id={`bud-${o.value}`} />
                        <Label htmlFor={`bud-${o.value}`} className="font-normal cursor-pointer">{o.label}</Label>
                      </div>
                    ))}
                  </RadioGroup>
                </CardContent>
              </Card>

              {/* NGO Q9 */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">9. If we built one feature that would unlock budget from your next proposal, what would it be?</CardTitle>
                </CardHeader>
                <CardContent>
                  <Textarea value={ngoMustHave} onChange={e => setNgoMustHave(e.target.value.slice(0, 500))}
                    rows={4} required maxLength={500} placeholder="Be specific — e.g. 'satellite-verified hectares planted with deduplicated beneficiary IDs for our climate adaptation log-frame'" />
                  <div className="text-xs text-muted-foreground text-right mt-1">{ngoMustHave.length} / 500</div>
                </CardContent>
              </Card>
            </>
          )}

          {/* Follow up (shared) */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Open to a follow-up?</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center space-x-2">
                <Checkbox id="d-followup" checked={followUp} onCheckedChange={(v) => setFollowUp(!!v)} />
                <Label htmlFor="d-followup" className="font-normal cursor-pointer">
                  Yes, happy to do a 20-minute call
                </Label>
              </div>
              {followUp && (
                <div>
                  <Label htmlFor="d-fcontact" className="text-sm">Best way to reach you (phone, WhatsApp, or just "use my email")</Label>
                  <Input id="d-fcontact" value={followUpContact}
                    onChange={e => setFollowUpContact(e.target.value.slice(0, 160))}
                    maxLength={160} placeholder="e.g. WhatsApp +263 77..." />
                </div>
              )}
            </CardContent>
          </Card>

          <Button type="submit" disabled={submitting} className="w-full bg-green-900 hover:bg-green-800 text-white" size="lg">
            {submitting ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Submitting...</> : "Submit answers"}
          </Button>
          <p className="text-xs text-muted-foreground text-center">
            Your answers are private. We'll only contact you if you ticked the follow-up box.
          </p>
        </form>
      </div>
    </div>
  );
};

export default Discovery;
