import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { CheckCircle2, AlertTriangle, XCircle, HelpCircle, Loader2 } from "lucide-react";

interface Component {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  display_order: number;
  latency_warning_ms: number;
  latency_critical_ms: number;
}
interface HealthCheck {
  component_id: string;
  status: "up" | "degraded" | "down" | "unknown";
  latency_ms: number | null;
  checked_at: string;
}
interface Incident {
  id: string;
  component_id: string | null;
  title: string;
  description: string | null;
  severity: string;
  status: string;
  started_at: string;
  resolved_at: string | null;
}

const STATUS_META: Record<string, { label: string; color: string; Icon: any }> = {
  up: { label: "Operational", color: "text-green-600", Icon: CheckCircle2 },
  degraded: { label: "Degraded", color: "text-amber-600", Icon: AlertTriangle },
  down: { label: "Outage", color: "text-red-600", Icon: XCircle },
  unknown: { label: "Unknown", color: "text-gray-500", Icon: HelpCircle },
};

const Status = () => {
  const [components, setComponents] = useState<Component[]>([]);
  const [latest, setLatest] = useState<Record<string, HealthCheck>>({});
  const [history, setHistory] = useState<Record<string, HealthCheck[]>>({});
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [loading, setLoading] = useState(true);
  const [lastRefresh, setLastRefresh] = useState<Date>(new Date());

  const load = async () => {
    const [{ data: comps }, { data: checks }, { data: incs }] = await Promise.all([
      supabase.from("service_components").select("*").eq("is_public", true).order("display_order"),
      supabase
        .from("service_health_checks")
        .select("component_id,status,latency_ms,checked_at")
        .gte("checked_at", new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString())
        .order("checked_at", { ascending: false })
        .limit(1000),
      supabase
        .from("incidents")
        .select("*")
        .gte("started_at", new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString())
        .order("started_at", { ascending: false }),
    ]);

    setComponents((comps as Component[]) || []);
    setIncidents((incs as Incident[]) || []);

    const latestByComp: Record<string, HealthCheck> = {};
    const historyByComp: Record<string, HealthCheck[]> = {};
    for (const c of (checks as HealthCheck[]) || []) {
      if (!latestByComp[c.component_id]) latestByComp[c.component_id] = c;
      if (!historyByComp[c.component_id]) historyByComp[c.component_id] = [];
      historyByComp[c.component_id].push(c);
    }
    setLatest(latestByComp);
    setHistory(historyByComp);
    setLastRefresh(new Date());
    setLoading(false);
  };

  useEffect(() => {
    load();
    const t = setInterval(load, 30_000);
    return () => clearInterval(t);
  }, []);

  const overall = useMemo(() => {
    if (components.length === 0) return "unknown";
    const statuses = components.map((c) => latest[c.id]?.status ?? "unknown");
    if (statuses.includes("down")) return "down";
    if (statuses.includes("degraded")) return "degraded";
    if (statuses.every((s) => s === "up")) return "up";
    return "unknown";
  }, [components, latest]);

  const uptimePct = (compId: string): number | null => {
    const h = history[compId];
    if (!h || h.length === 0) return null;
    const ups = h.filter((c) => c.status === "up").length;
    return (ups / h.length) * 100;
  };

  const overallMeta = STATUS_META[overall];
  const OverallIcon = overallMeta.Icon;
  const activeIncidents = incidents.filter((i) => i.status !== "resolved");

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-yellow-50">
      <header className="border-b bg-white">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link to="/" className="font-bold text-green-900 text-lg">VerdantIQ</Link>
          <span className="text-sm text-muted-foreground">Status</span>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-4xl space-y-6">
        <Card>
          <CardContent className="p-6 flex items-center gap-4">
            <OverallIcon className={`h-10 w-10 ${overallMeta.color}`} />
            <div className="flex-1">
              <h1 className="text-2xl font-bold">
                {overall === "up" ? "All systems operational" : `Some systems ${overallMeta.label.toLowerCase()}`}
              </h1>
              <p className="text-sm text-muted-foreground">
                Last checked {lastRefresh.toLocaleTimeString()} · auto-refreshes every 30s
              </p>
            </div>
            {loading && <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />}
          </CardContent>
        </Card>

        {activeIncidents.length > 0 && (
          <Card className="border-amber-300 bg-amber-50">
            <CardHeader>
              <CardTitle className="text-amber-900 text-base">Active incidents</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {activeIncidents.map((inc) => (
                <div key={inc.id} className="border-l-4 border-amber-500 pl-3">
                  <div className="font-semibold">{inc.title}</div>
                  <div className="text-xs text-muted-foreground">
                    {inc.severity} · {inc.status} · started {new Date(inc.started_at).toLocaleString()}
                  </div>
                  {inc.description && <p className="text-sm mt-1">{inc.description}</p>}
                </div>
              ))}
            </CardContent>
          </Card>
        )}

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Components</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {components.length === 0 && !loading && (
              <p className="text-sm text-muted-foreground">No components configured yet.</p>
            )}
            {components.map((c) => {
              const last = latest[c.id];
              const status = last?.status ?? "unknown";
              const meta = STATUS_META[status];
              const Icon = meta.Icon;
              const pct = uptimePct(c.id);
              return (
                <div
                  key={c.id}
                  className="flex items-center justify-between gap-3 py-3 border-b last:border-b-0"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <Icon className={`h-5 w-5 shrink-0 ${meta.color}`} />
                    <div className="min-w-0">
                      <div className="font-medium truncate">{c.name}</div>
                      {c.description && (
                        <div className="text-xs text-muted-foreground truncate">{c.description}</div>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-3 text-sm">
                    {last?.latency_ms != null && (
                      <span className="text-muted-foreground hidden sm:inline">{last.latency_ms} ms</span>
                    )}
                    {pct != null && (
                      <span className="text-muted-foreground hidden md:inline">
                        {pct.toFixed(1)}% (30d)
                      </span>
                    )}
                    <Badge variant="outline" className={meta.color}>{meta.label}</Badge>
                  </div>
                </div>
              );
            })}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Incident history (last 30 days)</CardTitle>
          </CardHeader>
          <CardContent>
            {incidents.length === 0 ? (
              <p className="text-sm text-muted-foreground">No incidents reported. 🎉</p>
            ) : (
              <ul className="space-y-3">
                {incidents.map((inc) => (
                  <li key={inc.id} className="border-l-2 border-gray-300 pl-3">
                    <div className="font-medium">{inc.title}</div>
                    <div className="text-xs text-muted-foreground">
                      {inc.severity} · {inc.status} ·{" "}
                      {new Date(inc.started_at).toLocaleDateString()}
                      {inc.resolved_at && ` → resolved ${new Date(inc.resolved_at).toLocaleDateString()}`}
                    </div>
                    {inc.description && <p className="text-sm mt-1">{inc.description}</p>}
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>

        <p className="text-center text-xs text-muted-foreground">
          Powered by VerdantIQ · <Link to="/" className="underline">Back to app</Link>
        </p>
      </main>
    </div>
  );
};

export default Status;
