export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.4"
  }
  public: {
    Tables: {
      agroecological_zones: {
        Row: {
          created_at: string
          description: string | null
          geometry: unknown
          id: string
          rainfall_max_mm: number | null
          rainfall_min_mm: number | null
          recommended_agroforestry: Json
          recommended_cover_crops: Json
          recommended_crops: Json
          region_code: string
          region_name: string
          typical_soil_constraints: Json
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          geometry?: unknown
          id?: string
          rainfall_max_mm?: number | null
          rainfall_min_mm?: number | null
          recommended_agroforestry?: Json
          recommended_cover_crops?: Json
          recommended_crops?: Json
          region_code: string
          region_name: string
          typical_soil_constraints?: Json
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          geometry?: unknown
          id?: string
          rainfall_max_mm?: number | null
          rainfall_min_mm?: number | null
          recommended_agroforestry?: Json
          recommended_cover_crops?: Json
          recommended_crops?: Json
          region_code?: string
          region_name?: string
          typical_soil_constraints?: Json
          updated_at?: string
        }
        Relationships: []
      }
      ai_interactions: {
        Row: {
          ai_response: string
          context_data: Json | null
          created_at: string
          feedback_comment: string | null
          feedback_rating: number | null
          id: string
          session_id: string
          updated_at: string
          user_id: string | null
          user_message: string
        }
        Insert: {
          ai_response: string
          context_data?: Json | null
          created_at?: string
          feedback_comment?: string | null
          feedback_rating?: number | null
          id?: string
          session_id?: string
          updated_at?: string
          user_id?: string | null
          user_message: string
        }
        Update: {
          ai_response?: string
          context_data?: Json | null
          created_at?: string
          feedback_comment?: string | null
          feedback_rating?: number | null
          id?: string
          session_id?: string
          updated_at?: string
          user_id?: string | null
          user_message?: string
        }
        Relationships: []
      }
      collection_requests: {
        Row: {
          assigned_vehicle_id: string | null
          created_at: string
          crop_cycle_id: string
          id: string
          provider_id: string | null
          request_date: string
          scheduled_pickup_date: string | null
          status: string
        }
        Insert: {
          assigned_vehicle_id?: string | null
          created_at?: string
          crop_cycle_id: string
          id?: string
          provider_id?: string | null
          request_date?: string
          scheduled_pickup_date?: string | null
          status?: string
        }
        Update: {
          assigned_vehicle_id?: string | null
          created_at?: string
          crop_cycle_id?: string
          id?: string
          provider_id?: string | null
          request_date?: string
          scheduled_pickup_date?: string | null
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "collection_requests_crop_cycle_id_fkey"
            columns: ["crop_cycle_id"]
            isOneToOne: false
            referencedRelation: "crop_cycles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "collection_requests_provider_id_fkey"
            columns: ["provider_id"]
            isOneToOne: false
            referencedRelation: "logistics_providers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "collection_requests_provider_id_fkey"
            columns: ["provider_id"]
            isOneToOne: false
            referencedRelation: "logistics_providers_public"
            referencedColumns: ["id"]
          },
        ]
      }
      collection_status_events: {
        Row: {
          collection_request_id: string
          created_at: string
          created_by: string
          id: string
          note: string | null
          status: string
        }
        Insert: {
          collection_request_id: string
          created_at?: string
          created_by?: string
          id?: string
          note?: string | null
          status: string
        }
        Update: {
          collection_request_id?: string
          created_at?: string
          created_by?: string
          id?: string
          note?: string | null
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "collection_status_events_collection_request_id_fkey"
            columns: ["collection_request_id"]
            isOneToOne: false
            referencedRelation: "collection_requests"
            referencedColumns: ["id"]
          },
        ]
      }
      commodities: {
        Row: {
          category: string
          created_at: string
          id: string
          is_active: boolean
          name: string
          slug: string
          unit: string
        }
        Insert: {
          category: string
          created_at?: string
          id?: string
          is_active?: boolean
          name: string
          slug: string
          unit?: string
        }
        Update: {
          category?: string
          created_at?: string
          id?: string
          is_active?: boolean
          name?: string
          slug?: string
          unit?: string
        }
        Relationships: []
      }
      conversations: {
        Row: {
          ai_response: string
          context_used: Json | null
          created_at: string | null
          farm_context: Json | null
          id: string
          message_type: string | null
          satisfaction_score: number | null
          user_id: string
          user_message: string
        }
        Insert: {
          ai_response: string
          context_used?: Json | null
          created_at?: string | null
          farm_context?: Json | null
          id?: string
          message_type?: string | null
          satisfaction_score?: number | null
          user_id: string
          user_message: string
        }
        Update: {
          ai_response?: string
          context_used?: Json | null
          created_at?: string | null
          farm_context?: Json | null
          id?: string
          message_type?: string | null
          satisfaction_score?: number | null
          user_id?: string
          user_message?: string
        }
        Relationships: []
      }
      crop_cycles: {
        Row: {
          actual_yield_tonnes: number | null
          area_hectares: number
          created_at: string
          crop_type: string
          estimated_harvest_date: string | null
          farm_id: string
          id: string
          planting_date: string | null
          predicted_yield_tonnes: number | null
          status: string
        }
        Insert: {
          actual_yield_tonnes?: number | null
          area_hectares: number
          created_at?: string
          crop_type: string
          estimated_harvest_date?: string | null
          farm_id: string
          id?: string
          planting_date?: string | null
          predicted_yield_tonnes?: number | null
          status?: string
        }
        Update: {
          actual_yield_tonnes?: number | null
          area_hectares?: number
          created_at?: string
          crop_type?: string
          estimated_harvest_date?: string | null
          farm_id?: string
          id?: string
          planting_date?: string | null
          predicted_yield_tonnes?: number | null
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "crop_cycles_farm_id_fkey"
            columns: ["farm_id"]
            isOneToOne: false
            referencedRelation: "farms"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "crop_cycles_farm_id_fkey"
            columns: ["farm_id"]
            isOneToOne: false
            referencedRelation: "soil_health_cards"
            referencedColumns: ["farm_id"]
          },
        ]
      }
      cycle_tasks: {
        Row: {
          created_at: string
          crop_cycle_id: string
          due_date: string
          id: string
          is_completed: boolean
          notes: string | null
          task_name: string
        }
        Insert: {
          created_at?: string
          crop_cycle_id: string
          due_date: string
          id?: string
          is_completed?: boolean
          notes?: string | null
          task_name: string
        }
        Update: {
          created_at?: string
          crop_cycle_id?: string
          due_date?: string
          id?: string
          is_completed?: boolean
          notes?: string | null
          task_name?: string
        }
        Relationships: [
          {
            foreignKeyName: "cycle_tasks_crop_cycle_id_fkey"
            columns: ["crop_cycle_id"]
            isOneToOne: false
            referencedRelation: "crop_cycles"
            referencedColumns: ["id"]
          },
        ]
      }
      data_access_log: {
        Row: {
          action: string
          actor_user_id: string | null
          created_at: string
          id: string
          ip_address: string | null
          metadata: Json
          organization_id: string | null
          target_id: string | null
          target_type: string | null
        }
        Insert: {
          action: string
          actor_user_id?: string | null
          created_at?: string
          id?: string
          ip_address?: string | null
          metadata?: Json
          organization_id?: string | null
          target_id?: string | null
          target_type?: string | null
        }
        Update: {
          action?: string
          actor_user_id?: string | null
          created_at?: string
          id?: string
          ip_address?: string | null
          metadata?: Json
          organization_id?: string | null
          target_id?: string | null
          target_type?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "data_access_log_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      data_license_acceptance: {
        Row: {
          accepted_at: string
          accepted_by_user_id: string
          id: string
          ip_address: string | null
          license_text_hash: string | null
          license_version: string
          organization_id: string
          user_agent: string | null
        }
        Insert: {
          accepted_at?: string
          accepted_by_user_id: string
          id?: string
          ip_address?: string | null
          license_text_hash?: string | null
          license_version: string
          organization_id: string
          user_agent?: string | null
        }
        Update: {
          accepted_at?: string
          accepted_by_user_id?: string
          id?: string
          ip_address?: string | null
          license_text_hash?: string | null
          license_version?: string
          organization_id?: string
          user_agent?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "data_license_acceptance_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      discovery_responses: {
        Row: {
          audience: string
          company: string
          created_at: string
          current_monitoring: string | null
          email: string
          farmer_count_band: string | null
          follow_up_contact: string | null
          follow_up_ok: boolean
          id: string
          name: string
          ngo_beneficiary_band: string | null
          ngo_budget_band: string | null
          ngo_funder_type: string | null
          ngo_me_tools: string | null
          ngo_must_have: string | null
          ngo_pain_ranking: Json | null
          ngo_program_type: string | null
          ngo_reporting_burden: string | null
          one_fix: string | null
          pain_ranking: Json
          relationship_type: string | null
          role: string
          source: string | null
          user_agent: string | null
          would_pay: string | null
          would_pay_notes: string | null
        }
        Insert: {
          audience?: string
          company: string
          created_at?: string
          current_monitoring?: string | null
          email: string
          farmer_count_band?: string | null
          follow_up_contact?: string | null
          follow_up_ok?: boolean
          id?: string
          name: string
          ngo_beneficiary_band?: string | null
          ngo_budget_band?: string | null
          ngo_funder_type?: string | null
          ngo_me_tools?: string | null
          ngo_must_have?: string | null
          ngo_pain_ranking?: Json | null
          ngo_program_type?: string | null
          ngo_reporting_burden?: string | null
          one_fix?: string | null
          pain_ranking?: Json
          relationship_type?: string | null
          role: string
          source?: string | null
          user_agent?: string | null
          would_pay?: string | null
          would_pay_notes?: string | null
        }
        Update: {
          audience?: string
          company?: string
          created_at?: string
          current_monitoring?: string | null
          email?: string
          farmer_count_band?: string | null
          follow_up_contact?: string | null
          follow_up_ok?: boolean
          id?: string
          name?: string
          ngo_beneficiary_band?: string | null
          ngo_budget_band?: string | null
          ngo_funder_type?: string | null
          ngo_me_tools?: string | null
          ngo_must_have?: string | null
          ngo_pain_ranking?: Json | null
          ngo_program_type?: string | null
          ngo_reporting_burden?: string | null
          one_fix?: string | null
          pain_ranking?: Json
          relationship_type?: string | null
          role?: string
          source?: string | null
          user_agent?: string | null
          would_pay?: string | null
          would_pay_notes?: string | null
        }
        Relationships: []
      }
      equipment: {
        Row: {
          acquisition_cost_usd: number | null
          category: Database["public"]["Enums"]["equipment_category"] | null
          condition: Database["public"]["Enums"]["equipment_condition"] | null
          created_at: string | null
          farm_id: string
          horsepower: number | null
          id: string
          is_operational: boolean | null
          maintenance_schedule: Json | null
          model: string | null
          name: string
          ownership: Database["public"]["Enums"]["ownership_type"] | null
          power_source: Database["public"]["Enums"]["power_source"] | null
          purchase_date: string | null
          status: string | null
          type: string
          updated_at: string | null
        }
        Insert: {
          acquisition_cost_usd?: number | null
          category?: Database["public"]["Enums"]["equipment_category"] | null
          condition?: Database["public"]["Enums"]["equipment_condition"] | null
          created_at?: string | null
          farm_id: string
          horsepower?: number | null
          id?: string
          is_operational?: boolean | null
          maintenance_schedule?: Json | null
          model?: string | null
          name: string
          ownership?: Database["public"]["Enums"]["ownership_type"] | null
          power_source?: Database["public"]["Enums"]["power_source"] | null
          purchase_date?: string | null
          status?: string | null
          type: string
          updated_at?: string | null
        }
        Update: {
          acquisition_cost_usd?: number | null
          category?: Database["public"]["Enums"]["equipment_category"] | null
          condition?: Database["public"]["Enums"]["equipment_condition"] | null
          created_at?: string | null
          farm_id?: string
          horsepower?: number | null
          id?: string
          is_operational?: boolean | null
          maintenance_schedule?: Json | null
          model?: string | null
          name?: string
          ownership?: Database["public"]["Enums"]["ownership_type"] | null
          power_source?: Database["public"]["Enums"]["power_source"] | null
          purchase_date?: string | null
          status?: string | null
          type?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      farm_polygons: {
        Row: {
          agromonitoring_polygon_id: string
          area_ha: number
          created_at: string
          farm_id: string
          id: string
        }
        Insert: {
          agromonitoring_polygon_id: string
          area_ha?: number
          created_at?: string
          farm_id: string
          id?: string
        }
        Update: {
          agromonitoring_polygon_id?: string
          area_ha?: number
          created_at?: string
          farm_id?: string
          id?: string
        }
        Relationships: []
      }
      farm_practices: {
        Row: {
          adoption_score: number | null
          agroforestry_species: string[] | null
          conservation_ag_methods: string[] | null
          cover_crops: string[] | null
          created_at: string
          farm_id: string
          id: string
          intercrops: Json | null
          notes: string | null
          organic_inputs: Json | null
          rotation_sequence: string[] | null
          season: string
          updated_at: string
        }
        Insert: {
          adoption_score?: number | null
          agroforestry_species?: string[] | null
          conservation_ag_methods?: string[] | null
          cover_crops?: string[] | null
          created_at?: string
          farm_id: string
          id?: string
          intercrops?: Json | null
          notes?: string | null
          organic_inputs?: Json | null
          rotation_sequence?: string[] | null
          season: string
          updated_at?: string
        }
        Update: {
          adoption_score?: number | null
          agroforestry_species?: string[] | null
          conservation_ag_methods?: string[] | null
          cover_crops?: string[] | null
          created_at?: string
          farm_id?: string
          id?: string
          intercrops?: Json | null
          notes?: string | null
          organic_inputs?: Json | null
          rotation_sequence?: string[] | null
          season?: string
          updated_at?: string
        }
        Relationships: []
      }
      farm_reports: {
        Row: {
          content: Json
          created_by: string | null
          farm_id: string
          generated_at: string | null
          id: string
          period_end: string | null
          period_start: string | null
          report_type: string
          title: string
        }
        Insert: {
          content: Json
          created_by?: string | null
          farm_id: string
          generated_at?: string | null
          id?: string
          period_end?: string | null
          period_start?: string | null
          report_type: string
          title: string
        }
        Update: {
          content?: Json
          created_by?: string | null
          farm_id?: string
          generated_at?: string | null
          id?: string
          period_end?: string | null
          period_start?: string | null
          report_type?: string
          title?: string
        }
        Relationships: []
      }
      farms: {
        Row: {
          agroecological_zone_id: string | null
          boundary: unknown
          created_at: string
          farming_type: Database["public"]["Enums"]["farming_type"] | null
          id: string
          latitude: number | null
          location: string | null
          longitude: number | null
          name: string
          size_hectares: number | null
          soil_confidence: Database["public"]["Enums"]["soil_confidence_level"]
          user_id: string
        }
        Insert: {
          agroecological_zone_id?: string | null
          boundary?: unknown
          created_at?: string
          farming_type?: Database["public"]["Enums"]["farming_type"] | null
          id?: string
          latitude?: number | null
          location?: string | null
          longitude?: number | null
          name: string
          size_hectares?: number | null
          soil_confidence?: Database["public"]["Enums"]["soil_confidence_level"]
          user_id: string
        }
        Update: {
          agroecological_zone_id?: string | null
          boundary?: unknown
          created_at?: string
          farming_type?: Database["public"]["Enums"]["farming_type"] | null
          id?: string
          latitude?: number | null
          location?: string | null
          longitude?: number | null
          name?: string
          size_hectares?: number | null
          soil_confidence?: Database["public"]["Enums"]["soil_confidence_level"]
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "farms_agroecological_zone_id_fkey"
            columns: ["agroecological_zone_id"]
            isOneToOne: false
            referencedRelation: "agroecological_zones"
            referencedColumns: ["id"]
          },
        ]
      }
      fields: {
        Row: {
          area_hectares: number | null
          boundary: unknown
          created_at: string
          farm_id: string
          id: string
          is_default: boolean
          name: string
          updated_at: string
        }
        Insert: {
          area_hectares?: number | null
          boundary?: unknown
          created_at?: string
          farm_id: string
          id?: string
          is_default?: boolean
          name?: string
          updated_at?: string
        }
        Update: {
          area_hectares?: number | null
          boundary?: unknown
          created_at?: string
          farm_id?: string
          id?: string
          is_default?: boolean
          name?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "fields_farm_id_fkey"
            columns: ["farm_id"]
            isOneToOne: false
            referencedRelation: "farms"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fields_farm_id_fkey"
            columns: ["farm_id"]
            isOneToOne: false
            referencedRelation: "soil_health_cards"
            referencedColumns: ["farm_id"]
          },
        ]
      }
      goods_received_notes: {
        Row: {
          collection_request_id: string
          created_at: string
          farmer_confirmation_signature: string | null
          id: string
          quality_grade: string | null
          quantity_bags: number | null
          received_by_driver_signature: string | null
          weight_tonnes: number
        }
        Insert: {
          collection_request_id: string
          created_at?: string
          farmer_confirmation_signature?: string | null
          id?: string
          quality_grade?: string | null
          quantity_bags?: number | null
          received_by_driver_signature?: string | null
          weight_tonnes: number
        }
        Update: {
          collection_request_id?: string
          created_at?: string
          farmer_confirmation_signature?: string | null
          id?: string
          quality_grade?: string | null
          quantity_bags?: number | null
          received_by_driver_signature?: string | null
          weight_tonnes?: number
        }
        Relationships: [
          {
            foreignKeyName: "goods_received_notes_collection_request_id_fkey"
            columns: ["collection_request_id"]
            isOneToOne: false
            referencedRelation: "collection_requests"
            referencedColumns: ["id"]
          },
        ]
      }
      incidents: {
        Row: {
          component_id: string | null
          created_at: string
          created_by: string | null
          description: string | null
          id: string
          resolved_at: string | null
          severity: string
          started_at: string
          status: string
          title: string
          updated_at: string
        }
        Insert: {
          component_id?: string | null
          created_at?: string
          created_by?: string | null
          description?: string | null
          id?: string
          resolved_at?: string | null
          severity?: string
          started_at?: string
          status?: string
          title: string
          updated_at?: string
        }
        Update: {
          component_id?: string | null
          created_at?: string
          created_by?: string | null
          description?: string | null
          id?: string
          resolved_at?: string | null
          severity?: string
          started_at?: string
          status?: string
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "incidents_component_id_fkey"
            columns: ["component_id"]
            isOneToOne: false
            referencedRelation: "service_components"
            referencedColumns: ["id"]
          },
        ]
      }
      kb_chunks: {
        Row: {
          chunk_index: number
          content: string
          created_at: string
          document_id: string
          embedding: string | null
          id: string
          metadata: Json
          model_version: string
          token_count: number | null
        }
        Insert: {
          chunk_index: number
          content: string
          created_at?: string
          document_id: string
          embedding?: string | null
          id?: string
          metadata?: Json
          model_version?: string
          token_count?: number | null
        }
        Update: {
          chunk_index?: number
          content?: string
          created_at?: string
          document_id?: string
          embedding?: string | null
          id?: string
          metadata?: Json
          model_version?: string
          token_count?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "kb_chunks_document_id_fkey"
            columns: ["document_id"]
            isOneToOne: false
            referencedRelation: "kb_documents"
            referencedColumns: ["id"]
          },
        ]
      }
      kb_documents: {
        Row: {
          chunk_count: number
          created_at: string
          crop: string | null
          id: string
          language: string
          model_version: string
          notes: string | null
          page_count: number | null
          region: string | null
          source: string | null
          storage_path: string | null
          tags: string[]
          title: string
          updated_at: string
          uploaded_by: string | null
        }
        Insert: {
          chunk_count?: number
          created_at?: string
          crop?: string | null
          id?: string
          language?: string
          model_version?: string
          notes?: string | null
          page_count?: number | null
          region?: string | null
          source?: string | null
          storage_path?: string | null
          tags?: string[]
          title: string
          updated_at?: string
          uploaded_by?: string | null
        }
        Update: {
          chunk_count?: number
          created_at?: string
          crop?: string | null
          id?: string
          language?: string
          model_version?: string
          notes?: string | null
          page_count?: number | null
          region?: string | null
          source?: string | null
          storage_path?: string | null
          tags?: string[]
          title?: string
          updated_at?: string
          uploaded_by?: string | null
        }
        Relationships: []
      }
      kb_query_log: {
        Row: {
          created_at: string
          filter_crop: string | null
          filter_language: string | null
          filter_region: string | null
          id: string
          query: string | null
          surface: string | null
          top_chunk_ids: string[] | null
          top_similarity: number | null
          user_id: string | null
        }
        Insert: {
          created_at?: string
          filter_crop?: string | null
          filter_language?: string | null
          filter_region?: string | null
          id?: string
          query?: string | null
          surface?: string | null
          top_chunk_ids?: string[] | null
          top_similarity?: number | null
          user_id?: string | null
        }
        Update: {
          created_at?: string
          filter_crop?: string | null
          filter_language?: string | null
          filter_region?: string | null
          id?: string
          query?: string | null
          surface?: string | null
          top_chunk_ids?: string[] | null
          top_similarity?: number | null
          user_id?: string | null
        }
        Relationships: []
      }
      knowledge_interactions: {
        Row: {
          created_at: string | null
          farm_context: Json | null
          id: string
          importance_score: number | null
          interaction_summary: string
          key_topics: string[] | null
          user_id: string
          vectorized: boolean | null
        }
        Insert: {
          created_at?: string | null
          farm_context?: Json | null
          id?: string
          importance_score?: number | null
          interaction_summary: string
          key_topics?: string[] | null
          user_id: string
          vectorized?: boolean | null
        }
        Update: {
          created_at?: string | null
          farm_context?: Json | null
          id?: string
          importance_score?: number | null
          interaction_summary?: string
          key_topics?: string[] | null
          user_id?: string
          vectorized?: boolean | null
        }
        Relationships: []
      }
      livestock_events: {
        Row: {
          created_at: string
          event_date: string
          event_type: string
          herd_id: string
          id: string
          notes: string | null
          quantity: number | null
          value_usd: number | null
        }
        Insert: {
          created_at?: string
          event_date?: string
          event_type: string
          herd_id: string
          id?: string
          notes?: string | null
          quantity?: number | null
          value_usd?: number | null
        }
        Update: {
          created_at?: string
          event_date?: string
          event_type?: string
          herd_id?: string
          id?: string
          notes?: string | null
          quantity?: number | null
          value_usd?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "livestock_events_herd_id_fkey"
            columns: ["herd_id"]
            isOneToOne: false
            referencedRelation: "livestock_herds"
            referencedColumns: ["id"]
          },
        ]
      }
      livestock_herds: {
        Row: {
          breed: string | null
          created_at: string
          farm_id: string
          herd_size: number
          housing_type: string | null
          id: string
          notes: string | null
          purpose: string | null
          species: string
          start_date: string | null
          status: string
          updated_at: string
        }
        Insert: {
          breed?: string | null
          created_at?: string
          farm_id: string
          herd_size?: number
          housing_type?: string | null
          id?: string
          notes?: string | null
          purpose?: string | null
          species: string
          start_date?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          breed?: string | null
          created_at?: string
          farm_id?: string
          herd_size?: number
          housing_type?: string | null
          id?: string
          notes?: string | null
          purpose?: string | null
          species?: string
          start_date?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      logistics_providers: {
        Row: {
          contact_email: string | null
          contact_phone: string | null
          created_at: string
          id: string
          is_active: boolean
          name: string
          region: string | null
        }
        Insert: {
          contact_email?: string | null
          contact_phone?: string | null
          created_at?: string
          id?: string
          is_active?: boolean
          name: string
          region?: string | null
        }
        Update: {
          contact_email?: string | null
          contact_phone?: string | null
          created_at?: string
          id?: string
          is_active?: boolean
          name?: string
          region?: string | null
        }
        Relationships: []
      }
      market_price_history: {
        Row: {
          created_at: string | null
          crop: string
          currency: string
          id: string
          market_location: string | null
          price: number
          price_change: number | null
          recorded_date: string
          region: string
          source: string | null
          unit: string
        }
        Insert: {
          created_at?: string | null
          crop: string
          currency?: string
          id?: string
          market_location?: string | null
          price: number
          price_change?: number | null
          recorded_date?: string
          region: string
          source?: string | null
          unit?: string
        }
        Update: {
          created_at?: string | null
          crop?: string
          currency?: string
          id?: string
          market_location?: string | null
          price?: number
          price_change?: number | null
          recorded_date?: string
          region?: string
          source?: string | null
          unit?: string
        }
        Relationships: []
      }
      market_prices: {
        Row: {
          created_at: string | null
          created_by: string | null
          crop: string
          currency: string
          id: string
          last_updated: string | null
          market_location: string | null
          price: number
          price_change: number | null
          region: string
          source: string | null
          unit: string
        }
        Insert: {
          created_at?: string | null
          created_by?: string | null
          crop: string
          currency?: string
          id?: string
          last_updated?: string | null
          market_location?: string | null
          price: number
          price_change?: number | null
          region: string
          source?: string | null
          unit?: string
        }
        Update: {
          created_at?: string | null
          created_by?: string | null
          crop?: string
          currency?: string
          id?: string
          last_updated?: string | null
          market_location?: string | null
          price?: number
          price_change?: number | null
          region?: string
          source?: string | null
          unit?: string
        }
        Relationships: []
      }
      mbare_market_prices: {
        Row: {
          captured_at: string | null
          id: string
          item: string
          quantity: string
          source: string | null
          source_type: string
          usd_price: number
          zig_price: number
        }
        Insert: {
          captured_at?: string | null
          id?: string
          item: string
          quantity: string
          source?: string | null
          source_type?: string
          usd_price: number
          zig_price: number
        }
        Update: {
          captured_at?: string | null
          id?: string
          item?: string
          quantity?: string
          source?: string | null
          source_type?: string
          usd_price?: number
          zig_price?: number
        }
        Relationships: []
      }
      mbare_price_audit: {
        Row: {
          action: string
          actor_id: string | null
          actor_role: string | null
          after: Json | null
          before: Json | null
          created_at: string
          id: string
          item: string | null
          note: string | null
          price_id: string | null
          source_type: string | null
        }
        Insert: {
          action: string
          actor_id?: string | null
          actor_role?: string | null
          after?: Json | null
          before?: Json | null
          created_at?: string
          id?: string
          item?: string | null
          note?: string | null
          price_id?: string | null
          source_type?: string | null
        }
        Update: {
          action?: string
          actor_id?: string | null
          actor_role?: string | null
          after?: Json | null
          before?: Json | null
          created_at?: string
          id?: string
          item?: string | null
          note?: string | null
          price_id?: string | null
          source_type?: string | null
        }
        Relationships: []
      }
      mbare_price_history: {
        Row: {
          created_at: string | null
          id: string
          item: string
          quantity: string
          recorded_date: string
          source: string | null
          usd_price: number
          zig_price: number
        }
        Insert: {
          created_at?: string | null
          id?: string
          item: string
          quantity: string
          recorded_date?: string
          source?: string | null
          usd_price: number
          zig_price: number
        }
        Update: {
          created_at?: string | null
          id?: string
          item?: string
          quantity?: string
          recorded_date?: string
          source?: string | null
          usd_price?: number
          zig_price?: number
        }
        Relationships: []
      }
      message_log: {
        Row: {
          channel: string
          created_at: string | null
          direction: string
          id: string
          message_content: string
          metadata: Json | null
          status: string | null
          user_id: string | null
        }
        Insert: {
          channel: string
          created_at?: string | null
          direction: string
          id?: string
          message_content: string
          metadata?: Json | null
          status?: string | null
          user_id?: string | null
        }
        Update: {
          channel?: string
          created_at?: string | null
          direction?: string
          id?: string
          message_content?: string
          metadata?: Json | null
          status?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      messaging_preferences: {
        Row: {
          created_at: string | null
          id: string
          language: string | null
          phone_number: string | null
          preferred_channel: string | null
          price_alerts_enabled: boolean | null
          sms_enabled: boolean | null
          task_reminders_enabled: boolean | null
          updated_at: string | null
          user_id: string
          weather_alerts_enabled: boolean | null
          whatsapp_enabled: boolean | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          language?: string | null
          phone_number?: string | null
          preferred_channel?: string | null
          price_alerts_enabled?: boolean | null
          sms_enabled?: boolean | null
          task_reminders_enabled?: boolean | null
          updated_at?: string | null
          user_id: string
          weather_alerts_enabled?: boolean | null
          whatsapp_enabled?: boolean | null
        }
        Update: {
          created_at?: string | null
          id?: string
          language?: string | null
          phone_number?: string | null
          preferred_channel?: string | null
          price_alerts_enabled?: boolean | null
          sms_enabled?: boolean | null
          task_reminders_enabled?: boolean | null
          updated_at?: string | null
          user_id?: string
          weather_alerts_enabled?: boolean | null
          whatsapp_enabled?: boolean | null
        }
        Relationships: []
      }
      ndvi_anomalies: {
        Row: {
          created_at: string
          crop_context: Json | null
          detected_at: string
          diagnosis: string | null
          drop_pct: number | null
          farm_id: string
          id: string
          language: string | null
          ndvi_current: number
          ndvi_previous: number | null
          notified_dashboard: boolean
          notified_whatsapp: boolean
          recommended_actions: Json | null
          resolved_at: string | null
          severity: string
          trigger_reason: string
        }
        Insert: {
          created_at?: string
          crop_context?: Json | null
          detected_at?: string
          diagnosis?: string | null
          drop_pct?: number | null
          farm_id: string
          id?: string
          language?: string | null
          ndvi_current: number
          ndvi_previous?: number | null
          notified_dashboard?: boolean
          notified_whatsapp?: boolean
          recommended_actions?: Json | null
          resolved_at?: string | null
          severity?: string
          trigger_reason: string
        }
        Update: {
          created_at?: string
          crop_context?: Json | null
          detected_at?: string
          diagnosis?: string | null
          drop_pct?: number | null
          farm_id?: string
          id?: string
          language?: string | null
          ndvi_current?: number
          ndvi_previous?: number | null
          notified_dashboard?: boolean
          notified_whatsapp?: boolean
          recommended_actions?: Json | null
          resolved_at?: string | null
          severity?: string
          trigger_reason?: string
        }
        Relationships: []
      }
      notifications: {
        Row: {
          created_at: string | null
          expires_at: string | null
          id: string
          is_read: boolean | null
          message: string
          metadata: Json | null
          recipient_user_id: string
          sender_user_id: string | null
          title: string
          type: string | null
        }
        Insert: {
          created_at?: string | null
          expires_at?: string | null
          id?: string
          is_read?: boolean | null
          message: string
          metadata?: Json | null
          recipient_user_id: string
          sender_user_id?: string | null
          title: string
          type?: string | null
        }
        Update: {
          created_at?: string | null
          expires_at?: string | null
          id?: string
          is_read?: boolean | null
          message?: string
          metadata?: Json | null
          recipient_user_id?: string
          sender_user_id?: string | null
          title?: string
          type?: string | null
        }
        Relationships: []
      }
      org_branding: {
        Row: {
          accent_color: string | null
          contact_email: string | null
          contact_phone: string | null
          logo_url: string | null
          organization_id: string
          primary_color: string | null
          tagline: string | null
          updated_at: string
          website_url: string | null
        }
        Insert: {
          accent_color?: string | null
          contact_email?: string | null
          contact_phone?: string | null
          logo_url?: string | null
          organization_id: string
          primary_color?: string | null
          tagline?: string | null
          updated_at?: string
          website_url?: string | null
        }
        Update: {
          accent_color?: string | null
          contact_email?: string | null
          contact_phone?: string | null
          logo_url?: string | null
          organization_id?: string
          primary_color?: string | null
          tagline?: string | null
          updated_at?: string
          website_url?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "org_branding_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: true
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      org_members: {
        Row: {
          accepted_at: string | null
          created_at: string
          id: string
          invited_at: string
          invited_by: string | null
          organization_id: string
          role: Database["public"]["Enums"]["org_role"]
          user_id: string
        }
        Insert: {
          accepted_at?: string | null
          created_at?: string
          id?: string
          invited_at?: string
          invited_by?: string | null
          organization_id: string
          role?: Database["public"]["Enums"]["org_role"]
          user_id: string
        }
        Update: {
          accepted_at?: string | null
          created_at?: string
          id?: string
          invited_at?: string
          invited_by?: string | null
          organization_id?: string
          role?: Database["public"]["Enums"]["org_role"]
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "org_members_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      organizations: {
        Row: {
          created_at: string
          created_by: string | null
          id: string
          metadata: Json
          name: string
          pilot_expires_at: string | null
          plan: Database["public"]["Enums"]["org_plan"]
          region_id: string | null
          slug: string
          status: Database["public"]["Enums"]["org_status"]
          type: Database["public"]["Enums"]["org_type"]
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          id?: string
          metadata?: Json
          name: string
          pilot_expires_at?: string | null
          plan?: Database["public"]["Enums"]["org_plan"]
          region_id?: string | null
          slug: string
          status?: Database["public"]["Enums"]["org_status"]
          type: Database["public"]["Enums"]["org_type"]
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          id?: string
          metadata?: Json
          name?: string
          pilot_expires_at?: string | null
          plan?: Database["public"]["Enums"]["org_plan"]
          region_id?: string | null
          slug?: string
          status?: Database["public"]["Enums"]["org_status"]
          type?: Database["public"]["Enums"]["org_type"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "organizations_region_id_fkey"
            columns: ["region_id"]
            isOneToOne: false
            referencedRelation: "regions"
            referencedColumns: ["id"]
          },
        ]
      }
      platform_feedback: {
        Row: {
          admin_note: string | null
          app_version: string | null
          created_at: string
          feedback_type: string
          id: string
          message: string
          page_route: string | null
          rating: number | null
          status: string
          updated_at: string
          user_agent: string | null
          user_id: string | null
          viewport: string | null
        }
        Insert: {
          admin_note?: string | null
          app_version?: string | null
          created_at?: string
          feedback_type?: string
          id?: string
          message: string
          page_route?: string | null
          rating?: number | null
          status?: string
          updated_at?: string
          user_agent?: string | null
          user_id?: string | null
          viewport?: string | null
        }
        Update: {
          admin_note?: string | null
          app_version?: string | null
          created_at?: string
          feedback_type?: string
          id?: string
          message?: string
          page_route?: string | null
          rating?: number | null
          status?: string
          updated_at?: string
          user_agent?: string | null
          user_id?: string | null
          viewport?: string | null
        }
        Relationships: []
      }
      profiles: {
        Row: {
          created_at: string | null
          crops_of_interest: string[] | null
          email: string | null
          farming_type: Database["public"]["Enums"]["farming_type"] | null
          full_name: string | null
          id: string
          is_admin: boolean | null
          livestock_of_interest: string[] | null
          preferred_language: string | null
          region: string | null
          updated_at: string | null
          value_chain_stage: string | null
        }
        Insert: {
          created_at?: string | null
          crops_of_interest?: string[] | null
          email?: string | null
          farming_type?: Database["public"]["Enums"]["farming_type"] | null
          full_name?: string | null
          id: string
          is_admin?: boolean | null
          livestock_of_interest?: string[] | null
          preferred_language?: string | null
          region?: string | null
          updated_at?: string | null
          value_chain_stage?: string | null
        }
        Update: {
          created_at?: string | null
          crops_of_interest?: string[] | null
          email?: string | null
          farming_type?: Database["public"]["Enums"]["farming_type"] | null
          full_name?: string | null
          id?: string
          is_admin?: boolean | null
          livestock_of_interest?: string[] | null
          preferred_language?: string | null
          region?: string | null
          updated_at?: string | null
          value_chain_stage?: string | null
        }
        Relationships: []
      }
      regions: {
        Row: {
          code: string
          country_code: string
          created_at: string
          id: string
          name: string
          parent_region_id: string | null
        }
        Insert: {
          code: string
          country_code: string
          created_at?: string
          id?: string
          name: string
          parent_region_id?: string | null
        }
        Update: {
          code?: string
          country_code?: string
          created_at?: string
          id?: string
          name?: string
          parent_region_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "regions_parent_region_id_fkey"
            columns: ["parent_region_id"]
            isOneToOne: false
            referencedRelation: "regions"
            referencedColumns: ["id"]
          },
        ]
      }
      satellite_imagery: {
        Row: {
          captured_at: string | null
          cloud_cover_pct: number | null
          created_at: string | null
          farm_id: string
          id: string
          image_captured_at: string | null
          image_url: string | null
          ndvi_value: number | null
          source: string | null
        }
        Insert: {
          captured_at?: string | null
          cloud_cover_pct?: number | null
          created_at?: string | null
          farm_id: string
          id?: string
          image_captured_at?: string | null
          image_url?: string | null
          ndvi_value?: number | null
          source?: string | null
        }
        Update: {
          captured_at?: string | null
          cloud_cover_pct?: number | null
          created_at?: string | null
          farm_id?: string
          id?: string
          image_captured_at?: string | null
          image_url?: string | null
          ndvi_value?: number | null
          source?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "satellite_imagery_farm_id_fkey"
            columns: ["farm_id"]
            isOneToOne: false
            referencedRelation: "farms"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "satellite_imagery_farm_id_fkey"
            columns: ["farm_id"]
            isOneToOne: false
            referencedRelation: "soil_health_cards"
            referencedColumns: ["farm_id"]
          },
        ]
      }
      scheme_enrollments: {
        Row: {
          created_at: string
          enrolled_at: string
          farmer_user_id: string
          field_id: string | null
          id: string
          metadata: Json
          scheme_id: string
          status: Database["public"]["Enums"]["enrollment_status"]
          updated_at: string
          withdrawn_at: string | null
        }
        Insert: {
          created_at?: string
          enrolled_at?: string
          farmer_user_id: string
          field_id?: string | null
          id?: string
          metadata?: Json
          scheme_id: string
          status?: Database["public"]["Enums"]["enrollment_status"]
          updated_at?: string
          withdrawn_at?: string | null
        }
        Update: {
          created_at?: string
          enrolled_at?: string
          farmer_user_id?: string
          field_id?: string | null
          id?: string
          metadata?: Json
          scheme_id?: string
          status?: Database["public"]["Enums"]["enrollment_status"]
          updated_at?: string
          withdrawn_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "scheme_enrollments_field_id_fkey"
            columns: ["field_id"]
            isOneToOne: false
            referencedRelation: "fields"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "scheme_enrollments_scheme_id_fkey"
            columns: ["scheme_id"]
            isOneToOne: false
            referencedRelation: "schemes"
            referencedColumns: ["id"]
          },
        ]
      }
      scheme_invitations: {
        Row: {
          accepted_at: string | null
          accepted_by_user_id: string | null
          created_at: string
          email: string | null
          expires_at: string
          farmer_name: string | null
          id: string
          invited_by: string | null
          metadata: Json
          phone_number: string | null
          scheme_id: string
          status: Database["public"]["Enums"]["invitation_status"]
          token: string
        }
        Insert: {
          accepted_at?: string | null
          accepted_by_user_id?: string | null
          created_at?: string
          email?: string | null
          expires_at?: string
          farmer_name?: string | null
          id?: string
          invited_by?: string | null
          metadata?: Json
          phone_number?: string | null
          scheme_id: string
          status?: Database["public"]["Enums"]["invitation_status"]
          token?: string
        }
        Update: {
          accepted_at?: string | null
          accepted_by_user_id?: string | null
          created_at?: string
          email?: string | null
          expires_at?: string
          farmer_name?: string | null
          id?: string
          invited_by?: string | null
          metadata?: Json
          phone_number?: string | null
          scheme_id?: string
          status?: Database["public"]["Enums"]["invitation_status"]
          token?: string
        }
        Relationships: [
          {
            foreignKeyName: "scheme_invitations_scheme_id_fkey"
            columns: ["scheme_id"]
            isOneToOne: false
            referencedRelation: "schemes"
            referencedColumns: ["id"]
          },
        ]
      }
      scheme_reports: {
        Row: {
          content: Json
          created_at: string
          csv_url: string | null
          generated_at: string
          generated_by: string | null
          id: string
          pdf_url: string | null
          period_end: string | null
          period_start: string | null
          report_type: Database["public"]["Enums"]["scheme_report_type"]
          scheme_id: string
          title: string
        }
        Insert: {
          content?: Json
          created_at?: string
          csv_url?: string | null
          generated_at?: string
          generated_by?: string | null
          id?: string
          pdf_url?: string | null
          period_end?: string | null
          period_start?: string | null
          report_type?: Database["public"]["Enums"]["scheme_report_type"]
          scheme_id: string
          title: string
        }
        Update: {
          content?: Json
          created_at?: string
          csv_url?: string | null
          generated_at?: string
          generated_by?: string | null
          id?: string
          pdf_url?: string | null
          period_end?: string | null
          period_start?: string | null
          report_type?: Database["public"]["Enums"]["scheme_report_type"]
          scheme_id?: string
          title?: string
        }
        Relationships: [
          {
            foreignKeyName: "scheme_reports_scheme_id_fkey"
            columns: ["scheme_id"]
            isOneToOne: false
            referencedRelation: "schemes"
            referencedColumns: ["id"]
          },
        ]
      }
      schemes: {
        Row: {
          commodity_id: string | null
          created_at: string
          created_by: string | null
          description: string | null
          end_date: string | null
          id: string
          metadata: Json
          name: string
          organization_id: string
          region_id: string | null
          season: string
          start_date: string | null
          status: Database["public"]["Enums"]["scheme_status"]
          target_farmer_count: number | null
          updated_at: string
        }
        Insert: {
          commodity_id?: string | null
          created_at?: string
          created_by?: string | null
          description?: string | null
          end_date?: string | null
          id?: string
          metadata?: Json
          name: string
          organization_id: string
          region_id?: string | null
          season: string
          start_date?: string | null
          status?: Database["public"]["Enums"]["scheme_status"]
          target_farmer_count?: number | null
          updated_at?: string
        }
        Update: {
          commodity_id?: string | null
          created_at?: string
          created_by?: string | null
          description?: string | null
          end_date?: string | null
          id?: string
          metadata?: Json
          name?: string
          organization_id?: string
          region_id?: string | null
          season?: string
          start_date?: string | null
          status?: Database["public"]["Enums"]["scheme_status"]
          target_farmer_count?: number | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "schemes_commodity_id_fkey"
            columns: ["commodity_id"]
            isOneToOne: false
            referencedRelation: "commodities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "schemes_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "schemes_region_id_fkey"
            columns: ["region_id"]
            isOneToOne: false
            referencedRelation: "regions"
            referencedColumns: ["id"]
          },
        ]
      }
      service_components: {
        Row: {
          check_url: string | null
          created_at: string
          description: string | null
          display_order: number
          id: string
          is_public: boolean
          latency_critical_ms: number
          latency_warning_ms: number
          name: string
          slug: string
          updated_at: string
        }
        Insert: {
          check_url?: string | null
          created_at?: string
          description?: string | null
          display_order?: number
          id?: string
          is_public?: boolean
          latency_critical_ms?: number
          latency_warning_ms?: number
          name: string
          slug: string
          updated_at?: string
        }
        Update: {
          check_url?: string | null
          created_at?: string
          description?: string | null
          display_order?: number
          id?: string
          is_public?: boolean
          latency_critical_ms?: number
          latency_warning_ms?: number
          name?: string
          slug?: string
          updated_at?: string
        }
        Relationships: []
      }
      service_health_checks: {
        Row: {
          checked_at: string
          component_id: string
          error_message: string | null
          id: string
          latency_ms: number | null
          status: string
        }
        Insert: {
          checked_at?: string
          component_id: string
          error_message?: string | null
          id?: string
          latency_ms?: number | null
          status: string
        }
        Update: {
          checked_at?: string
          component_id?: string
          error_message?: string | null
          id?: string
          latency_ms?: number | null
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "service_health_checks_component_id_fkey"
            columns: ["component_id"]
            isOneToOne: false
            referencedRelation: "service_components"
            referencedColumns: ["id"]
          },
        ]
      }
      soil_baseline: {
        Row: {
          bulk_density_kg_per_m3: number | null
          cec_cmol_per_kg: number | null
          clay_pct: number | null
          farm_id: string
          fetched_at: string
          id: string
          nitrogen_g_per_kg: number | null
          organic_carbon_g_per_kg: number | null
          ph: number | null
          raw_response: Json | null
          sand_pct: number | null
          silt_pct: number | null
          source: string
        }
        Insert: {
          bulk_density_kg_per_m3?: number | null
          cec_cmol_per_kg?: number | null
          clay_pct?: number | null
          farm_id: string
          fetched_at?: string
          id?: string
          nitrogen_g_per_kg?: number | null
          organic_carbon_g_per_kg?: number | null
          ph?: number | null
          raw_response?: Json | null
          sand_pct?: number | null
          silt_pct?: number | null
          source?: string
        }
        Update: {
          bulk_density_kg_per_m3?: number | null
          cec_cmol_per_kg?: number | null
          clay_pct?: number | null
          farm_id?: string
          fetched_at?: string
          id?: string
          nitrogen_g_per_kg?: number | null
          organic_carbon_g_per_kg?: number | null
          ph?: number | null
          raw_response?: Json | null
          sand_pct?: number | null
          silt_pct?: number | null
          source?: string
        }
        Relationships: []
      }
      soil_self_assessments: {
        Row: {
          assessed_at: string
          assessed_by: string | null
          created_at: string
          drainage_class: string | null
          erosion_observed: string | null
          farm_id: string
          field_name: string | null
          id: string
          last_compost_application_date: string | null
          last_manure_application_date: string | null
          notes: string | null
          residue_management: string | null
          slope_class: string | null
          soil_colour: string | null
          texture_by_feel: string | null
        }
        Insert: {
          assessed_at?: string
          assessed_by?: string | null
          created_at?: string
          drainage_class?: string | null
          erosion_observed?: string | null
          farm_id: string
          field_name?: string | null
          id?: string
          last_compost_application_date?: string | null
          last_manure_application_date?: string | null
          notes?: string | null
          residue_management?: string | null
          slope_class?: string | null
          soil_colour?: string | null
          texture_by_feel?: string | null
        }
        Update: {
          assessed_at?: string
          assessed_by?: string | null
          created_at?: string
          drainage_class?: string | null
          erosion_observed?: string | null
          farm_id?: string
          field_name?: string | null
          id?: string
          last_compost_application_date?: string | null
          last_manure_application_date?: string | null
          notes?: string | null
          residue_management?: string | null
          slope_class?: string | null
          soil_colour?: string | null
          texture_by_feel?: string | null
        }
        Relationships: []
      }
      soil_tests: {
        Row: {
          biological_activity_score: number | null
          boron: number | null
          bulk_density: number | null
          cec: number | null
          clay_pct: number | null
          confidence_level: Database["public"]["Enums"]["soil_confidence_level"]
          created_at: string | null
          drainage_class: string | null
          ec: number | null
          erosion_risk: string | null
          farm_id: string | null
          field_name: string | null
          file_url: string | null
          id: string
          location: string | null
          nitrogen: number | null
          organic_carbon: number | null
          organic_matter: number | null
          parent_material: string | null
          ph_level: number | null
          phosphorus: number | null
          potassium: number | null
          recommendations: string | null
          sand_pct: number | null
          silt_pct: number | null
          slope_pct: number | null
          source: Database["public"]["Enums"]["soil_data_source"]
          sulphur: number | null
          test_date: string | null
          user_id: string
          zinc: number | null
        }
        Insert: {
          biological_activity_score?: number | null
          boron?: number | null
          bulk_density?: number | null
          cec?: number | null
          clay_pct?: number | null
          confidence_level?: Database["public"]["Enums"]["soil_confidence_level"]
          created_at?: string | null
          drainage_class?: string | null
          ec?: number | null
          erosion_risk?: string | null
          farm_id?: string | null
          field_name?: string | null
          file_url?: string | null
          id?: string
          location?: string | null
          nitrogen?: number | null
          organic_carbon?: number | null
          organic_matter?: number | null
          parent_material?: string | null
          ph_level?: number | null
          phosphorus?: number | null
          potassium?: number | null
          recommendations?: string | null
          sand_pct?: number | null
          silt_pct?: number | null
          slope_pct?: number | null
          source?: Database["public"]["Enums"]["soil_data_source"]
          sulphur?: number | null
          test_date?: string | null
          user_id: string
          zinc?: number | null
        }
        Update: {
          biological_activity_score?: number | null
          boron?: number | null
          bulk_density?: number | null
          cec?: number | null
          clay_pct?: number | null
          confidence_level?: Database["public"]["Enums"]["soil_confidence_level"]
          created_at?: string | null
          drainage_class?: string | null
          ec?: number | null
          erosion_risk?: string | null
          farm_id?: string | null
          field_name?: string | null
          file_url?: string | null
          id?: string
          location?: string | null
          nitrogen?: number | null
          organic_carbon?: number | null
          organic_matter?: number | null
          parent_material?: string | null
          ph_level?: number | null
          phosphorus?: number | null
          potassium?: number | null
          recommendations?: string | null
          sand_pct?: number | null
          silt_pct?: number | null
          slope_pct?: number | null
          source?: Database["public"]["Enums"]["soil_data_source"]
          sulphur?: number | null
          test_date?: string | null
          user_id?: string
          zinc?: number | null
        }
        Relationships: []
      }
      spatial_ref_sys: {
        Row: {
          auth_name: string | null
          auth_srid: number | null
          proj4text: string | null
          srid: number
          srtext: string | null
        }
        Insert: {
          auth_name?: string | null
          auth_srid?: number | null
          proj4text?: string | null
          srid: number
          srtext?: string | null
        }
        Update: {
          auth_name?: string | null
          auth_srid?: number | null
          proj4text?: string | null
          srid?: number
          srtext?: string | null
        }
        Relationships: []
      }
      usage_events: {
        Row: {
          created_at: string
          event_name: string
          id: string
          page_route: string | null
          properties: Json
          user_id: string | null
        }
        Insert: {
          created_at?: string
          event_name: string
          id?: string
          page_route?: string | null
          properties?: Json
          user_id?: string | null
        }
        Update: {
          created_at?: string
          event_name?: string
          id?: string
          page_route?: string | null
          properties?: Json
          user_id?: string | null
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          created_by: string | null
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      weather_alerts: {
        Row: {
          alert_type: string
          created_at: string | null
          expires_at: string | null
          farm_id: string | null
          id: string
          is_active: boolean | null
          message: string
          metadata: Json | null
          severity: string
        }
        Insert: {
          alert_type: string
          created_at?: string | null
          expires_at?: string | null
          farm_id?: string | null
          id?: string
          is_active?: boolean | null
          message: string
          metadata?: Json | null
          severity?: string
        }
        Update: {
          alert_type?: string
          created_at?: string | null
          expires_at?: string | null
          farm_id?: string | null
          id?: string
          is_active?: boolean | null
          message?: string
          metadata?: Json | null
          severity?: string
        }
        Relationships: [
          {
            foreignKeyName: "weather_alerts_farm_id_fkey"
            columns: ["farm_id"]
            isOneToOne: false
            referencedRelation: "farms"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "weather_alerts_farm_id_fkey"
            columns: ["farm_id"]
            isOneToOne: false
            referencedRelation: "soil_health_cards"
            referencedColumns: ["farm_id"]
          },
        ]
      }
      weather_cache: {
        Row: {
          cached_at: string | null
          condition: string | null
          expires_at: string | null
          forecast_data: Json | null
          humidity: number | null
          id: string
          latitude: number | null
          longitude: number | null
          rainfall: number | null
          region: string
          soil_moisture_0_1cm: number | null
          soil_moisture_1_3cm: number | null
          soil_temperature_0cm: number | null
          soil_temperature_18cm: number | null
          soil_temperature_6cm: number | null
          temperature: number | null
          wind_speed: number | null
        }
        Insert: {
          cached_at?: string | null
          condition?: string | null
          expires_at?: string | null
          forecast_data?: Json | null
          humidity?: number | null
          id?: string
          latitude?: number | null
          longitude?: number | null
          rainfall?: number | null
          region: string
          soil_moisture_0_1cm?: number | null
          soil_moisture_1_3cm?: number | null
          soil_temperature_0cm?: number | null
          soil_temperature_18cm?: number | null
          soil_temperature_6cm?: number | null
          temperature?: number | null
          wind_speed?: number | null
        }
        Update: {
          cached_at?: string | null
          condition?: string | null
          expires_at?: string | null
          forecast_data?: Json | null
          humidity?: number | null
          id?: string
          latitude?: number | null
          longitude?: number | null
          rainfall?: number | null
          region?: string
          soil_moisture_0_1cm?: number | null
          soil_moisture_1_3cm?: number | null
          soil_temperature_0cm?: number | null
          soil_temperature_18cm?: number | null
          soil_temperature_6cm?: number | null
          temperature?: number | null
          wind_speed?: number | null
        }
        Relationships: []
      }
      whatsapp_sessions: {
        Row: {
          created_at: string | null
          id: string
          language: string | null
          last_message_context: Json | null
          onboarding_step: string | null
          phone_number: string
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          language?: string | null
          last_message_context?: Json | null
          onboarding_step?: string | null
          phone_number: string
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          created_at?: string | null
          id?: string
          language?: string | null
          last_message_context?: Json | null
          onboarding_step?: string | null
          phone_number?: string
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
    }
    Views: {
      geography_columns: {
        Row: {
          coord_dimension: number | null
          f_geography_column: unknown
          f_table_catalog: unknown
          f_table_name: unknown
          f_table_schema: unknown
          srid: number | null
          type: string | null
        }
        Relationships: []
      }
      geometry_columns: {
        Row: {
          coord_dimension: number | null
          f_geometry_column: unknown
          f_table_catalog: string | null
          f_table_name: unknown
          f_table_schema: unknown
          srid: number | null
          type: string | null
        }
        Insert: {
          coord_dimension?: number | null
          f_geometry_column?: unknown
          f_table_catalog?: string | null
          f_table_name?: unknown
          f_table_schema?: unknown
          srid?: number | null
          type?: string | null
        }
        Update: {
          coord_dimension?: number | null
          f_geometry_column?: unknown
          f_table_catalog?: string | null
          f_table_name?: unknown
          f_table_schema?: unknown
          srid?: number | null
          type?: string | null
        }
        Relationships: []
      }
      logistics_providers_public: {
        Row: {
          created_at: string | null
          id: string | null
          is_active: boolean | null
          name: string | null
          region: string | null
        }
        Insert: {
          created_at?: string | null
          id?: string | null
          is_active?: boolean | null
          name?: string | null
          region?: string | null
        }
        Update: {
          created_at?: string | null
          id?: string | null
          is_active?: boolean | null
          name?: string | null
          region?: string | null
        }
        Relationships: []
      }
      soil_health_cards: {
        Row: {
          agroecological_zone_id: string | null
          baseline: Json | null
          farm_id: string | null
          farm_name: string | null
          health_grade: string | null
          latest_lab: Json | null
          latest_self_assessment: Json | null
          region_code: string | null
          region_name: string | null
          soil_confidence:
            | Database["public"]["Enums"]["soil_confidence_level"]
            | null
          user_id: string | null
        }
        Relationships: [
          {
            foreignKeyName: "farms_agroecological_zone_id_fkey"
            columns: ["agroecological_zone_id"]
            isOneToOne: false
            referencedRelation: "agroecological_zones"
            referencedColumns: ["id"]
          },
        ]
      }
      v_national_ndvi_daily: {
        Row: {
          avg_ndvi: number | null
          day: string | null
          region_code: string | null
          region_name: string | null
          sample_count: number | null
        }
        Relationships: []
      }
    }
    Functions: {
      _postgis_deprecate: {
        Args: { newname: string; oldname: string; version: string }
        Returns: undefined
      }
      _postgis_index_extent: {
        Args: { col: string; tbl: unknown }
        Returns: unknown
      }
      _postgis_pgsql_version: { Args: never; Returns: string }
      _postgis_scripts_pgsql_version: { Args: never; Returns: string }
      _postgis_selectivity: {
        Args: { att_name: string; geom: unknown; mode?: string; tbl: unknown }
        Returns: number
      }
      _postgis_stats: {
        Args: { ""?: string; att_name: string; tbl: unknown }
        Returns: string
      }
      _st_3dintersects: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: boolean
      }
      _st_contains: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: boolean
      }
      _st_containsproperly: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: boolean
      }
      _st_coveredby:
        | { Args: { geog1: unknown; geog2: unknown }; Returns: boolean }
        | { Args: { geom1: unknown; geom2: unknown }; Returns: boolean }
      _st_covers:
        | { Args: { geog1: unknown; geog2: unknown }; Returns: boolean }
        | { Args: { geom1: unknown; geom2: unknown }; Returns: boolean }
      _st_crosses: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: boolean
      }
      _st_dwithin: {
        Args: {
          geog1: unknown
          geog2: unknown
          tolerance: number
          use_spheroid?: boolean
        }
        Returns: boolean
      }
      _st_equals: { Args: { geom1: unknown; geom2: unknown }; Returns: boolean }
      _st_intersects: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: boolean
      }
      _st_linecrossingdirection: {
        Args: { line1: unknown; line2: unknown }
        Returns: number
      }
      _st_longestline: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: unknown
      }
      _st_maxdistance: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: number
      }
      _st_orderingequals: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: boolean
      }
      _st_overlaps: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: boolean
      }
      _st_sortablehash: { Args: { geom: unknown }; Returns: number }
      _st_touches: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: boolean
      }
      _st_voronoi: {
        Args: {
          clip?: unknown
          g1: unknown
          return_polygons?: boolean
          tolerance?: number
        }
        Returns: unknown
      }
      _st_within: { Args: { geom1: unknown; geom2: unknown }; Returns: boolean }
      addauth: { Args: { "": string }; Returns: boolean }
      addgeometrycolumn:
        | {
            Args: {
              catalog_name: string
              column_name: string
              new_dim: number
              new_srid_in: number
              new_type: string
              schema_name: string
              table_name: string
              use_typmod?: boolean
            }
            Returns: string
          }
        | {
            Args: {
              column_name: string
              new_dim: number
              new_srid: number
              new_type: string
              schema_name: string
              table_name: string
              use_typmod?: boolean
            }
            Returns: string
          }
        | {
            Args: {
              column_name: string
              new_dim: number
              new_srid: number
              new_type: string
              table_name: string
              use_typmod?: boolean
            }
            Returns: string
          }
      can_manage_scheme: {
        Args: { _scheme_id: string; _user_id: string }
        Returns: boolean
      }
      disablelongtransactions: { Args: never; Returns: string }
      dropgeometrycolumn:
        | {
            Args: {
              catalog_name: string
              column_name: string
              schema_name: string
              table_name: string
            }
            Returns: string
          }
        | {
            Args: {
              column_name: string
              schema_name: string
              table_name: string
            }
            Returns: string
          }
        | { Args: { column_name: string; table_name: string }; Returns: string }
      dropgeometrytable:
        | {
            Args: {
              catalog_name: string
              schema_name: string
              table_name: string
            }
            Returns: string
          }
        | { Args: { schema_name: string; table_name: string }; Returns: string }
        | { Args: { table_name: string }; Returns: string }
      enablelongtransactions: { Args: never; Returns: string }
      equals: { Args: { geom1: unknown; geom2: unknown }; Returns: boolean }
      geometry: { Args: { "": string }; Returns: unknown }
      geometry_above: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: boolean
      }
      geometry_below: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: boolean
      }
      geometry_cmp: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: number
      }
      geometry_contained_3d: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: boolean
      }
      geometry_contains: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: boolean
      }
      geometry_contains_3d: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: boolean
      }
      geometry_distance_box: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: number
      }
      geometry_distance_centroid: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: number
      }
      geometry_eq: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: boolean
      }
      geometry_ge: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: boolean
      }
      geometry_gt: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: boolean
      }
      geometry_le: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: boolean
      }
      geometry_left: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: boolean
      }
      geometry_lt: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: boolean
      }
      geometry_overabove: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: boolean
      }
      geometry_overbelow: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: boolean
      }
      geometry_overlaps: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: boolean
      }
      geometry_overlaps_3d: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: boolean
      }
      geometry_overleft: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: boolean
      }
      geometry_overright: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: boolean
      }
      geometry_right: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: boolean
      }
      geometry_same: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: boolean
      }
      geometry_same_3d: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: boolean
      }
      geometry_within: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: boolean
      }
      geomfromewkt: { Args: { "": string }; Returns: unknown }
      get_farm_boundary_geojson: { Args: { _farm_id: string }; Returns: Json }
      get_farm_mechanization_score: {
        Args: { _farm_id: string }
        Returns: Json
      }
      get_latest_farm_ndvi: {
        Args: never
        Returns: {
          captured_at: string
          farm_id: string
          farm_name: string
          latitude: number
          longitude: number
          ndvi_value: number
          region_code: string
          region_name: string
        }[]
      }
      get_zones_geojson: { Args: never; Returns: Json }
      gettransactionid: { Args: never; Returns: unknown }
      has_org_role: {
        Args: {
          _org_id: string
          _roles: Database["public"]["Enums"]["org_role"][]
          _user_id: string
        }
        Returns: boolean
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      infer_default_horsepower: {
        Args: {
          _category: Database["public"]["Enums"]["equipment_category"]
          _power: Database["public"]["Enums"]["power_source"]
        }
        Returns: number
      }
      is_admin:
        | { Args: never; Returns: boolean }
        | { Args: { _user_id: string }; Returns: boolean }
      is_logistics_or_admin:
        | { Args: never; Returns: boolean }
        | { Args: { _user_id: string }; Returns: boolean }
      is_org_member: {
        Args: { _org_id: string; _user_id: string }
        Returns: boolean
      }
      longtransactionsenabled: { Args: never; Returns: boolean }
      match_kb_chunks: {
        Args: {
          filter_crop?: string
          filter_language?: string
          filter_region?: string
          match_count?: number
          min_similarity?: number
          query_embedding: string
        }
        Returns: {
          chunk_id: string
          content: string
          crop: string
          document_id: string
          language: string
          metadata: Json
          region: string
          similarity: number
          source: string
          title: string
        }[]
      }
      org_field_visible: {
        Args: { _field_id: string; _user_id: string }
        Returns: boolean
      }
      populate_geometry_columns:
        | { Args: { tbl_oid: unknown; use_typmod?: boolean }; Returns: number }
        | { Args: { use_typmod?: boolean }; Returns: string }
      postgis_constraint_dims: {
        Args: { geomcolumn: string; geomschema: string; geomtable: string }
        Returns: number
      }
      postgis_constraint_srid: {
        Args: { geomcolumn: string; geomschema: string; geomtable: string }
        Returns: number
      }
      postgis_constraint_type: {
        Args: { geomcolumn: string; geomschema: string; geomtable: string }
        Returns: string
      }
      postgis_extensions_upgrade: { Args: never; Returns: string }
      postgis_full_version: { Args: never; Returns: string }
      postgis_geos_version: { Args: never; Returns: string }
      postgis_lib_build_date: { Args: never; Returns: string }
      postgis_lib_revision: { Args: never; Returns: string }
      postgis_lib_version: { Args: never; Returns: string }
      postgis_libjson_version: { Args: never; Returns: string }
      postgis_liblwgeom_version: { Args: never; Returns: string }
      postgis_libprotobuf_version: { Args: never; Returns: string }
      postgis_libxml_version: { Args: never; Returns: string }
      postgis_proj_version: { Args: never; Returns: string }
      postgis_scripts_build_date: { Args: never; Returns: string }
      postgis_scripts_installed: { Args: never; Returns: string }
      postgis_scripts_released: { Args: never; Returns: string }
      postgis_svn_version: { Args: never; Returns: string }
      postgis_type_name: {
        Args: {
          coord_dimension: number
          geomname: string
          use_new_name?: boolean
        }
        Returns: string
      }
      postgis_version: { Args: never; Returns: string }
      postgis_wagyu_version: { Args: never; Returns: string }
      recent_ndvi_anomaly_exists: {
        Args: { _cooldown_days?: number; _farm_id: string }
        Returns: boolean
      }
      st_3dclosestpoint: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: unknown
      }
      st_3ddistance: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: number
      }
      st_3dintersects: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: boolean
      }
      st_3dlongestline: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: unknown
      }
      st_3dmakebox: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: unknown
      }
      st_3dmaxdistance: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: number
      }
      st_3dshortestline: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: unknown
      }
      st_addpoint: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: unknown
      }
      st_angle:
        | { Args: { line1: unknown; line2: unknown }; Returns: number }
        | {
            Args: { pt1: unknown; pt2: unknown; pt3: unknown; pt4?: unknown }
            Returns: number
          }
      st_area:
        | { Args: { geog: unknown; use_spheroid?: boolean }; Returns: number }
        | { Args: { "": string }; Returns: number }
      st_asencodedpolyline: {
        Args: { geom: unknown; nprecision?: number }
        Returns: string
      }
      st_asewkt: { Args: { "": string }; Returns: string }
      st_asgeojson:
        | {
            Args: { geog: unknown; maxdecimaldigits?: number; options?: number }
            Returns: string
          }
        | {
            Args: { geom: unknown; maxdecimaldigits?: number; options?: number }
            Returns: string
          }
        | {
            Args: {
              geom_column?: string
              maxdecimaldigits?: number
              pretty_bool?: boolean
              r: Record<string, unknown>
            }
            Returns: string
          }
        | { Args: { "": string }; Returns: string }
      st_asgml:
        | {
            Args: {
              geog: unknown
              id?: string
              maxdecimaldigits?: number
              nprefix?: string
              options?: number
            }
            Returns: string
          }
        | {
            Args: { geom: unknown; maxdecimaldigits?: number; options?: number }
            Returns: string
          }
        | { Args: { "": string }; Returns: string }
        | {
            Args: {
              geog: unknown
              id?: string
              maxdecimaldigits?: number
              nprefix?: string
              options?: number
              version: number
            }
            Returns: string
          }
        | {
            Args: {
              geom: unknown
              id?: string
              maxdecimaldigits?: number
              nprefix?: string
              options?: number
              version: number
            }
            Returns: string
          }
      st_askml:
        | {
            Args: { geog: unknown; maxdecimaldigits?: number; nprefix?: string }
            Returns: string
          }
        | {
            Args: { geom: unknown; maxdecimaldigits?: number; nprefix?: string }
            Returns: string
          }
        | { Args: { "": string }; Returns: string }
      st_aslatlontext: {
        Args: { geom: unknown; tmpl?: string }
        Returns: string
      }
      st_asmarc21: { Args: { format?: string; geom: unknown }; Returns: string }
      st_asmvtgeom: {
        Args: {
          bounds: unknown
          buffer?: number
          clip_geom?: boolean
          extent?: number
          geom: unknown
        }
        Returns: unknown
      }
      st_assvg:
        | {
            Args: { geog: unknown; maxdecimaldigits?: number; rel?: number }
            Returns: string
          }
        | {
            Args: { geom: unknown; maxdecimaldigits?: number; rel?: number }
            Returns: string
          }
        | { Args: { "": string }; Returns: string }
      st_astext: { Args: { "": string }; Returns: string }
      st_astwkb:
        | {
            Args: {
              geom: unknown
              prec?: number
              prec_m?: number
              prec_z?: number
              with_boxes?: boolean
              with_sizes?: boolean
            }
            Returns: string
          }
        | {
            Args: {
              geom: unknown[]
              ids: number[]
              prec?: number
              prec_m?: number
              prec_z?: number
              with_boxes?: boolean
              with_sizes?: boolean
            }
            Returns: string
          }
      st_asx3d: {
        Args: { geom: unknown; maxdecimaldigits?: number; options?: number }
        Returns: string
      }
      st_azimuth:
        | { Args: { geog1: unknown; geog2: unknown }; Returns: number }
        | { Args: { geom1: unknown; geom2: unknown }; Returns: number }
      st_boundingdiagonal: {
        Args: { fits?: boolean; geom: unknown }
        Returns: unknown
      }
      st_buffer:
        | {
            Args: { geom: unknown; options?: string; radius: number }
            Returns: unknown
          }
        | {
            Args: { geom: unknown; quadsegs: number; radius: number }
            Returns: unknown
          }
      st_centroid: { Args: { "": string }; Returns: unknown }
      st_clipbybox2d: {
        Args: { box: unknown; geom: unknown }
        Returns: unknown
      }
      st_closestpoint: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: unknown
      }
      st_collect: { Args: { geom1: unknown; geom2: unknown }; Returns: unknown }
      st_concavehull: {
        Args: {
          param_allow_holes?: boolean
          param_geom: unknown
          param_pctconvex: number
        }
        Returns: unknown
      }
      st_contains: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: boolean
      }
      st_containsproperly: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: boolean
      }
      st_coorddim: { Args: { geometry: unknown }; Returns: number }
      st_coveredby:
        | { Args: { geog1: unknown; geog2: unknown }; Returns: boolean }
        | { Args: { geom1: unknown; geom2: unknown }; Returns: boolean }
      st_covers:
        | { Args: { geog1: unknown; geog2: unknown }; Returns: boolean }
        | { Args: { geom1: unknown; geom2: unknown }; Returns: boolean }
      st_crosses: { Args: { geom1: unknown; geom2: unknown }; Returns: boolean }
      st_curvetoline: {
        Args: { flags?: number; geom: unknown; tol?: number; toltype?: number }
        Returns: unknown
      }
      st_delaunaytriangles: {
        Args: { flags?: number; g1: unknown; tolerance?: number }
        Returns: unknown
      }
      st_difference: {
        Args: { geom1: unknown; geom2: unknown; gridsize?: number }
        Returns: unknown
      }
      st_disjoint: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: boolean
      }
      st_distance:
        | {
            Args: { geog1: unknown; geog2: unknown; use_spheroid?: boolean }
            Returns: number
          }
        | { Args: { geom1: unknown; geom2: unknown }; Returns: number }
      st_distancesphere:
        | { Args: { geom1: unknown; geom2: unknown }; Returns: number }
        | {
            Args: { geom1: unknown; geom2: unknown; radius: number }
            Returns: number
          }
      st_distancespheroid: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: number
      }
      st_dwithin: {
        Args: {
          geog1: unknown
          geog2: unknown
          tolerance: number
          use_spheroid?: boolean
        }
        Returns: boolean
      }
      st_equals: { Args: { geom1: unknown; geom2: unknown }; Returns: boolean }
      st_expand:
        | { Args: { box: unknown; dx: number; dy: number }; Returns: unknown }
        | {
            Args: { box: unknown; dx: number; dy: number; dz?: number }
            Returns: unknown
          }
        | {
            Args: {
              dm?: number
              dx: number
              dy: number
              dz?: number
              geom: unknown
            }
            Returns: unknown
          }
      st_force3d: { Args: { geom: unknown; zvalue?: number }; Returns: unknown }
      st_force3dm: {
        Args: { geom: unknown; mvalue?: number }
        Returns: unknown
      }
      st_force3dz: {
        Args: { geom: unknown; zvalue?: number }
        Returns: unknown
      }
      st_force4d: {
        Args: { geom: unknown; mvalue?: number; zvalue?: number }
        Returns: unknown
      }
      st_generatepoints:
        | { Args: { area: unknown; npoints: number }; Returns: unknown }
        | {
            Args: { area: unknown; npoints: number; seed: number }
            Returns: unknown
          }
      st_geogfromtext: { Args: { "": string }; Returns: unknown }
      st_geographyfromtext: { Args: { "": string }; Returns: unknown }
      st_geohash:
        | { Args: { geog: unknown; maxchars?: number }; Returns: string }
        | { Args: { geom: unknown; maxchars?: number }; Returns: string }
      st_geomcollfromtext: { Args: { "": string }; Returns: unknown }
      st_geometricmedian: {
        Args: {
          fail_if_not_converged?: boolean
          g: unknown
          max_iter?: number
          tolerance?: number
        }
        Returns: unknown
      }
      st_geometryfromtext: { Args: { "": string }; Returns: unknown }
      st_geomfromewkt: { Args: { "": string }; Returns: unknown }
      st_geomfromgeojson:
        | { Args: { "": Json }; Returns: unknown }
        | { Args: { "": Json }; Returns: unknown }
        | { Args: { "": string }; Returns: unknown }
      st_geomfromgml: { Args: { "": string }; Returns: unknown }
      st_geomfromkml: { Args: { "": string }; Returns: unknown }
      st_geomfrommarc21: { Args: { marc21xml: string }; Returns: unknown }
      st_geomfromtext: { Args: { "": string }; Returns: unknown }
      st_gmltosql: { Args: { "": string }; Returns: unknown }
      st_hasarc: { Args: { geometry: unknown }; Returns: boolean }
      st_hausdorffdistance: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: number
      }
      st_hexagon: {
        Args: { cell_i: number; cell_j: number; origin?: unknown; size: number }
        Returns: unknown
      }
      st_hexagongrid: {
        Args: { bounds: unknown; size: number }
        Returns: Record<string, unknown>[]
      }
      st_interpolatepoint: {
        Args: { line: unknown; point: unknown }
        Returns: number
      }
      st_intersection: {
        Args: { geom1: unknown; geom2: unknown; gridsize?: number }
        Returns: unknown
      }
      st_intersects:
        | { Args: { geog1: unknown; geog2: unknown }; Returns: boolean }
        | { Args: { geom1: unknown; geom2: unknown }; Returns: boolean }
      st_isvaliddetail: {
        Args: { flags?: number; geom: unknown }
        Returns: Database["public"]["CompositeTypes"]["valid_detail"]
        SetofOptions: {
          from: "*"
          to: "valid_detail"
          isOneToOne: true
          isSetofReturn: false
        }
      }
      st_length:
        | { Args: { geog: unknown; use_spheroid?: boolean }; Returns: number }
        | { Args: { "": string }; Returns: number }
      st_letters: { Args: { font?: Json; letters: string }; Returns: unknown }
      st_linecrossingdirection: {
        Args: { line1: unknown; line2: unknown }
        Returns: number
      }
      st_linefromencodedpolyline: {
        Args: { nprecision?: number; txtin: string }
        Returns: unknown
      }
      st_linefromtext: { Args: { "": string }; Returns: unknown }
      st_linelocatepoint: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: number
      }
      st_linetocurve: { Args: { geometry: unknown }; Returns: unknown }
      st_locatealong: {
        Args: { geometry: unknown; leftrightoffset?: number; measure: number }
        Returns: unknown
      }
      st_locatebetween: {
        Args: {
          frommeasure: number
          geometry: unknown
          leftrightoffset?: number
          tomeasure: number
        }
        Returns: unknown
      }
      st_locatebetweenelevations: {
        Args: { fromelevation: number; geometry: unknown; toelevation: number }
        Returns: unknown
      }
      st_longestline: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: unknown
      }
      st_makebox2d: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: unknown
      }
      st_makeline: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: unknown
      }
      st_makevalid: {
        Args: { geom: unknown; params: string }
        Returns: unknown
      }
      st_maxdistance: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: number
      }
      st_minimumboundingcircle: {
        Args: { inputgeom: unknown; segs_per_quarter?: number }
        Returns: unknown
      }
      st_mlinefromtext: { Args: { "": string }; Returns: unknown }
      st_mpointfromtext: { Args: { "": string }; Returns: unknown }
      st_mpolyfromtext: { Args: { "": string }; Returns: unknown }
      st_multilinestringfromtext: { Args: { "": string }; Returns: unknown }
      st_multipointfromtext: { Args: { "": string }; Returns: unknown }
      st_multipolygonfromtext: { Args: { "": string }; Returns: unknown }
      st_node: { Args: { g: unknown }; Returns: unknown }
      st_normalize: { Args: { geom: unknown }; Returns: unknown }
      st_offsetcurve: {
        Args: { distance: number; line: unknown; params?: string }
        Returns: unknown
      }
      st_orderingequals: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: boolean
      }
      st_overlaps: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: boolean
      }
      st_perimeter: {
        Args: { geog: unknown; use_spheroid?: boolean }
        Returns: number
      }
      st_pointfromtext: { Args: { "": string }; Returns: unknown }
      st_pointm: {
        Args: {
          mcoordinate: number
          srid?: number
          xcoordinate: number
          ycoordinate: number
        }
        Returns: unknown
      }
      st_pointz: {
        Args: {
          srid?: number
          xcoordinate: number
          ycoordinate: number
          zcoordinate: number
        }
        Returns: unknown
      }
      st_pointzm: {
        Args: {
          mcoordinate: number
          srid?: number
          xcoordinate: number
          ycoordinate: number
          zcoordinate: number
        }
        Returns: unknown
      }
      st_polyfromtext: { Args: { "": string }; Returns: unknown }
      st_polygonfromtext: { Args: { "": string }; Returns: unknown }
      st_project: {
        Args: { azimuth: number; distance: number; geog: unknown }
        Returns: unknown
      }
      st_quantizecoordinates: {
        Args: {
          g: unknown
          prec_m?: number
          prec_x: number
          prec_y?: number
          prec_z?: number
        }
        Returns: unknown
      }
      st_reduceprecision: {
        Args: { geom: unknown; gridsize: number }
        Returns: unknown
      }
      st_relate: { Args: { geom1: unknown; geom2: unknown }; Returns: string }
      st_removerepeatedpoints: {
        Args: { geom: unknown; tolerance?: number }
        Returns: unknown
      }
      st_segmentize: {
        Args: { geog: unknown; max_segment_length: number }
        Returns: unknown
      }
      st_setsrid:
        | { Args: { geog: unknown; srid: number }; Returns: unknown }
        | { Args: { geom: unknown; srid: number }; Returns: unknown }
      st_sharedpaths: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: unknown
      }
      st_shortestline: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: unknown
      }
      st_simplifypolygonhull: {
        Args: { geom: unknown; is_outer?: boolean; vertex_fraction: number }
        Returns: unknown
      }
      st_split: { Args: { geom1: unknown; geom2: unknown }; Returns: unknown }
      st_square: {
        Args: { cell_i: number; cell_j: number; origin?: unknown; size: number }
        Returns: unknown
      }
      st_squaregrid: {
        Args: { bounds: unknown; size: number }
        Returns: Record<string, unknown>[]
      }
      st_srid:
        | { Args: { geog: unknown }; Returns: number }
        | { Args: { geom: unknown }; Returns: number }
      st_subdivide: {
        Args: { geom: unknown; gridsize?: number; maxvertices?: number }
        Returns: unknown[]
      }
      st_swapordinates: {
        Args: { geom: unknown; ords: unknown }
        Returns: unknown
      }
      st_symdifference: {
        Args: { geom1: unknown; geom2: unknown; gridsize?: number }
        Returns: unknown
      }
      st_symmetricdifference: {
        Args: { geom1: unknown; geom2: unknown }
        Returns: unknown
      }
      st_tileenvelope: {
        Args: {
          bounds?: unknown
          margin?: number
          x: number
          y: number
          zoom: number
        }
        Returns: unknown
      }
      st_touches: { Args: { geom1: unknown; geom2: unknown }; Returns: boolean }
      st_transform:
        | {
            Args: { from_proj: string; geom: unknown; to_proj: string }
            Returns: unknown
          }
        | {
            Args: { from_proj: string; geom: unknown; to_srid: number }
            Returns: unknown
          }
        | { Args: { geom: unknown; to_proj: string }; Returns: unknown }
      st_triangulatepolygon: { Args: { g1: unknown }; Returns: unknown }
      st_union:
        | { Args: { geom1: unknown; geom2: unknown }; Returns: unknown }
        | {
            Args: { geom1: unknown; geom2: unknown; gridsize: number }
            Returns: unknown
          }
      st_voronoilines: {
        Args: { extend_to?: unknown; g1: unknown; tolerance?: number }
        Returns: unknown
      }
      st_voronoipolygons: {
        Args: { extend_to?: unknown; g1: unknown; tolerance?: number }
        Returns: unknown
      }
      st_within: { Args: { geom1: unknown; geom2: unknown }; Returns: boolean }
      st_wkbtosql: { Args: { wkb: string }; Returns: unknown }
      st_wkttosql: { Args: { "": string }; Returns: unknown }
      st_wrapx: {
        Args: { geom: unknown; move: number; wrap: number }
        Returns: unknown
      }
      unlockrows: { Args: { "": string }; Returns: number }
      update_farm_boundary: {
        Args: {
          boundary_geojson: string
          farm_id: string
          lat: number
          lng: number
        }
        Returns: undefined
      }
      updategeometrysrid: {
        Args: {
          catalogn_name: string
          column_name: string
          new_srid_in: number
          schema_name: string
          table_name: string
        }
        Returns: string
      }
      user_orgs: {
        Args: { _user_id: string }
        Returns: {
          organization_id: string
          role: Database["public"]["Enums"]["org_role"]
        }[]
      }
      user_role: { Args: never; Returns: string }
    }
    Enums: {
      app_role: "admin" | "logistics" | "farmer" | "trader"
      enrollment_status: "invited" | "active" | "withdrawn" | "completed"
      equipment_category:
        | "tractor"
        | "plough"
        | "planter"
        | "harvester"
        | "irrigation_pump"
        | "sprayer"
        | "thresher"
        | "mill"
        | "vehicle"
        | "hand_tool"
        | "other"
      equipment_condition: "new" | "good" | "fair" | "poor" | "broken"
      farming_type: "crop" | "livestock" | "mixed"
      invitation_status: "pending" | "accepted" | "expired" | "revoked"
      org_plan: "pilot" | "growth" | "enterprise"
      org_role:
        | "org_owner"
        | "org_manager"
        | "org_agronomist"
        | "org_extension"
        | "org_viewer"
      org_status: "prospect" | "pilot" | "active" | "suspended" | "archived"
      org_type: "exporter" | "ngo" | "processor" | "government" | "cooperative"
      ownership_type: "owned" | "leased" | "shared" | "hired"
      power_source: "manual" | "animal" | "fuel" | "electric" | "solar"
      scheme_report_type: "compliance" | "impact" | "season_summary" | "custom"
      scheme_status: "draft" | "recruiting" | "active" | "closed" | "archived"
      soil_confidence_level: "low" | "medium" | "high" | "validated"
      soil_data_source:
        | "estimated"
        | "self_reported"
        | "lab_uploaded"
        | "officer_entry"
    }
    CompositeTypes: {
      geometry_dump: {
        path: number[] | null
        geom: unknown
      }
      valid_detail: {
        valid: boolean | null
        reason: string | null
        location: unknown
      }
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "logistics", "farmer", "trader"],
      enrollment_status: ["invited", "active", "withdrawn", "completed"],
      equipment_category: [
        "tractor",
        "plough",
        "planter",
        "harvester",
        "irrigation_pump",
        "sprayer",
        "thresher",
        "mill",
        "vehicle",
        "hand_tool",
        "other",
      ],
      equipment_condition: ["new", "good", "fair", "poor", "broken"],
      farming_type: ["crop", "livestock", "mixed"],
      invitation_status: ["pending", "accepted", "expired", "revoked"],
      org_plan: ["pilot", "growth", "enterprise"],
      org_role: [
        "org_owner",
        "org_manager",
        "org_agronomist",
        "org_extension",
        "org_viewer",
      ],
      org_status: ["prospect", "pilot", "active", "suspended", "archived"],
      org_type: ["exporter", "ngo", "processor", "government", "cooperative"],
      ownership_type: ["owned", "leased", "shared", "hired"],
      power_source: ["manual", "animal", "fuel", "electric", "solar"],
      scheme_report_type: ["compliance", "impact", "season_summary", "custom"],
      scheme_status: ["draft", "recruiting", "active", "closed", "archived"],
      soil_confidence_level: ["low", "medium", "high", "validated"],
      soil_data_source: [
        "estimated",
        "self_reported",
        "lab_uploaded",
        "officer_entry",
      ],
    },
  },
} as const
