
import React, { useState, useEffect, useRef, lazy, Suspense } from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider, useAuth } from "@/hooks/useAuth";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import PrivacyPolicy from "./pages/PrivacyPolicy";
import Terms from "./pages/Terms";
import Status from "./pages/Status";
import ProtectedRoute from "@/components/ProtectedRoute";
import ErrorBoundary from "@/components/ErrorBoundary";
import FeedbackWidget from "@/components/FeedbackWidget";
import { useTelemetry } from "@/hooks/useTelemetry";
import { supabase } from "@/integrations/supabase/client";

// Lazy-load heavy auth-only routes so the public landing stays fast
const AuthPage = lazy(() => import("@/components/AuthPage"));
const AdminDashboard = lazy(() => import("@/components/AdminDashboard"));
const Discovery = lazy(() => import("./pages/Discovery"));
const MyFarmDashboard = lazy(() => import("@/components/MyFarmDashboard"));
const LogisticsDashboard = lazy(() => import("@/components/LogisticsDashboard"));
const FarmRegistrationModal = lazy(() => import("@/components/FarmRegistrationModal"));
const PitchDashboard = lazy(() => import("./pages/PitchDashboard"));
const OrgPage = lazy(() => import("./pages/OrgPage"));
const InvitationAccept = lazy(() => import("./pages/InvitationAccept"));


const RouteFallback = () => (
  <div className="min-h-screen bg-gradient-to-br from-green-50 to-yellow-50 flex items-center justify-center">
    <div className="text-green-900 text-xl flex items-center gap-3">
      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-900"></div>
      Loading...
    </div>
  </div>
);

// Add defensive check for React
if (typeof React === 'undefined') {
  throw new Error('React is not imported correctly');
}

// Tuned for low-bandwidth / PWA-like behavior:
// - no refetch when the tab regains focus (was the main cause of "reload on tab return")
// - generous staleTime/gcTime so cached data survives navigation
// - capped retry backoff for flaky connections
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      refetchOnReconnect: "always",
      staleTime: 5 * 60 * 1000,
      gcTime: 30 * 60 * 1000,
      retry: 2,
      retryDelay: (attempt) => Math.min(1000 * 2 ** attempt, 10_000),
    },
  },
});

const TelemetryRoutes = ({ showFeedback }: { showFeedback: boolean }) => {
  useTelemetry(); // auto-tracks page_view on every route change
  return (
    <Suspense fallback={<RouteFallback />}>
      <Routes>
        <Route path="/" element={<Index />} />
        <Route path="/dashboard" element={<Index />} />
        <Route path="/auth" element={<AuthPage onAuthSuccess={() => window.location.href = '/'} />} />
        <Route path="/privacy" element={<PrivacyPolicy />} />
        <Route path="/terms" element={<Terms />} />
        <Route path="/status" element={<Status />} />
        <Route path="/discovery" element={<Discovery />} />
        <Route path="/pitch" element={<PitchDashboard />} />
        <Route path="/org/:slug" element={<OrgPage />} />
        <Route path="/invite/:token" element={<InvitationAccept />} />

        <Route path="/admin" element={<AdminDashboard />} />

        {/* Protected farmer route */}
        <Route element={<ProtectedRoute allowedRoles={["farmer"]} />}>
          <Route path="/my-farm" element={<MyFarmDashboard />} />
        </Route>

        {/* Protected logistics/admin route */}
        <Route element={<ProtectedRoute allowedRoles={["Logistics", "Admin"]} />}>
          <Route path="/logistics" element={<LogisticsDashboard />} />
        </Route>

        <Route path="*" element={<NotFound />} />
      </Routes>
      {showFeedback && <FeedbackWidget />}
    </Suspense>
  );
};

const MainApp = ({ showFeedback }: { showFeedback: boolean }) => {
  return (
    <BrowserRouter>
      <TelemetryRoutes showFeedback={showFeedback} />
    </BrowserRouter>
  );
};

const AppContent = () => {
  const { user, loading, profile } = useAuth();
  const [showFarmRegistration, setShowFarmRegistration] = useState(false);
  // Cache the farm-check per user so tab refocus / token refresh never re-runs it.
  const checkedFarmForUserRef = useRef<string | null>(null);

  console.log("App state - User:", !!user, "Loading:", loading, "Profile:", !!profile);

  // Check if farmer needs to register a farm — runs at most once per signed-in user.
  // Done silently in the background so we never blank the dashboard with a spinner
  // when the tab regains focus.
  useEffect(() => {
    const checkFarmRegistration = async () => {
      const userRole = (user as any)?.user_metadata?.value_chain_stage as string | undefined;
      const profileRole = profile?.value_chain_stage;
      const effectiveRole = profileRole || userRole;

      if (!user || effectiveRole !== "farmer") return;
      if (checkedFarmForUserRef.current === user.id) return;
      checkedFarmForUserRef.current = user.id;

      try {
        const { data: farms, error } = await supabase
          .from("farms")
          .select("id")
          .eq("user_id", user.id)
          .limit(1);

        if (error) {
          console.error("Error checking farms:", error);
          return;
        }

        if (!farms || farms.length === 0) {
          setShowFarmRegistration(true);
        }
      } catch (error) {
        console.error("Error checking farm registration:", error);
      }
    };

    checkFarmRegistration();
  }, [user, profile]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-yellow-50 flex items-center justify-center">
        <div className="text-green-900 text-xl flex items-center gap-3">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-900"></div>
          Loading Zimbabwe's Agricultural Intelligence Engine...
        </div>
      </div>
    );
  }

  return (
    <>
      <MainApp showFeedback={!!user} />
      {showFarmRegistration && (
        <Suspense fallback={null}>
          <FarmRegistrationModal
            isOpen={showFarmRegistration}
            onClose={() => {
              setShowFarmRegistration(false);
              // Invalidate farm-related queries so the dashboard picks up the new farm
              // without doing a full-page reload.
              queryClient.invalidateQueries({ queryKey: ["farms"] });
              queryClient.invalidateQueries({ queryKey: ["farm"] });
            }}
            userId={user!.id}
          />
        </Suspense>
      )}
    </>
  );
};

const App = () => {
  return (
    <ErrorBoundary>
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <ErrorBoundary>
            <AuthProvider>
              <ErrorBoundary>
                <Toaster />
                <Sonner />
                <AppContent />
              </ErrorBoundary>
            </AuthProvider>
          </ErrorBoundary>
        </TooltipProvider>
      </QueryClientProvider>
    </ErrorBoundary>
  );
};

export default App;
