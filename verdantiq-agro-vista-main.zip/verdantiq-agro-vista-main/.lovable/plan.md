# Retire ZimPriceCheck scraper + Responsible AI guardrails

## 1. Remove the ZimPriceCheck scraper (keep all stored prices)

**Database migration**

- `SELECT cron.unschedule('zimpricecheck-daily-scrape');` (guarded with `IF EXISTS`-style DO block so re-runs are safe).
- No `DELETE` on `mbare_market_prices` / `mbare_price_history` — historical + today's prices stay intact.
- Add a `source_type` column to `mbare_market_prices` ( `'manual' | 'partner'`, default `'manual'`) and backfill existing rows to `'manual'` so the audit trail distinguishes legacy data.

**Edge function**

- Delete `supabase/functions/zimpricecheck-scraper/` and remove its entry from `supabase/config.toml`.
- Call `supabase--delete_edge_functions` for `zimpricecheck-scraper` so the deployed function stops serving.
- Remove the `market-scraper` / `zimpricecheck-scraper` row from `service_components` seed (Status page) via migration so it stops showing as a monitored service.

**Frontend**

- `AdminDashboard.tsx`: remove the "Market Data Scraper" card and `runZimPriceCheckScraper` handler. The existing Mbare add/edit/delete UI already supports manual entry — no rebuild needed.
- `src/pages/Index.tsx`: replace "Mbare + zimpricecheck" copy with "Mbare Musika (verified prices)".

## 2. Audit trail for manual price entry

Architecture designed so a future "approved data partner" can drop in without schema changes.

**New table `mbare_price_audit**` (append-only)

- Columns: `id`, `price_id` (fk to `mbare_market_prices`), `action` (`insert|update|delete`), `actor_id` (auth.uid), `actor_role`, `source_type`, `before` jsonb, `after` jsonb, `note` text, `created_at`.
- RLS: only admins read; inserts via SECURITY DEFINER trigger only.
- Trigger `mbare_price_audit_trg` on `mbare_market_prices` INSERT/UPDATE/DELETE writes the row automatically.
- GRANTs: `SELECT` to authenticated (RLS narrows to admins); `ALL` to service_role.

**Admin UI**

- New sub-tab under Mbare Musika: "Audit log" — lists recent actions with actor email, action, item, before/after, timestamp.
- Add a small "Source" dropdown in the add/edit form (`Manual verified` / `Partner feed`) so operators tag entries; stored in `source_type`.

**Partner-ready plug-in point**

- Document (README section in the AdminDashboard KB or a comment in the migration) that a partner ingestion function only needs to `INSERT` into `mbare_market_prices` with `source_type = 'partner'` and set `source` to the partner name; the trigger handles audit automatically. No downstream code changes required.

## 3. Responsible AI principles & guardrails

Applied everywhere the app surfaces AI advice: `ai-agronomist`, `planting-insights`, `yield-prediction`, `ndvi-anomaly-check`, `daily-whatsapp-digest`.

**Shared system-prompt block** (new file `supabase/functions/_shared/responsible-ai.ts` exporting `RESPONSIBLE_AI_GUARDRAILS`):

- **Transparency:** frame every recommendation as "decision-support guidance, not a definitive instruction"; instruct the model to say so explicitly in outputs.
- **Attribution:** always attribute to "Mudhumeni Hungwe (Powered by Zyterra)" — never name the underlying model.
- **Uncertainty:** when confidence is low or data is stale/missing, say so ("Based on limited data…", "Verify with your local extension officer").
- **Safety scope:** refuse or defer on chemical dosages that exceed label rates, veterinary drug prescriptions, financial/legal advice; direct to a qualified professional.
- **Bias & locality:** ground advice in Zimbabwean/African smallholder context; avoid Northern-hemisphere defaults.
- **Human oversight:** every response ends with a short standard disclaimer footer.

**Wire-up**

- Prepend `RESPONSIBLE_AI_GUARDRAILS` to the system prompt in each of the 5 edge functions above.
- WhatsApp channel: shortened one-line footer ("*Guidance only — verify with your extension officer.*") to respect the 1400-char cap.
- Web channel: full disclaimer rendered as a small muted card under AI outputs in `AIAgronomist.tsx`, `PlantingInsights.tsx`, `YieldPrediction.tsx`, and the NDVI anomaly diagnosis in `CropHealthMonitor.tsx`.

**UI badge**

- Add a reusable `<AIAdvisoryBadge />` component (small pill: "AI-assisted guidance · verify locally") placed at the top of each AI output surface.

## Technical notes

- Migration order for the new table: `CREATE TABLE` → `GRANT` → `ENABLE RLS` → `CREATE POLICY` → trigger.
- `service_components` cleanup uses `DELETE WHERE key IN ('market-scraper','zimpricecheck-scraper')`.
- No changes to `useMarketData` — it already reads from `mbare_market_prices` regardless of source.
- Existing `mbare_price_history` is untouched; future partner feeds should keep writing history rows for trend charts.

## Out of scope

- Building a partner ingestion function (only the plug-in contract is documented).
- Changing the market_prices (grain) table — this request is scoped to the Mbare/scraper path and AI guardrails.

&nbsp;

Another important thing, let's remove the AI responce character cap for now. Full responses across Web & WhatsApp